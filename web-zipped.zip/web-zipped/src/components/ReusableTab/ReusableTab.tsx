import React from "react";
import { Tabs } from "antd";
import styles from "./ReusableTab.module.scss";

export interface TabItem {
  key: string;
  label: string;
  children: React.ReactNode;
  disabled?: boolean;
}

interface ReusableTabProps {
  items: TabItem[];
  defaultActiveKey?: string;
  activeKey?: string;
  onChange?: (key: string) => void;
  className?: string;
  centered?: boolean;
  size?: "small" | "middle" | "large";
  type?: "line" | "card" | "editable-card";
  tabPosition?: "top" | "right" | "bottom" | "left";
}

const ReusableTab: React.FC<ReusableTabProps> = ({
  items,
  defaultActiveKey,
  activeKey,
  onChange,
  className = "",
  centered = false,
  size = "middle",
  type = "line",
  tabPosition = "top",
}) => {
  return (
    <div className={styles.tabContainer}>
      <Tabs
        items={items}
        defaultActiveKey={defaultActiveKey}
        activeKey={activeKey}
        onChange={onChange}
        className={`${styles.reusableTab} ${className}`}
        centered={centered}
        size={size}
        type={type}
        tabPosition={tabPosition}
      />
    </div>
  );
};

export default ReusableTab;
