import React from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { SyncOutlined } from "@ant-design/icons";
import styles from "./DashboardGraph.module.scss";

interface DataPoint {
  month: string;
  value: number;
}

interface DashboardGraphProps {
  title?: string;
  status?: string;
  dataProvider?: string;
  color?: string;
  width?: number;
  height?: number;
  className?: string;
}

// Custom tooltip component
const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ payload: DataPoint; value: number }>;
  label?: string;
}) => {
  if (active && payload && payload.length) {
    const value = payload[0].value;
    return (
      <div className={styles.customTooltip}>
        <div className={styles.tooltipContent}>
          <div className={styles.tooltipTitle}>{label}</div>
          <div className={styles.tooltipValue}>value: {value}</div>
        </div>
      </div>
    );
  }
  return null;
};

const DashboardGraph: React.FC<DashboardGraphProps> = ({
  title = "Total Completed Transactions",
  status = "Available",
  dataProvider = "Data provided by SprintAP",
  color = "#2d5a5a",
  height = 300,
  className,
}) => {
  // Sample data points matching the attached image pattern
  const data: DataPoint[] = [
    { month: "JAN", value: 10 },
    { month: "FEB", value: 45 },
    { month: "MAR", value: 18 },
    { month: "APR", value: 8 },
    { month: "MAY", value: 3 },
    { month: "JUN", value: 12 },
    { month: "JUL", value: 8 },
    { month: "AUG", value: 58 },
    { month: "SEP", value: 15 },
    { month: "OCT", value: 42 },
    { month: "NOV", value: 25 },
    { month: "DEC", value: 5 },
  ];

  return (
    <div className={`${styles.graphContainer} ${className || ""}`}>
      <div className={styles.header}>
        <div className={styles.titleSection}>
          <h3 className={styles.title}>
            {title} <span className={styles.status}>{status}</span>
          </h3>
          <div className={styles.dataProvider}>{dataProvider}</div>
        </div>
        <SyncOutlined className={styles.refreshIcon} />
      </div>

      <div className={styles.chartWrapper}>
        <ResponsiveContainer width="100%" height={height}>
          <AreaChart
            data={data}
            margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 20,
            }}
          >
            <defs>
              <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.2} />
                <stop offset="100%" stopColor={color} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="0" stroke="transparent" />
            <XAxis
              dataKey="month"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: "#999999" }}
              padding={{ left: 20, right: 20 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: "#999999" }}
              domain={[0, 60]}
              tickCount={5}
              label={{
                value: "Current Growth",
                angle: -90,
                position: "insideLeft",
                style: {
                  textAnchor: "middle",
                  fontSize: "12px",
                  fill: "#999999",
                },
              }}
            />
            <Tooltip content={<CustomTooltip />} cursor={false} />
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              fill="url(#colorGradient)"
              dot={false}
              activeDot={{
                r: 4,
                fill: color,
                stroke: "transparent",
                strokeWidth: 0,
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default DashboardGraph;
