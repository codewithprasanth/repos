import { App } from "antd";

let messageApi: ReturnType<typeof App.useApp>["message"] | null = null;

export const setMessageApi = (
  api: ReturnType<typeof App.useApp>["message"]
) => {
  messageApi = api;
};

/**
 * Extracts error message from API error response
 */
export const getErrorMessage = (
  error: unknown,
  fallbackMessage: string
): string => {
  // Try to extract message from Axios error response
  const err = error as {
    response?: { data?: { message?: string } };
    message?: string;
  };

  if (err?.response?.data?.message) {
    return err.response.data.message;
  }

  // Fallback to generic message or error message
  if (err?.message) {
    return err.message;
  }

  return fallbackMessage;
};

/**
 * Centralized message utility for consistent notifications across the application.
 *
 * Usage:
 * ```ts
 * import { showMessage } from '@/components/Message';
 *
 * showMessage.success('Operation completed successfully');
 * showMessage.error('Failed to save data');
 * showMessage.warning('Please review your input');
 * showMessage.info('New update available');
 *
 * // For loading states
 * const hide = showMessage.loading('Processing...');
 * // Later: hide();
 * ```
 */
export const showMessage = {
  /**
   * Show success message
   */
  success: (content: string) => {
    if (messageApi) {
      messageApi.success({
        content,
        duration: 3,
      });
    }
  },

  /**
   * Show error message
   */
  error: (content: string) => {
    if (messageApi) {
      messageApi.error({
        content,
        duration: 3,
      });
    }
  },

  /**
   * Show warning message
   */
  warning: (content: string) => {
    if (messageApi) {
      messageApi.warning({
        content,
        duration: 3,
      });
    }
  },

  /**
   * Show info message
   */
  info: (content: string) => {
    if (messageApi) {
      messageApi.info({
        content,
        duration: 3,
      });
    }
  },

  /**
   * Show loading message (does not auto-close)
   * Returns a function to manually close the message
   */
  loading: (content: string) => {
    if (messageApi) {
      return messageApi.loading({
        content,
        duration: 0,
      });
    }
    return () => {};
  },

  /**
   * Destroy all messages
   */
  destroy: () => {
    if (messageApi) {
      messageApi.destroy();
    }
  },
};

export default showMessage;
