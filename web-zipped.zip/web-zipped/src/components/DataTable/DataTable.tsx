import React from "react";
import { Table } from "antd";
import type { ColumnsType, TableProps } from "antd/es/table";
import styles from "./DataTable.module.scss";

interface DataTableProps<T = Record<string, unknown>> {
  data?: T[];
  columns: ColumnsType<T>;
  loading?: boolean;
  size?: "small" | "middle" | "large";
  onRowClick?: (record: T) => void;
  rowKey?: string | ((record: T) => string);
  pagination?: boolean | object;
  bordered?: boolean;
  className?: string;
  onSortChange?: (sortBy: string, sortOrder: "asc" | "desc") => void;
  onPaginationChange?: (page: number, pageSize: number) => void;
  totalRecords?: number;
  rowSelection?: TableProps<T>["rowSelection"];
}

export default function DataTable<T = Record<string, unknown>>({
  data = [],
  columns,
  loading = false,
  size = "small",
  onRowClick,
  rowKey = "id",
  pagination = true,
  bordered = false,
  className,
  onSortChange,
  onPaginationChange,
  totalRecords,
  rowSelection,
}: DataTableProps<T>) {
  const handleTableChange: TableProps<T>["onChange"] = (
    paginationConfig,
    _filters,
    sorter
  ) => {
    // Handle sort changes
    if (!Array.isArray(sorter) && sorter.order && onSortChange) {
      const sortOrder = sorter.order === "ascend" ? "asc" : "desc";
      onSortChange(sorter.field as string, sortOrder);
    }

    // Handle pagination changes
    if (paginationConfig && onPaginationChange) {
      onPaginationChange(
        paginationConfig.current || 1,
        paginationConfig.pageSize || 10
      );
    }
  };

  return (
    <div className={styles.dataTableContainer}>
      <Table
        columns={columns}
        dataSource={data}
        loading={loading}
        size={size}
        className={`${styles.dataTable} ${className || ""}`}
        rowKey={rowKey}
        bordered={bordered}
        onChange={handleTableChange}
        rowSelection={rowSelection}
        onRow={
          onRowClick
            ? (record) => ({
                onDoubleClick: () => onRowClick(record),
                style: { cursor: "pointer" },
              })
            : undefined
        }
        pagination={
          pagination === true
            ? (totalRecords || data.length) <= 10
              ? false
              : {
                  showSizeChanger: true,
                  showQuickJumper: false,
                  showTotal: (total, range) =>
                    `${range[0]} - ${range[1]} of ${total}`,
                  defaultPageSize: 10,
                  pageSizeOptions: ["10", "20", "50", "100"],
                  className: styles.pagination,
                  size: "default",
                  total: totalRecords || data.length,
                }
            : pagination
        }
        scroll={{ x: "max-content" }}
      />
    </div>
  );
}
