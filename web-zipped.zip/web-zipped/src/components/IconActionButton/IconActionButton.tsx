import React from "react";
import { Tooltip } from "antd";
import type { ButtonProps } from "antd";
import ReusableButton from "../ReusableButton/ReusableButton";
import styles from "./IconActionButton.module.scss";

interface ActionButtonProps extends Omit<ButtonProps, "children" | "variant"> {
  icon: React.ReactNode;
  tooltip?: string;
  variant?: "primary" | "secondary" | "danger" | "success" | "warning";
  size?: "small" | "middle" | "large";
  className?: string;
}

const IconButton: React.FC<ActionButtonProps> = ({
  icon,
  tooltip,
  variant = "primary",
  size = "middle",
  className,
  disabled = false,
  loading = false,
  onClick,
  ...restProps
}) => {
  const getButtonProps = () => {
    const baseProps: ButtonProps = {
      type: "text",
      shape: "circle",
      size,
      icon,
      disabled,
      loading,
      onClick,
      className: `${styles.actionButton} ${styles[variant]} ${className || ""}`,
      ...restProps,
    };

    return baseProps;
  };

  const buttonProps = getButtonProps();
  const { variant: _, ...restButtonProps } = buttonProps;
  const button = <ReusableButton variant={variant} {...restButtonProps} />;

  // Wrap with tooltip if provided
  if (tooltip && !disabled) {
    return (
      <Tooltip title={tooltip} placement="top">
        {button}
      </Tooltip>
    );
  }

  return button;
};

export default IconButton;
