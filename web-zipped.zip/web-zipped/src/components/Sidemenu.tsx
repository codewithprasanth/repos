// SidebarMenu.tsx
import React, { useState, useMemo } from "react";
import { Menu } from "antd";
import type { MenuProps } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { selectUser } from "../store/auth/auth-selector";
import { AppRoles } from "../auth/roles-privileges";
import {
  HomeOutlined,
  FileTextOutlined,
  InboxOutlined,
  SettingOutlined,
  ToolOutlined,
  RobotOutlined,
  BarChartOutlined,
  UserOutlined,
  MailOutlined,
  TeamOutlined,
  LineChartOutlined,
  PieChartOutlined,
  FundOutlined,
} from "@ant-design/icons";
import styles from "./Sidemenu.module.scss";

interface SideMenuProps {
  collapsed: boolean;
}

const SideMenu: React.FC<SideMenuProps> = ({ collapsed }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const user = useSelector(selectUser);

  const routeMap: Record<string, string> = {
    home: "/home",
    personal_inbox: "/invoice-management/personal-inbox",
    touchless: "/invoice-management/touchless",
    indexing: "/invoice-management/indexing",
    // qc_module: "/invoice-management/qc-module",
    doa_configuration: "/admin/doa-configuration",
    user_management: "/admin/user-management",
    email_recon_report: "/analytics/email-recon-report",
    organizational: "/analytics/organizational",
    personal_analytics: "/analytics/personal-analytics",
    qc_analysis: "/analytics/qc-analysis",
    spend_analysis: "/analytics/spend-analysis",
    volume_forecast: "/analytics/volume-forecast",
  };

  // Get current selected key based on current route
  const getCurrentKey = () => {
    const currentRoute = location.pathname;
    return (
      Object.keys(routeMap).find((key) => routeMap[key] === currentRoute) ||
      "home"
    );
  };

  const [selectedKey, setSelectedKey] = useState(getCurrentKey());

  const handleClick: MenuProps["onClick"] = (e) => {
    setSelectedKey(e.key);
    const route = routeMap[e.key];
    if (route) {
      navigate(route);
    }
  };

  // Build menu items based on user roles
  const menuItems: MenuProps["items"] = useMemo(() => {
    // Helper function to check if user has any of the required roles
    const hasAnyRole = (requiredRoles: string[]): boolean => {
      if (!user?.roles) return false;
      return requiredRoles.some((role) => user.roles.includes(role));
    };

    const items: MenuProps["items"] = [];

    // Home - accessible to all authenticated users
    items.push({
      key: "home",
      icon: <HomeOutlined />,
      label: "Home",
    });

    // Invoice Management - build children based on roles
    const invoiceChildren: MenuProps["items"] = [];

    // Personal Inbox - accessible to all authenticated users
    invoiceChildren.push({
      key: "personal_inbox",
      icon: <InboxOutlined />,
      label: "Personal Inbox",
    });

    // Touchless - accessible to INDEXER or ADMIN
    if (hasAnyRole([AppRoles.INDEXER, AppRoles.ADMIN])) {
      invoiceChildren.push({
        key: "touchless",
        icon: <RobotOutlined />,
        label: "Touchless",
      });
    }

    // Indexing - accessible to INDEXER or ADMIN
    if (hasAnyRole([AppRoles.INDEXER, AppRoles.ADMIN])) {
      invoiceChildren.push({
        key: "indexing",
        icon: <ToolOutlined />,
        label: "Indexing (Manual)",
      });
    }

    // Always show Invoice Management as all users have at least Personal Inbox
    items.push({
      key: "invoice_management",
      icon: <FileTextOutlined />,
      label: "Invoice Management",
      children: invoiceChildren,
    });

    // Admin - accessible to ADMIN only
    if (hasAnyRole([AppRoles.ADMIN])) {
      items.push({
        key: "admin",
        icon: <SettingOutlined />,
        label: "Admin",
        children: [
          {
            key: "doa_configuration",
            icon: <SettingOutlined />,
            label: "DOA Configuration",
          },
          {
            key: "user_management",
            icon: <UserOutlined />,
            label: "User Management",
          },
        ],
      });
    }

    // Analytics - accessible to all authenticated users
    items.push({
      key: "analytics",
      icon: <BarChartOutlined />,
      label: "Analytics",
      children: [
        {
          key: "email_recon_report",
          icon: <MailOutlined />,
          label: "Email Recon Report",
        },
        {
          key: "organizational",
          icon: <TeamOutlined />,
          label: "Organizational",
        },
        {
          key: "personal_analytics",
          icon: <UserOutlined />,
          label: "Personal",
        },
        {
          key: "qc_analysis",
          icon: <LineChartOutlined />,
          label: "QC Analysis",
        },
        {
          key: "spend_analysis",
          icon: <PieChartOutlined />,
          label: "Spend Analysis",
        },
        {
          key: "volume_forecast",
          icon: <FundOutlined />,
          label: "Volume Forecast",
        },
      ],
    });

    return items;
  }, [user]);

  return (
    <Menu
      onClick={handleClick}
      selectedKeys={[selectedKey]}
      mode="inline"
      inlineCollapsed={collapsed}
      className={styles.sideMenu}
      items={menuItems}
    />
  );
};

export default SideMenu;
