import React, { useState, useEffect, useRef } from "react";
import { Select, Spin } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import styles from "./LiveSearch.module.scss";

export interface LiveSearchProps<T> {
  label?: string;
  placeholder?: string;
  required?: boolean;
  error?: string;
  value?: string | number | string[] | number[];
  onChange?: (
    value: string | number | string[] | number[],
    selectedItem?: T
  ) => void;
  disabled?: boolean;
  mode?: "multiple" | "tags";
  allowClear?: boolean;

  // API integration
  fetchFunction: (keyword?: string) => Promise<T[]>;

  // Customization
  getOptionValue: (item: T) => string | number;
  getOptionLabel: (item: T) => string;
  renderOption?: (item: T) => React.ReactNode;
  renderSelectedValue?: (item: T) => React.ReactNode;

  // Configuration
  initialPageSize?: number;
  searchPageSize?: number;
  debounceMs?: number;
}

function LiveSearch<T>({
  label,
  placeholder = "Search...",
  required = false,
  error,
  value,
  onChange,
  disabled = false,
  mode,
  allowClear = true,
  fetchFunction,
  getOptionValue,
  getOptionLabel,
  renderOption,
  initialPageSize = 5,
  searchPageSize = 5,
  debounceMs = 300,
}: LiveSearchProps<T>) {
  const [options, setOptions] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState("");
  const debounceTimerRef = useRef<number | null>(null);

  // Initial load
  useEffect(() => {
    fetchOptions("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch options on search
  useEffect(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      fetchOptions(searchKeyword);
    }, debounceMs);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchKeyword]);

  const fetchOptions = async (keyword: string) => {
    try {
      setLoading(true);
      const data = await fetchFunction(keyword);
      const pageSize = keyword ? searchPageSize : initialPageSize;
      setOptions(data.slice(0, pageSize));
    } catch (error) {
      console.error("Error fetching options:", error);
      setOptions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (value: string) => {
    setSearchKeyword(value);
  };

  const handleChange = (
    selectedValue: string | number | string[] | number[]
  ) => {
    if (onChange) {
      const selectedItem = options.find(
        (item) => getOptionValue(item) === selectedValue
      );
      onChange(selectedValue, selectedItem);
    }
  };

  const selectOptions = options.map((item) => ({
    value: getOptionValue(item),
    label: renderOption ? renderOption(item) : getOptionLabel(item),
    item: item,
  }));

  return (
    <div className={styles.liveSearch}>
      {label && (
        <label className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      )}
      <Select
        showSearch
        value={value}
        placeholder={placeholder}
        suffixIcon={<SearchOutlined />}
        filterOption={false}
        onSearch={handleSearch}
        onChange={handleChange}
        notFoundContent={loading ? <Spin size="small" /> : "No data found"}
        loading={loading}
        disabled={disabled}
        mode={mode}
        allowClear={allowClear}
        className={styles.select}
        options={selectOptions}
      />
      {error && <span className={styles.error}>{error}</span>}
    </div>
  );
}

export default LiveSearch;
