import React from "react";
import { Tag } from "antd";
import styles from "./StatusTag.module.scss";

interface StatusTagProps {
  status: unknown;
  className?: string;
}

const StatusTag: React.FC<StatusTagProps> = ({ status, className }) => {
  const statusStr = String(status);

  const getStatusColor = (statusValue: string) => {
    switch (statusValue.toLowerCase()) {
      case "duplicate":
        return "red";
      case "invoice cancelled":
        return "volcano";
      case "invoice indexed":
        return "green";
      case "pre indexing":
        return "blue";
      case "ap processing bucket":
        return "orange";
      case "sap posting":
        return "cyan";
      case "completed":
        return "success";
      case "pending":
        return "warning";
      case "in progress":
        return "processing";
      default:
        return "default";
    }
  };

  return (
    <Tag
      color={getStatusColor(statusStr)}
      className={`${styles.statusTag} ${className || ""}`}
    >
      {statusStr}
    </Tag>
  );
};

export default StatusTag;
