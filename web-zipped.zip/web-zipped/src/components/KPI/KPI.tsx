import React from "react";
import styles from "./KPI.module.scss";

interface KPIProps {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  value: string | number;
  trend?: "up" | "down" | "neutral";
  className?: string;
}

const KPI: React.FC<KPIProps> = ({
  icon,
  title,
  subtitle,
  value,
  trend,
  className,
}) => {
  return (
    <div className={`${styles.kpi} ${className || ""}`}>
      <div className={styles.left}>
        <div className={styles.iconContainer}>{icon}</div>
        <div className={styles.textContent}>
          <h3 className={styles.title}>{title}</h3>
          {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
        </div>
      </div>
      <div className={styles.right}>
        <span className={`${styles.value} ${trend ? styles[trend] : ""}`}>
          {value}
        </span>
      </div>
    </div>
  );
};

export default KPI;
