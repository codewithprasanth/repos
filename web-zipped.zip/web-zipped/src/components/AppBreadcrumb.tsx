import React from "react";
import { Breadcrumb } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { HomeOutlined } from "@ant-design/icons";
import { getRouteMetadata } from "../config/breadcrumbs-routes";

export default function AppBreadcrumb() {
  const location = useLocation();
  const navigate = useNavigate();

  const pathSegments = location.pathname.split("/").filter(Boolean);

  // Handle home page - show simple breadcrumb
  if (
    pathSegments.length === 0 ||
    (pathSegments.length === 1 && pathSegments[0] === "home")
  ) {
    return (
      <Breadcrumb
        separator=">"
        items={[
          {
            title: (
              <span
                style={{ display: "flex", alignItems: "center", gap: "4px" }}
              >
                <HomeOutlined />
                Home
              </span>
            ),
          },
        ]}
        style={{
          padding: "0 16px",
          margin: "0",
          background: "#fafafa",
          borderRadius: "6px",
          lineHeight: "32px",
        }}
      />
    );
  }

  const breadcrumbItems: { title: React.ReactNode }[] = [];

  // Build breadcrumb path
  let currentPath = "";
  pathSegments.forEach((segment, index) => {
    currentPath += `/${segment}`;
    const isLast = index === pathSegments.length - 1;
    const routeInfo = getRouteMetadata(segment);
    const displayName = routeInfo?.title || segment;
    const hasStandalonePage = routeInfo?.hasStandalonePage ?? true;

    if (isLast) {
      // Last item (current page) - not clickable
      breadcrumbItems.push({
        title: <span>{displayName}</span>,
      });
    } else if (!hasStandalonePage) {
      // Non-clickable parent routes (no standalone pages)
      breadcrumbItems.push({
        title: <span>{displayName}</span>,
      });
    } else {
      // Intermediate items - clickable
      const pathToNavigate = currentPath;
      breadcrumbItems.push({
        title: (
          <span
            onClick={() => navigate(pathToNavigate)}
            style={{ cursor: "pointer" }}
          >
            {displayName}
          </span>
        ),
      });
    }
  });

  return (
    <Breadcrumb
      separator=">"
      items={breadcrumbItems}
      style={{
        margin: "0",
        padding: "0 16px",
        background: "#fafafa",
        borderRadius: "6px",
        lineHeight: "32px",
      }}
    />
  );
}
