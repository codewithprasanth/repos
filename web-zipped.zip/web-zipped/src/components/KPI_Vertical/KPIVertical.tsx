import React from "react";
import styles from "./KPIVertical.module.scss";

interface KPIVerticalProps {
  icon: React.ReactNode;
  value: string | number;
  label: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  backgroundColor?: string;
  iconColor?: string;
  className?: string;
}

const KPIVertical: React.FC<KPIVerticalProps> = ({
  icon,
  value,
  label,
  trend,
  trendValue,
  backgroundColor = "rgb(45, 90, 90)",
  iconColor = "#ffffff",
  className,
}) => {
  return (
    <div
      className={`${styles.kpiContainer} ${className || ""}`}
      style={{ backgroundColor }}
    >
      <div className={styles.left}>
        <div className={styles.iconContainer} style={{ color: iconColor }}>
          {icon}
        </div>
      </div>
      <div className={styles.right}>
        <div className={styles.valueContainer}>
          <span className={styles.value}>{value}</span>
          {trend && trendValue && (
            <span className={`${styles.trend} ${styles[trend]}`}>
              {trend === "up" ? "↗" : trend === "down" ? "↘" : "→"} {trendValue}
            </span>
          )}
        </div>
        <div className={styles.labelContainer}>
          <span className={styles.label}>{label}</span>
        </div>
      </div>
    </div>
  );
};

export default KPIVertical;
