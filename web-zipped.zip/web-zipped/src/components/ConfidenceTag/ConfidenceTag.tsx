import { Tag } from "antd";

interface ConfidenceTagProps {
  confidence: string;
}

export default function ConfidenceTag({ confidence }: ConfidenceTagProps) {
  const percentage = parseInt(confidence.replace("%", ""));
  let color = "green";
  if (percentage < 90) color = "orange";
  if (percentage < 70) color = "red";

  return (
    <Tag
      color={color}
      style={{
        backgroundColor:
          color === "green"
            ? "#f6ffed"
            : color === "orange"
            ? "#fff7e6"
            : "#fff2f0",
        border: `1px solid ${
          color === "green"
            ? "#b7eb8f"
            : color === "orange"
            ? "#ffd591"
            : "#ffccc7"
        }`,
      }}
    >
      {confidence}
    </Tag>
  );
}
