import React from "react";
import { Modal } from "antd";
import styles from "./DocumentPreviewModal.module.scss";

export interface DocumentPreviewModalProps {
  open: boolean;
  onClose: () => void;
  documentUrl: string;
  documentType?: "pdf" | "image";
  title?: string;
}

const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  open,
  onClose,
  documentUrl,
  documentType = "pdf",
  title = "Document Preview",
}) => {
  return (
    <Modal
      title={title}
      open={open}
      onCancel={onClose}
      footer={null}
      width="80%"
      style={{ top: 20 }}
      bodyStyle={{ height: "calc(100vh - 200px)", overflow: "auto" }}
      className={styles.documentPreviewModal}
    >
      <div className={styles.previewContent}>
        {documentType === "pdf" ? (
          <iframe
            src={documentUrl}
            className={styles.pdfViewer}
            title="Document Preview"
          />
        ) : (
          <img
            src={documentUrl}
            alt="Document Preview"
            className={styles.imageViewer}
          />
        )}
      </div>
    </Modal>
  );
};

export default DocumentPreviewModal;
