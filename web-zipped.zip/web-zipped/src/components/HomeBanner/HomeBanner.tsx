import React from "react";
import styles from "./HomeBanner.module.scss";

interface GreetingBannerProps {
  username: string;
}

const HomeBanner: React.FC<GreetingBannerProps> = ({ username }) => {
  const now = new Date();
  const hour = now.getHours();
  const time = now.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  // Truncate username if too long for mobile
  const displayName =
    username.length > 15 ? `${username.substring(0, 12)}...` : username;

  let greeting = "";

  if (hour >= 5 && hour < 12) {
    greeting = "Good Morning";
  } else if (hour >= 12 && hour < 17) {
    greeting = "Good Afternoon";
  } else if (hour >= 17 && hour < 20) {
    greeting = "Good Evening";
  } else {
    greeting = "Good Night";
  }

  return (
    <div
      className={styles.banner}
      style={{
        background: "linear-gradient(135deg, #2d5a5a 0%, #4a8e8e 100%)",
      }}
    >
      <div className={styles.left}>
        <h1>
          {greeting} {displayName}
        </h1>
        <p>Check out the tasks below to get things rolling</p>
      </div>
      <div className={styles.right}>
        <span className={styles.time}>{time}</span>
      </div>
    </div>
  );
};

export default HomeBanner;
