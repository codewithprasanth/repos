import React from "react";
import { Switch } from "antd";
import styles from "./LabeledToggle.module.scss";

export interface LabeledToggleProps {
  label: string;
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  size?: "default" | "small";
  required?: boolean;
  helpText?: string;
  error?: string;
  className?: string;
  name?: string;
  id?: string;
  loading?: boolean;
}

const LabeledToggle: React.FC<LabeledToggleProps> = ({
  label,
  checked = false,
  onChange,
  disabled = false,
  size = "default",
  required = false,
  helpText,
  error,
  className = "",
  name,
  id,
  loading = false,
}) => {
  const toggleId = id || name || label.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className={`${styles.labeledToggle} ${className}`}>
      <div className={styles.toggleWrapper}>
        <div className={styles.labelWrapper}>
          <label htmlFor={toggleId} className={styles.label}>
            {label}
            {required && <span className={styles.required}>*</span>}
          </label>
        </div>
        <Switch
          id={toggleId}
          checked={checked}
          onChange={onChange}
          disabled={disabled}
          size={size}
          loading={loading}
          className={styles.switch}
        />
      </div>
      {error && <div className={styles.errorText}>{error}</div>}
      {!error && helpText && <div className={styles.helpText}>{helpText}</div>}
    </div>
  );
};

export default LabeledToggle;
