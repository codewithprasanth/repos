import React from "react";
import { Spin } from "antd";
import { LoadingOutlined } from "@ant-design/icons";

interface SpinnerProps {
  fullscreen?: boolean;
  tip?: string;
  size?: "small" | "default" | "large";
}

const Spinner: React.FC<SpinnerProps> = ({
  fullscreen = false,
  size = "large",
}) => {
  const style: React.CSSProperties = fullscreen
    ? {
        position: "fixed",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        zIndex: 9999,
      }
    : {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100%",
        width: "100%",
      };

  return (
    <div style={style}>
      <Spin
        indicator={
          <LoadingOutlined
            style={{
              fontSize: size === "small" ? 24 : size === "large" ? 64 : 36,
              color: "#2d5a5a",
            }}
            spin
          />
        }
      />
    </div>
  );
};

export default Spinner;
