import React from "react";
import { Timeline as AntTimeline } from "antd";
import { CheckCircleOutlined, ClockCircleOutlined } from "@ant-design/icons";
import styles from "./RulesTimeline.module.scss";

export interface TimelineRule {
  title: string;
  status: "success" | "failed" | "pending";
  message: string;
}

interface RulesTimelineProps {
  data: TimelineRule[];
  className?: string;
}

const RulesTimeline: React.FC<RulesTimelineProps> = ({
  data,
  className = "",
}) => {
  const getTimelineIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircleOutlined style={{ color: "#52c41a" }} />;
      case "failed":
        return <ClockCircleOutlined style={{ color: "#faad14" }} />;
      default:
        return <ClockCircleOutlined />;
    }
  };

  const getStatusTag = (status: string, message: string) => {
    const color =
      status === "success" ? "green" : status === "failed" ? "orange" : "blue";
    const backgroundColor =
      status === "success"
        ? "#f6ffed"
        : status === "failed"
        ? "#fff7e6"
        : "#f0f5ff";

    return (
      <span
        className={`${styles.statusTag} ${styles[status]}`}
        style={{
          backgroundColor,
          border: `1px solid ${
            color === "green"
              ? "#b7eb8f"
              : color === "orange"
              ? "#ffd591"
              : "#91d5ff"
          }`,
        }}
      >
        {message}
      </span>
    );
  };

  const timelineItems = data.map((rule, index) => ({
    key: `timeline-${index}`,
    dot: getTimelineIcon(rule.status),
    children: (
      <div className={styles.timelineItem}>
        <div className={styles.ruleTitle}>{rule.title}</div>
        <div className={styles.ruleStatus}>
          {getStatusTag(rule.status, rule.message)}
        </div>
      </div>
    ),
  }));

  return (
    <div className={`${styles.timelineContainer} ${className}`}>
      <AntTimeline items={timelineItems} />
    </div>
  );
};

export default RulesTimeline;
