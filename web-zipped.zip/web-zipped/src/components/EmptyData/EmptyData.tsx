import React from "react";
import styles from "./EmptyData.module.scss";

interface EmptyDataProps {
  icon?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

const EmptyData: React.FC<EmptyDataProps> = ({
  icon = "📋",
  title,
  description,
  action,
}) => {
  return (
    <div className={styles.emptyData}>
      <div className={styles.emptyIcon}>{icon}</div>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action && <div className={styles.actionContainer}>{action}</div>}
    </div>
  );
};

export default EmptyData;
