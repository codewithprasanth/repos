import React from "react";
import { Dropdown } from "antd";
import type { MenuProps } from "antd";
import { MoreOutlined } from "@ant-design/icons";
import styles from "./ThreePointButtons.module.scss";

export interface ThreePointMenuItem {
  key: string;
  label: string;
  onClick: () => void;
  visible?: boolean;
  danger?: boolean;
  disabled?: boolean;
}

interface ThreePointButtonsProps {
  items: ThreePointMenuItem[];
  className?: string;
  placement?:
    | "topLeft"
    | "topCenter"
    | "topRight"
    | "bottomLeft"
    | "bottomCenter"
    | "bottomRight";
}

const ThreePointButtons: React.FC<ThreePointButtonsProps> = ({
  items,
  className = "",
  placement = "bottomRight",
}) => {
  // Filter visible items and convert to Ant Design menu format
  const menuItems: MenuProps["items"] = items
    .filter((item) => item.visible !== false)
    .map((item) => ({
      key: item.key,
      label: item.label,
      danger: item.danger,
      disabled: item.disabled,
      onClick: item.onClick,
    }));

  const menuProps: MenuProps = {
    items: menuItems,
  };

  return (
    <Dropdown menu={menuProps} placement={placement} trigger={["click"]}>
      <button className={`${styles.threePointButton} ${className}`}>
        <MoreOutlined className={styles.icon} />
      </button>
    </Dropdown>
  );
};

export default ThreePointButtons;
