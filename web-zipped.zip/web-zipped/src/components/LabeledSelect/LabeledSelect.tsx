import React from "react";
import { Select } from "antd";
import styles from "./LabeledSelect.module.scss";

export interface SelectOption {
  label: string;
  value: string | number;
  disabled?: boolean;
}

export interface LabeledSelectProps {
  label: string;
  placeholder?: string;
  value?: string | number | (string | number)[];
  onChange?: (
    value: string | number | (string | number)[],
    option?: SelectOption | SelectOption[]
  ) => void;
  onBlur?: () => void;
  options: SelectOption[];
  required?: boolean;
  disabled?: boolean;
  size?: "large" | "middle" | "small";
  mode?: "multiple" | "tags";
  allowClear?: boolean;
  showSearch?: boolean;
  filterOption?: boolean | ((input: string, option?: SelectOption) => boolean);
  className?: string;
  error?: string;
  helpText?: string;
  name?: string;
  id?: string;
  loading?: boolean;
  maxTagCount?: number;
}

const LabeledSelect: React.FC<LabeledSelectProps> = ({
  label,
  placeholder = "Please select",
  value,
  onChange,
  onBlur,
  options,
  required = false,
  disabled = false,
  size = "large",
  mode,
  allowClear = true,
  showSearch = false,
  filterOption = true,
  className = "",
  error,
  helpText,
  name,
  id,
  loading = false,
  maxTagCount,
}) => {
  const selectId = id || name || label.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className={`${styles.labeledSelect} ${styles[size]} ${className}`}>
      <div className={styles.labelWrapper}>
        <label htmlFor={selectId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      </div>
      <Select
        id={selectId}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        options={options}
        disabled={disabled}
        size={size}
        mode={mode}
        allowClear={allowClear}
        showSearch={showSearch}
        filterOption={filterOption}
        loading={loading}
        maxTagCount={maxTagCount}
        className={styles.select}
        status={error ? "error" : undefined}
      />
      {(error || helpText) && (
        <div className={styles.helpText}>{error || helpText}</div>
      )}
    </div>
  );
};

export default LabeledSelect;
