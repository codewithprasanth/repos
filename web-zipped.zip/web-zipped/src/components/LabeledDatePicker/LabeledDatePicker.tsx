import React from "react";
import { DatePicker } from "antd";
import type { Dayjs } from "dayjs";
import styles from "./LabeledDatePicker.module.scss";

const { RangePicker } = DatePicker;

export interface LabeledDatePickerProps {
  label: string;
  placeholder?: string;
  value?: Dayjs | null;
  onChange?: (date: Dayjs | null, dateString: string | string[]) => void;
  required?: boolean;
  disabled?: boolean;
  size?: "large" | "middle" | "small";
  format?: string;
  showTime?: boolean | object;
  picker?: "date" | "week" | "month" | "quarter" | "year";
  allowClear?: boolean;
  className?: string;
  error?: string;
  helpText?: string;
  name?: string;
  id?: string;
  disabledDate?: (current: Dayjs) => boolean;
  showToday?: boolean;
}

export interface LabeledRangePickerProps {
  label: string;
  placeholder?: [string, string];
  value?: [Dayjs | null, Dayjs | null] | null;
  onChange?: (
    dates: [Dayjs | null, Dayjs | null] | null,
    dateStrings: [string, string]
  ) => void;
  required?: boolean;
  disabled?: boolean;
  size?: "large" | "middle" | "small";
  format?: string;
  showTime?: boolean | object;
  picker?: "date" | "week" | "month" | "quarter" | "year";
  allowClear?: boolean;
  className?: string;
  error?: string;
  helpText?: string;
  name?: string;
  id?: string;
  disabledDate?: (current: Dayjs) => boolean;
  showToday?: boolean;
  mode: "range";
}

const LabeledDatePicker: React.FC<LabeledDatePickerProps> = ({
  label,
  placeholder = "Select date",
  value,
  onChange,
  required = false,
  disabled = false,
  size = "large",
  format = "DD/MM/YYYY",
  showTime = false,
  picker = "date",
  allowClear = true,
  className = "",
  error,
  helpText,
  name,
  id,
  disabledDate,
  showToday = true,
}) => {
  const datePickerId = id || name || label.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className={`${styles.labeledDatePicker} ${styles[size]} ${className}`}>
      <div className={styles.labelWrapper}>
        <label htmlFor={datePickerId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      </div>
      <DatePicker
        id={datePickerId}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
        size={size}
        format={format}
        showTime={showTime}
        picker={picker}
        allowClear={allowClear}
        disabledDate={disabledDate}
        showToday={showToday}
        className={styles.datePicker}
        status={error ? "error" : undefined}
      />
      {(error || helpText) && (
        <div className={styles.helpText}>{error || helpText}</div>
      )}
    </div>
  );
};

export const LabeledRangePicker: React.FC<LabeledRangePickerProps> = ({
  label,
  placeholder = ["Start date", "End date"],
  value,
  onChange,
  required = false,
  disabled = false,
  size = "large",
  format = "DD/MM/YYYY",
  showTime = false,
  picker = "date",
  allowClear = true,
  className = "",
  error,
  helpText,
  name,
  id,
  disabledDate,
  showToday = true,
}) => {
  const datePickerId = id || name || label.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className={`${styles.labeledDatePicker} ${className}`}>
      <div className={styles.labelWrapper}>
        <label htmlFor={datePickerId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      </div>
      <RangePicker
        id={datePickerId}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
        size={size}
        format={format}
        showTime={showTime}
        picker={picker}
        allowClear={allowClear}
        disabledDate={disabledDate}
        showToday={showToday}
        className={styles.datePicker}
        status={error ? "error" : undefined}
      />
      {(error || helpText) && (
        <div className={styles.helpText}>{error || helpText}</div>
      )}
    </div>
  );
};

export default LabeledDatePicker;
