import { Popconfirm as AntPopconfirm } from "antd";
import type { PopconfirmProps as AntPopconfirmProps } from "antd";
import React from "react";

/**
 * Reusable Popconfirm component for consistent confirmation dialogs across the application.
 *
 * Usage:
 * ```tsx
 * import { ConfirmPopover } from '@/components/ConfirmPopover';
 *
 * <ConfirmPopover
 *   title="Are you sure you want to delete this user?"
 *   description="This action cannot be undone."
 *   onConfirm={() => handleDelete(userId)}
 * >
 *   <Button danger>Delete</Button>
 * </ConfirmPopover>
 * ```
 */

export interface ConfirmPopoverProps extends Omit<AntPopconfirmProps, "title"> {
  /** Main confirmation question */
  title: string;
  /** Optional description for additional context */
  description?: string;
  /** Confirm button text (default: "Yes") */
  okText?: string;
  /** Cancel button text (default: "No") */
  cancelText?: string;
  /** Type of action (affects button color) */
  type?: "danger" | "warning" | "info";
  children: React.ReactNode;
}

export const ConfirmPopover: React.FC<ConfirmPopoverProps> = ({
  title,
  description,
  okText = "Yes",
  cancelText = "No",
  type = "danger",
  children,
  okButtonProps,
  ...rest
}) => {
  const getOkButtonProps = () => {
    const baseProps = okButtonProps || {};

    if (type === "danger") {
      return { danger: true, ...baseProps };
    }

    return baseProps;
  };

  return (
    <AntPopconfirm
      title={title}
      description={description}
      okText={okText}
      cancelText={cancelText}
      okButtonProps={getOkButtonProps()}
      placement="topRight"
      {...rest}
    >
      {children}
    </AntPopconfirm>
  );
};

export default ConfirmPopover;
