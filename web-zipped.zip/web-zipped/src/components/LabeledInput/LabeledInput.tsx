import React from "react";
import { Input } from "antd";
import styles from "./LabeledInput.module.scss";

export interface LabeledInputProps {
  label: string;
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  size?: "large" | "middle" | "small";
  type?: "text" | "email" | "password" | "number";
  maxLength?: number;
  min?: number;
  max?: number;
  className?: string;
  error?: string;
  helpText?: string;
  name?: string;
  id?: string;
  isPriceInput?: boolean;
  decimals?: number;
}

const LabeledInput: React.FC<LabeledInputProps> = ({
  label,
  placeholder = "",
  value,
  onChange,
  onBlur,
  onKeyDown,
  required = false,
  disabled = false,
  readOnly = false,
  size = "large",
  type = "text",
  maxLength,
  min,
  max,
  className = "",
  error,
  helpText,
  name,
  id,
  isPriceInput = false,
  decimals = 2,
}) => {
  const inputId = id || name || label.toLowerCase().replace(/\s+/g, "-");

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isPriceInput) {
      onChange?.(e);
      return;
    }

    const inputValue = e.target.value;

    // Allow empty value
    if (inputValue === "") {
      onChange?.(e);
      return;
    }

    // Only allow numbers and single dot
    const regex = /^[0-9]*\.?[0-9]*$/;
    if (!regex.test(inputValue)) {
      return;
    }

    // Prevent multiple dots
    const dotCount = (inputValue.match(/\./g) || []).length;
    if (dotCount > 1) {
      return;
    }

    // Limit decimal places
    if (inputValue.includes(".")) {
      const parts = inputValue.split(".");
      if (parts[1] && parts[1].length > decimals) {
        return;
      }
    }

    onChange?.(e);
  };

  const handlePriceBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    if (isPriceInput && e.target.value && e.target.value !== "") {
      const numValue = parseFloat(e.target.value);
      if (!isNaN(numValue)) {
        // Format to specified decimal places on blur
        const formatted = numValue.toFixed(decimals);
        const syntheticEvent = {
          ...e,
          target: {
            ...e.target,
            value: formatted,
          },
        } as React.FocusEvent<HTMLInputElement>;
        onBlur?.(syntheticEvent);
      } else {
        onBlur?.(e);
      }
    } else {
      onBlur?.(e);
    }
  };

  return (
    <div className={`${styles.labeledInput} ${styles[size]} ${className}`}>
      <div className={styles.labelWrapper}>
        <label htmlFor={inputId} className={styles.label}>
          {label}
          {required && <span className={styles.required}>*</span>}
        </label>
      </div>
      <Input
        id={inputId}
        name={name}
        type={isPriceInput ? "text" : type}
        placeholder={placeholder}
        value={value}
        onChange={handlePriceChange}
        onBlur={handlePriceBlur}
        onKeyDown={onKeyDown}
        disabled={disabled}
        readOnly={readOnly}
        size={size}
        maxLength={maxLength}
        min={min}
        max={max}
        className={styles.input}
        status={error ? "error" : undefined}
        inputMode={isPriceInput ? "decimal" : undefined}
      />
      {(error || helpText) && (
        <div className={styles.helpText}>{error || helpText}</div>
      )}
    </div>
  );
};

export default LabeledInput;
