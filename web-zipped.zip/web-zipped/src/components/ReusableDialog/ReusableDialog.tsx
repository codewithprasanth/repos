import React from "react";
import { Modal } from "antd";
import ReusableButton from "../ReusableButton/ReusableButton";
import styles from "./ReusableDialog.module.scss";

export interface ReusableDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  onSubmit?: () => void;
  submitText?: string;
  cancelText?: string;
  width?: number | string;
  footer?: React.ReactNode | null;
  loading?: boolean;
  hideFooter?: boolean;
}

const ReusableDialog: React.FC<ReusableDialogProps> = ({
  open,
  onClose,
  title,
  children,
  onSubmit,
  submitText = "Submit",
  cancelText = "Cancel",
  width = 600,
  footer,
  loading = false,
  hideFooter = false,
}) => {
  const defaultFooter = hideFooter ? null : (
    <div className={styles.dialogFooter}>
      <ReusableButton variant="secondary" onClick={onClose} disabled={loading}>
        {cancelText}
      </ReusableButton>
      {onSubmit && (
        <ReusableButton variant="primary" onClick={onSubmit} disabled={loading}>
          {loading ? "Processing..." : submitText}
        </ReusableButton>
      )}
    </div>
  );

  return (
    <Modal
      open={open}
      onCancel={onClose}
      title={title}
      width={width}
      footer={footer !== undefined ? footer : defaultFooter}
      className={styles.reusableDialog}
      maskClosable={!loading}
      closable={!loading}
    >
      <div className={styles.dialogContent}>{children}</div>
    </Modal>
  );
};

export default ReusableDialog;
