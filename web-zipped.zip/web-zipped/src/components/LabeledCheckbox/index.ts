export { default } from "./LabeledCheckbox";
