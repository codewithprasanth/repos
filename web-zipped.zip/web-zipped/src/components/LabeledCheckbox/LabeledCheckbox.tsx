import React from "react";
import { Checkbox } from "antd";
import type { CheckboxProps } from "antd";
import styles from "./LabeledCheckbox.module.scss";

interface LabeledCheckboxProps extends Omit<CheckboxProps, "children"> {
  label?: string;
  className?: string;
  error?: string;
  required?: boolean;
}

const LabeledCheckbox: React.FC<LabeledCheckboxProps> = ({
  label,
  className,
  error,
  required,
  ...checkboxProps
}) => {
  return (
    <div className={`${styles.labeledCheckbox} ${className || ""}`}>
      <Checkbox
        {...checkboxProps}
        className={`${styles.checkbox} ${error ? styles.error : ""}`}
      >
        {label && (
          <span className={styles.label}>
            {label}
            {required && <span className={styles.required}>*</span>}
          </span>
        )}
      </Checkbox>
      {error && <div className={styles.errorMessage}>{error}</div>}
    </div>
  );
};

export default LabeledCheckbox;
