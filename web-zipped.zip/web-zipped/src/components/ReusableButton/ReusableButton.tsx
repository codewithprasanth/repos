import React from "react";
import { Button as AntButton } from "antd";
import type { ButtonProps as AntButtonProps } from "antd";
import styles from "./ReusableButton.module.scss";

export interface ReusableButtonProps extends Omit<AntButtonProps, "variant"> {
  variant?:
    | "primary"
    | "secondary"
    | "danger"
    | "success"
    | "warning"
    | "ghost";
  fullWidth?: boolean;
  className?: string;
}

const ReusableButton: React.FC<ReusableButtonProps> = ({
  variant = "primary",
  fullWidth = false,
  className = "",
  children,
  type,
  ...restProps
}) => {
  // Map variant to Ant Design type if not explicitly provided
  const getButtonType = (): AntButtonProps["type"] => {
    if (type) return type; // Use explicit type if provided

    switch (variant) {
      case "primary":
        return "primary";
      case "secondary":
        return "default";
      case "danger":
        return "primary";
      case "success":
        return "primary";
      case "warning":
        return "primary";
      case "ghost":
        return "dashed";
      default:
        return "primary";
    }
  };

  const buttonClasses = [
    styles.reusableButton,
    styles[variant],
    fullWidth ? styles.fullWidth : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <AntButton type={getButtonType()} className={buttonClasses} {...restProps}>
      {children}
    </AntButton>
  );
};

export default ReusableButton;
