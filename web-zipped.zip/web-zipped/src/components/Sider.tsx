import React, { useState } from "react";
import { Layout } from "antd";
import { MenuFoldOutlined, MenuUnfoldOutlined } from "@ant-design/icons";
import SideMenu from "./Sidemenu";
import logo from "../assets/logo.png";

const { Sider } = Layout;

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(window.innerWidth < 1000);

  // Responsive collapse on window resize
  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1000) {
        setCollapsed(true);
      } else {
        setCollapsed(false);
      }
    };
    window.addEventListener("resize", handleResize);
    // Initial check in case window was resized before mount
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const toggleCollapse = () => {
    setCollapsed((prev) => !prev);
  };

  return (
    <Sider
      collapsible
      collapsed={collapsed}
      trigger={null}
      width={250}
      style={{
        backgroundColor: "#fff",
        borderRight: "1px solid #f0f0f0",
        minHeight: "100vh",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: collapsed ? "center" : "space-between",
          padding: "0 16px",
          borderBottom: "1px solid #f0f0f0",
        }}
      >
        {!collapsed && (
          <div style={{ fontWeight: "bold", fontSize: 18 }}>
            <img
              src={logo}
              alt="Logo"
              style={{
                width: "70%",
              }}
            />
          </div>
        )}
        {collapsed ? (
          <MenuUnfoldOutlined
            onClick={toggleCollapse}
            style={{
              fontSize: "18px",
              color: "#2d5a5a",
              cursor: "pointer",
              padding: "8px",
              borderRadius: "6px",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(45, 90, 90, 0.1)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "transparent";
            }}
          />
        ) : (
          <MenuFoldOutlined
            onClick={toggleCollapse}
            style={{
              fontSize: "18px",
              color: "#2d5a5a",
              cursor: "pointer",
              padding: "8px",
              borderRadius: "6px",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(45, 90, 90, 0.1)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "transparent";
            }}
          />
        )}
      </div>

      <SideMenu collapsed={collapsed} />
    </Sider>
  );
};

export default Sidebar;
