import {
  DollarOutlined,
  GlobalOutlined,
  BankOutlined,
} from "@ant-design/icons";
import HomeBanner from "../../components/HomeBanner/HomeBanner";
import KPI from "../../components/KPI/KPI";
import styles from "./HomePage.module.scss";
import DashboardGraph from "../../components/DashboardGraph/DashboardGraph";
import { useSelector } from "react-redux";
import { selectUser } from "../../store/auth/auth-selector";

export default function HomePage() {
  const user = useSelector(selectUser);
  return (
    <div className={styles.homePage}>
      <HomeBanner username={user?.fullName || ""} />
      <div className={styles.kpiContainer}>
        <KPI
          icon={<GlobalOutlined />}
          title="Total Countries"
          subtitle="Assigned countries"
          value={13}
        />
        <KPI
          icon={<BankOutlined />}
          title="Company Codes"
          subtitle="Assigned company codes"
          value={33}
        />
        <KPI
          icon={<DollarOutlined />}
          title="Total Currencies"
          subtitle="Indexed today"
          value={8}
        />
      </div>
      <DashboardGraph />
    </div>
  );
}
//commenting for commit test