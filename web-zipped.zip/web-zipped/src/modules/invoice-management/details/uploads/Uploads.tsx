import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import {
  DownloadOutlined,
  EyeOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import DataTable from "../../../../components/DataTable/DataTable";
import Spinner from "../../../../components/spinner";
import {
  fetchUploads,
  selectUploads,
} from "../../../../store/invoice-management/invoice-management-slice";
import { useAppDispatch } from "../../../../store/store";
import type { DocumentItem } from "../../../../types/uploads";
import styles from "../InvoiceDetails.module.scss";

interface UploadTableData extends DocumentItem {
  key: string;
}

interface UploadsProps {
  workItemNumber: string;
  className?: string;
}

const Uploads: React.FC<UploadsProps> = ({ workItemNumber }) => {
  const dispatch = useAppDispatch();
  const { uploads, loading, error } = useSelector(selectUploads);

  const [selectedDocumentType, setSelectedDocumentType] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (workItemNumber) {
      dispatch(fetchUploads(workItemNumber));
    }
  }, [dispatch, workItemNumber]);

  // Document type options for upload
  const uploadDocumentTypeOptions = [
    { value: "Invoice", label: "Invoice" },
    { value: "PO", label: "PO" },
    { value: "GRN", label: "GRN" },
    { value: "Mail_Body", label: "Mail_Body" },
    { value: "Supporting_Doc", label: "Supporting_Doc" },
    { value: "Credit_Note", label: "Credit_Note" },
    { value: "Debit_Note", label: "Debit_Note" },
  ];

  // Handle file selection
  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  // Handle upload functionality
  const handleUpload = () => {
    console.log("Upload clicked with:", {
      documentType: selectedDocumentType,
      fileName: selectedFile?.name,
      file: selectedFile,
    });
    // TODO: Implement actual file upload logic when API is ready
  };

  // Handle view functionality
  const handleView = (record: UploadTableData) => {
    if (record.actions.canView && record.s3Url) {
      window.open(record.s3Url, "_blank");
    }
  };

  // Handle download functionality
  const handleDownload = async (record: UploadTableData) => {
    if (record.actions.canDownload && record.s3Url) {
      try {
        const response = await fetch(record.s3Url);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = record.documentName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      } catch (error) {
        console.error("Error downloading file:", error);
        // Fallback to direct link
        const link = document.createElement("a");
        link.href = record.s3Url;
        link.download = record.documentName;
        link.target = "_blank";
        link.click();
      }
    }
  };

  // Handle delete functionality
  const handleDelete = (record: UploadTableData) => {
    if (record.actions.canDelete) {
      console.log("Delete document:", record.documentId, record.documentName);
      // TODO: Implement actual delete API call when ready
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString("en-US", {
      month: "2-digit",
      day: "2-digit",
      year: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  // Define columns for Uploads table
  const uploadsColumns: ColumnsType<UploadTableData> = [
    {
      title: "Document Name",
      dataIndex: "documentName",
      key: "documentName",
      width: 200,
    },
    {
      title: "Document Type",
      dataIndex: "documentType",
      key: "documentType",
      width: 180,
    },
    {
      title: "Uploaded By",
      dataIndex: "uploadedBy",
      key: "uploadedBy",
      width: 140,
      render: (uploadedBy: { userId: string; name: string }) => uploadedBy.name,
    },
    {
      title: "Uploaded On",
      dataIndex: "uploadedOn",
      key: "uploadedOn",
      width: 160,
      render: (uploadedOn: string) => formatDate(uploadedOn),
    },
    {
      title: "Actions",
      key: "actions",
      width: 120,
      align: "center",
      render: (_, record: UploadTableData) => (
        <div className={styles.actionButtons}>
          <DownloadOutlined
            className={`${styles.actionIcon} ${
              !record.actions.canDownload ? styles.disabled : ""
            }`}
            title="Download"
            onClick={() => handleDownload(record)}
            style={{
              cursor: record.actions.canDownload ? "pointer" : "not-allowed",
            }}
          />
          <EyeOutlined
            className={`${styles.actionIcon} ${
              !record.actions.canView ? styles.disabled : ""
            }`}
            title="View"
            onClick={() => handleView(record)}
            style={{
              cursor: record.actions.canView ? "pointer" : "not-allowed",
            }}
          />
          <DeleteOutlined
            className={`${styles.actionIcon} ${
              !record.actions.canDelete ? styles.disabled : ""
            }`}
            title="Delete"
            onClick={() => handleDelete(record)}
            style={{
              cursor: record.actions.canDelete ? "pointer" : "not-allowed",
            }}
          />
        </div>
      ),
    },
  ];

  // Prepare table data
  const tableData: UploadTableData[] = uploads.map((upload) => ({
    ...upload,
    key: upload.documentId,
  }));

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return <div className={styles.error}>Error loading uploads: {error}</div>;
  }

  return (
    <div className={styles.uploadsTab}>
      <div className={styles.uploadForm}>
        <div className={styles.uploadFormRow}>
          <div className={styles.uploadFormCol}>
            <LabeledSelect
              label="Select Document Type"
              value={selectedDocumentType}
              onChange={(value) => setSelectedDocumentType(value as string)}
              options={uploadDocumentTypeOptions}
              required
              placeholder="Select document type"
              className={styles.documentTypeSelect}
            />
          </div>
          <div className={styles.uploadFormCol}>
            <label className={styles.fileSelectLabel}>Select File</label>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              style={{ display: "none" }}
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"
            />
            <div className={styles.fileSelectRow}>
              <ReusableButton
                variant="secondary"
                onClick={handleFileSelect}
                className={styles.selectFileButton}
              >
                Choose File
              </ReusableButton>
              {selectedFile && (
                <span className={styles.selectedFileName}>
                  {selectedFile.name}
                </span>
              )}
            </div>
          </div>
          <div className={styles.uploadFormCol}>
            <label className={styles.uploadButtonLabel}>&nbsp;</label>
            <ReusableButton
              variant="primary"
              className={styles.uploadButton}
              onClick={handleUpload}
              disabled={!selectedDocumentType || !selectedFile}
            >
              Upload
            </ReusableButton>
          </div>
        </div>
        <div className={styles.uploadHint}>Maximum file size: 10MB</div>
      </div>
      {tableData.length === 0 ? (
        <div style={{ padding: "20px", textAlign: "center", color: "#666" }}>
          No documents uploaded yet
        </div>
      ) : (
        <DataTable<UploadTableData>
          data={tableData}
          columns={uploadsColumns}
          pagination={false}
          size="middle"
          bordered={false}
          className={styles.uploadsTable}
        />
      )}
    </div>
  );
};

export default Uploads;
