import { Card, Row, Col } from "antd";
import { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import dayjs from "dayjs";
import Spinner from "../../../../components/spinner";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import LabeledDatePicker from "../../../../components/LabeledDatePicker/LabeledDatePicker";
import {
  fetchAdditionalDetails,
  selectAdditionalDetails,
} from "../../../../store/invoice-management/invoice-management-slice";
import type { RootDispatch } from "../../../../store/store";
import type { AdditionalDetails } from "../../../../types/invoice-management";
import styles from "../InvoiceDetails.module.scss";

export default function AdditionalDetails() {
  const dispatch = useDispatch<RootDispatch>();
  const { id: workItemNumber } = useParams<{ id: string }>();
  const { additionalDetails, loading, error } = useSelector(
    selectAdditionalDetails
  );

  // Local state for form field changes
  const [fieldChanges, setFieldChanges] = useState<Partial<AdditionalDetails>>(
    {}
  );

  // Merge additionalDetails with field changes
  const formData = useMemo(() => {
    if (!additionalDetails) return fieldChanges;
    return { ...additionalDetails, ...fieldChanges };
  }, [additionalDetails, fieldChanges]);

  // Fetch additional details on component mount
  useEffect(() => {
    if (workItemNumber) {
      dispatch(fetchAdditionalDetails(workItemNumber));
    }
  }, [dispatch, workItemNumber]);

  // Handle input change for nested fields
  const handleInputChange = (
    path: string,
    value: string | number | boolean
  ) => {
    setFieldChanges((prev) => {
      const keys = path.split(".");
      const updated = { ...prev } as Partial<AdditionalDetails>;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let current: Record<string, any> = updated as Record<string, any>;

      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current[keys[i]] = { ...current[keys[i]] };
        current = current[keys[i]];
      }

      current[keys[keys.length - 1]] = value;
      return updated;
    });
  };

  // Handle date change
  const handleDateChange = (path: string, date: dayjs.Dayjs | null) => {
    const dateString = date ? date.format("YYYY-MM-DD") : null;
    handleInputChange(path, dateString as string);
  };

  // Options for dropdowns
  const reportingCountryOptions = [
    { label: "India", value: "India" },
    { label: "United States", value: "United States" },
    { label: "United Kingdom", value: "United Kingdom" },
  ];

  const currencyOptions = [
    { label: "INR", value: "INR" },
    { label: "USD", value: "USD" },
    { label: "EUR", value: "EUR" },
    { label: "GBP", value: "GBP" },
  ];

  const paymentBlockOptions = [
    { label: "Yes", value: "Y" },
    { label: "No", value: "N" },
  ];

  const paymentMethodOptions = [
    { label: "Bank Transfer", value: "BANK_TRANSFER" },
    { label: "Check", value: "CHECK" },
    { label: "Cash", value: "CASH" },
    { label: "Wire Transfer", value: "WIRE_TRANSFER" },
  ];

  const paymentStatusOptions = [
    { label: "Pending", value: "PENDING" },
    { label: "Paid", value: "PAID" },
    { label: "Failed", value: "FAILED" },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        <p>Error: {error}</p>
      </div>
    );
  }

  if (!additionalDetails) {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        <p>No additional details available</p>
      </div>
    );
  }

  return (
    <div className={styles.quickOverviewTab}>
      <Row gutter={[24, 24]}>
        <Col span={24}>
          <Card className={styles.detailsCard}>
            <Row gutter={[16, 8]}>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Reporting Country"
                  value={formData.currency?.reportingCountry || ""}
                  onChange={(value) =>
                    handleInputChange(
                      "currency.reportingCountry",
                      value as string
                    )
                  }
                  options={reportingCountryOptions}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Exchange Rate"
                  value={formData.currency?.exchangeRate?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "currency.exchangeRate",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Doc Cur"
                  value={formData.currency?.docCurrency || ""}
                  onChange={(value) =>
                    handleInputChange("currency.docCurrency", value as string)
                  }
                  options={currencyOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Local Cur"
                  value={formData.currency?.localCurrency || ""}
                  onChange={(value) =>
                    handleInputChange("currency.localCurrency", value as string)
                  }
                  options={currencyOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Discount"
                  value={formData.financial?.discount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "financial.discount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  isPriceInput
                  decimals={2}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Reference 1"
                  value={formData.financial?.reference1 || ""}
                  onChange={(e) =>
                    handleInputChange("financial.reference1", e.target.value)
                  }
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Reference 2"
                  value={formData.financial?.reference2 || ""}
                  onChange={(e) =>
                    handleInputChange("financial.reference2", e.target.value)
                  }
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Reference 3"
                  value={formData.financial?.reference3 || ""}
                  onChange={(e) =>
                    handleInputChange("financial.reference3", e.target.value)
                  }
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Special GL Indicator"
                  value={formData.posting?.specialGLIndicator || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "posting.specialGLIndicator",
                      e.target.value
                    )
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Posting Document number"
                  value={formData.posting?.postingDocumentNumber || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "posting.postingDocumentNumber",
                      e.target.value
                    )
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Posting date"
                  value={
                    formData.posting?.postingDate
                      ? dayjs(formData.posting.postingDate)
                      : null
                  }
                  onChange={(date) =>
                    handleDateChange("posting.postingDate", date)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Baseline Date"
                  value={
                    formData.posting?.baselineDate
                      ? dayjs(formData.posting.baselineDate)
                      : null
                  }
                  onChange={(date) =>
                    handleDateChange("posting.baselineDate", date)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Due Date"
                  value={
                    formData.posting?.dueDate
                      ? dayjs(formData.posting.dueDate)
                      : null
                  }
                  onChange={(date) => handleDateChange("posting.dueDate", date)}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Document header Text"
                  value={formData.posting?.documentHeaderText || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "posting.documentHeaderText",
                      e.target.value
                    )
                  }
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Payment Block"
                  value={formData.payment?.paymentBlock || ""}
                  onChange={(value) =>
                    handleInputChange("payment.paymentBlock", value as string)
                  }
                  options={paymentBlockOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Part Bank"
                  value={formData.payment?.partnerBank || ""}
                  onChange={(e) =>
                    handleInputChange("payment.partnerBank", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Option"
                  value={formData.asset?.serialNumber || ""}
                  onChange={(e) =>
                    handleInputChange("asset.serialNumber", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Serial No"
                  value={formData.asset?.assetNumber || ""}
                  onChange={(e) =>
                    handleInputChange("asset.assetNumber", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Asset No"
                  value={formData.asset?.transactionType || ""}
                  onChange={(e) =>
                    handleInputChange("asset.transactionType", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Transaction Type"
                  value={formData.asset?.transactionType || ""}
                  onChange={(e) =>
                    handleInputChange("asset.transactionType", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Value Date"
                  value={
                    formData.asset?.valueDate
                      ? dayjs(formData.asset.valueDate)
                      : null
                  }
                  onChange={(date) => handleDateChange("asset.valueDate", date)}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Material Posting"
                  value={formData.asset?.materialPosting || ""}
                  onChange={(e) =>
                    handleInputChange("asset.materialPosting", e.target.value)
                  }
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Condition Amount"
                  value={formData.condition?.conditionAmount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "condition.conditionAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  isPriceInput
                  decimals={2}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Condition Amount Tax"
                  value={
                    formData.condition?.conditionTaxAmount?.toString() || ""
                  }
                  onChange={(e) =>
                    handleInputChange(
                      "condition.conditionTaxAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  isPriceInput
                  decimals={2}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="ERP Payment Status"
                  value={formData.erpStatus?.paymentStatus || ""}
                  onChange={(value) =>
                    handleInputChange(
                      "erpStatus.paymentStatus",
                      value as string
                    )
                  }
                  options={paymentStatusOptions}
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="ERP Payment date"
                  value={
                    formData.erpStatus?.paymentDate
                      ? dayjs(formData.erpStatus.paymentDate)
                      : null
                  }
                  onChange={(date) =>
                    handleDateChange("erpStatus.paymentDate", date)
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="ERP Posted By"
                  value={formData.erpStatus?.postedBy || ""}
                  onChange={(e) =>
                    handleInputChange("erpStatus.postedBy", e.target.value)
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Payment method"
                  value={formData.payment?.paymentMethod || ""}
                  onChange={(value) =>
                    handleInputChange("payment.paymentMethod", value as string)
                  }
                  options={paymentMethodOptions}
                  required
                />
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
