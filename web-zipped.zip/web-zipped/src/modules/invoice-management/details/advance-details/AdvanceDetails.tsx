import React from "react";
import styles from "../InvoiceDetails.module.scss";

export default function AdvanceDetails() {
  return (
    <div className={styles.advanceDetailsTab}>
      <div>Advance Details content goes here</div>
    </div>
  );
}
