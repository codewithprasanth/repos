import { useState } from "react";
import { useParams } from "react-router-dom";
import { EyeOutlined } from "@ant-design/icons";
import ReusableTab from "../../../components/ReusableTab/ReusableTab";
import type { TabItem } from "../../../components/ReusableTab/ReusableTab";
import ReusableButton from "../../../components/ReusableButton/ReusableButton";
import IconActionButton from "../../../components/IconActionButton/IconActionButton";
import DocumentPreviewModal from "../../../components/DocumentPreviewModal/DocumentPreviewModal";
import ReusableDialog from "../../../components/ReusableDialog/ReusableDialog";
import ThreePointButtons from "../../../components/ThreePointButtons/ThreePointButtons";
import type { ThreePointMenuItem } from "../../../components/ThreePointButtons/ThreePointButtons";
import Comments from "./Comments/Comments";
import ApprovalSubmissionForm from "./approval-submission-form/ApprovalSubmissionForm";
import type { ApprovalSubmissionFormData } from "./approval-submission-form/ApprovalSubmissionForm";
import SendToQueryForm from "./send-to-query-form/SendToQueryForm";
import type { SendToQueryFormData } from "./send-to-query-form/SendToQueryForm";
import CancelInvoiceForm from "./cancel-invoice-form/CancelInvoiceForm";
import type { CancelInvoiceFormData } from "./cancel-invoice-form/CancelInvoiceForm";
import showMessage from "../../../components/Message";
import WorkflowTimeline from "./WorkflowTimeline/WorkflowTimeline";
import type { WorkflowStep } from "./WorkflowTimeline/WorkflowTimeline";
import QuickOverview from "./quick-overview/QuickOverview";
import AdditionalDetails from "./additional-details/AdditionalDetails";
import DuplicateValidation from "./duplicate-validation/DuplicateValidation";
import BankDetails from "./bank-details/BankDetails";
import Uploads from "./uploads/Uploads";
import Approvers from "./approvers/Approvers";
import styles from "./InvoiceDetails.module.scss";

export default function InvoiceDetails() {
  const { id: workItemNumber } = useParams<{ id: string }>();
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isApprovalDialogOpen, setIsApprovalDialogOpen] = useState(false);
  const [approvalFormSubmit, setApprovalFormSubmit] = useState<
    (() => void) | null
  >(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isQueryDialogOpen, setIsQueryDialogOpen] = useState(false);
  const [queryFormSubmit, setQueryFormSubmit] = useState<(() => void) | null>(
    null
  );
  const [isQuerySubmitting, setIsQuerySubmitting] = useState(false);
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const [cancelFormSubmit, setCancelFormSubmit] = useState<(() => void) | null>(
    null
  );
  const [isCancelSubmitting, setIsCancelSubmitting] = useState(false);

  // Sample workflow data
  const workflowSteps: WorkflowStep[] = [
    {
      id: "1",
      status: "INDEXING-CLAIM",
      title: "USA_AP_U1",
      timestamp: "5/10/25, 6:52 PM",
      isCompleted: true,
    },
    {
      id: "2",
      status: "REVOKE",
      title: "Indexer",
      timestamp: "5/27/25, 4:20 PM",
      isCompleted: true,
    },
    {
      id: "3",
      status: "INDEXING-CLAIM",
      title: "Indexer",
      timestamp: "5/29/25, 4:14 PM",
      isCompleted: true,
    },
    {
      id: "4",
      status: "VALIDATION",
      title: "Validator",
      timestamp: "5/30/25, 10:30 AM",
      isCompleted: true,
    },
    {
      id: "5",
      status: "APPROVAL",
      title: "Manager Review",
      timestamp: "6/2/25, 2:15 PM",
      isCompleted: true,
    },
    {
      id: "6",
      status: "PROCESSING",
      title: "Finance Team",
      timestamp: "6/5/25, 9:45 AM",
      isCompleted: true,
      isActive: true,
    },
    {
      id: "7",
      status: "PAYMENT-READY",
      title: "Payment Queue",
      timestamp: "",
      isCompleted: false,
    },
    {
      id: "8",
      status: "COMPLETED",
      title: "Final Archive",
      timestamp: "",
      isCompleted: false,
    },
  ];

  const items: TabItem[] = [
    {
      key: "quickOverview",
      label: "Quick Overview",
      children: <QuickOverview />,
    },
    {
      key: "additionalDetails",
      label: "Additional Details",
      children: <AdditionalDetails />,
    },
    {
      key: "duplicateValidation",
      label: "Duplicate Validation",
      children: <DuplicateValidation />,
    },
    // {
    //   key: "advanceDetails",
    //   label: "Advance Details",
    //   children: <AdvanceDetails />,
    // },
    {
      key: "bank",
      label: "Bank Details",
      children: <BankDetails />,
    },
    {
      key: "comments",
      label: "Comments",
      children: workItemNumber ? (
        <Comments
          workItemNumber={workItemNumber}
          className={styles.commentsTab}
        />
      ) : null,
    },
    {
      key: "workflow",
      label: "Workflow History",
      children: (
        <WorkflowTimeline
          steps={workflowSteps}
          className={styles.workflowTab}
        />
      ),
    },
    {
      key: "uploads",
      label: "Uploads",
      children: <Uploads workItemNumber={workItemNumber!} />,
    },
    {
      key: "approvers",
      label: "Approvers",
      children: <Approvers />,
    },
    // {
    //   key: "simulate",
    //   label: "Simulate",
    //   children: <Simulate />,
    // },
  ];

  const handleSave = () => {
    // TODO: Implement save functionality
    console.log("Save clicked");
  };

  const handlePostToERP = () => {
    // TODO: Implement post to ERP functionality
    console.log("Post to ERP clicked");
  };

  const handleSubmitForApproval = () => {
    setIsApprovalDialogOpen(true);
  };

  const handleCloseApprovalDialog = () => {
    setIsApprovalDialogOpen(false);
    setApprovalFormSubmit(null);
  };

  const handleApprovalFormReady = (submitFn: () => void) => {
    setApprovalFormSubmit(() => submitFn);
  };

  const handleApprovalDialogSubmit = () => {
    if (approvalFormSubmit) {
      approvalFormSubmit();
    }
  };

  const handleApprovalFormSubmit = async (data: ApprovalSubmissionFormData) => {
    try {
      setIsSubmitting(true);
      console.log("Approval submission data:", {
        workItemNumber,
        comments: data.comments,
      });

      // TODO: Replace with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      showMessage.success("Invoice submitted for approval successfully");
      handleCloseApprovalDialog();
    } catch (error) {
      console.error("Error submitting for approval:", error);
      showMessage.error("Failed to submit for approval. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendToQuery = () => {
    setIsQueryDialogOpen(true);
  };

  const handleCloseQueryDialog = () => {
    setIsQueryDialogOpen(false);
    setQueryFormSubmit(null);
  };

  const handleQueryFormReady = (submitFn: () => void) => {
    setQueryFormSubmit(() => submitFn);
  };

  const handleQueryDialogSubmit = () => {
    if (queryFormSubmit) {
      queryFormSubmit();
    }
  };

  const handleQueryFormSubmit = async (data: SendToQueryFormData) => {
    try {
      setIsQuerySubmitting(true);
      console.log("Send to query data:", {
        workItemNumber,
        queryUser: data.queryUser,
        queryType: data.queryType,
        autoComments: data.autoComments,
      });

      // TODO: Replace with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      showMessage.success("Invoice sent to query successfully");
      handleCloseQueryDialog();
    } catch (error) {
      console.error("Error sending to query:", error);
      showMessage.error("Failed to send to query. Please try again.");
    } finally {
      setIsQuerySubmitting(false);
    }
  };

  const handleCancelInvoice = () => {
    setIsCancelDialogOpen(true);
  };

  const handleCloseCancelDialog = () => {
    setIsCancelDialogOpen(false);
    setCancelFormSubmit(null);
  };

  const handleCancelFormReady = (submitFn: () => void) => {
    setCancelFormSubmit(() => submitFn);
  };

  const handleCancelDialogSubmit = () => {
    if (cancelFormSubmit) {
      cancelFormSubmit();
    }
  };

  const handleCancelFormSubmit = async (data: CancelInvoiceFormData) => {
    try {
      setIsCancelSubmitting(true);
      console.log("Cancel invoice data:", {
        workItemNumber,
        reason: data.reason,
        comments: data.comments,
      });

      // TODO: Replace with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      showMessage.success("Invoice cancelled successfully");
      handleCloseCancelDialog();
    } catch (error) {
      console.error("Error cancelling invoice:", error);
      showMessage.error("Failed to cancel invoice. Please try again.");
    } finally {
      setIsCancelSubmitting(false);
    }
  };

  const handlePreview = () => {
    setIsPreviewOpen(true);
  };

  const handleClosePreview = () => {
    setIsPreviewOpen(false);
  };

  const moreMenuItems: ThreePointMenuItem[] = [
    {
      key: "sendToQuery",
      label: "Send to query",
      onClick: handleSendToQuery,
      visible: true,
    },
    {
      key: "cancel",
      label: "Cancel",
      onClick: handleCancelInvoice,
      visible: true,
      danger: true,
    },
  ];

  return (
    <div className={styles.invoiceDetails}>
      <div className={styles.actionRow}>
        <IconActionButton
          icon={<EyeOutlined />}
          tooltip="Preview Document"
          onClick={handlePreview}
        />
        <ReusableButton variant="primary" onClick={handleSave}>
          Save
        </ReusableButton>
        <ReusableButton variant="primary" onClick={handlePostToERP}>
          Post to ERP
        </ReusableButton>
        <ReusableButton variant="primary" onClick={handleSubmitForApproval}>
          Submit for approval
        </ReusableButton>
        <ThreePointButtons items={moreMenuItems} />
      </div>
      <ReusableTab
        defaultActiveKey="header"
        items={items}
        className={styles.invoiceTabs}
      />

      <DocumentPreviewModal
        open={isPreviewOpen}
        onClose={handleClosePreview}
        documentUrl="https://api.slingacademy.com/public/sample-photos/1.jpeg"
        // documentUrl="https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf"
        documentType="pdf"
        title="Invoice Document Preview"
      />

      <ReusableDialog
        open={isApprovalDialogOpen}
        onClose={handleCloseApprovalDialog}
        title="Submit for Approval"
        onSubmit={handleApprovalDialogSubmit}
        submitText="Submit"
        cancelText="Cancel"
        width={600}
        loading={isSubmitting}
      >
        <ApprovalSubmissionForm
          onSubmit={handleApprovalFormSubmit}
          onFormReady={handleApprovalFormReady}
        />
      </ReusableDialog>

      <ReusableDialog
        open={isQueryDialogOpen}
        onClose={handleCloseQueryDialog}
        title="Send to Query"
        onSubmit={handleQueryDialogSubmit}
        submitText="Send"
        cancelText="Cancel"
        width={600}
        loading={isQuerySubmitting}
      >
        <SendToQueryForm
          onSubmit={handleQueryFormSubmit}
          onFormReady={handleQueryFormReady}
        />
      </ReusableDialog>

      <ReusableDialog
        open={isCancelDialogOpen}
        onClose={handleCloseCancelDialog}
        title="Cancel Invoice"
        onSubmit={handleCancelDialogSubmit}
        submitText="Cancel Invoice"
        cancelText="Close"
        width={600}
        loading={isCancelSubmitting}
      >
        <CancelInvoiceForm
          onSubmit={handleCancelFormSubmit}
          onFormReady={handleCancelFormReady}
        />
      </ReusableDialog>
    </div>
  );
}
