import React, { useState } from "react";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import styles from "../InvoiceDetails.module.scss";

export default function DuplicateValidation() {
  // Duplicate validation state
  const [duplicateCategory, setDuplicateCategory] = useState("");
  const [duplicateWorkItemId, setDuplicateWorkItemId] = useState("");

  const duplicateCategoryOptions = [
    { value: "Invoice Number", label: "Invoice Number" },
    { value: "Vendor Code", label: "Vendor Code" },
    { value: "Amount", label: "Amount" },
    { value: "Date", label: "Date" },
  ];

  return (
    <div className={styles.invoiceDetailsForm}>
      <div className={styles.formRow}>
        <div className={styles.formCol}>
          <LabeledSelect
            label="Duplicate Category"
            value={duplicateCategory}
            onChange={(value) => setDuplicateCategory(value as string)}
            options={duplicateCategoryOptions}
            className={styles.formField}
            disabled
          />
        </div>
        <div className={styles.formCol}>
          <LabeledInput
            label="Duplicate Work Item Id"
            value={duplicateWorkItemId}
            onChange={(e) => setDuplicateWorkItemId(e.target.value)}
            className={styles.formField}
            disabled
          />
        </div>
        <div className={styles.formCol}></div>
        <div className={styles.formCol}></div>
      </div>
    </div>
  );
}
