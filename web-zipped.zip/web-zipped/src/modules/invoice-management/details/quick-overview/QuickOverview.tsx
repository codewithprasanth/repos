import { Card, Row, Col } from "antd";
import { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import type { ColumnsType } from "antd/es/table";
import dayjs from "dayjs";
import Spinner from "../../../../components/spinner";
import RulesTimeline from "../../../../components/RulesTimeline/RulesTimeline";
import type { TimelineRule } from "../../../../components/RulesTimeline/RulesTimeline";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import LabeledDatePicker from "../../../../components/LabeledDatePicker/LabeledDatePicker";
import DataTable from "../../../../components/DataTable/DataTable";
import {
  fetchInvoiceDetail,
  selectInvoiceDetail,
} from "../../../../store/invoice-management/invoice-management-slice";
import type { RootDispatch } from "../../../../store/store";
import type {
  InvoiceDetail,
  InvoiceLineItem,
} from "../../../../types/invoice-management";
import styles from "../InvoiceDetails.module.scss";

export default function QuickOverview() {
  const dispatch = useDispatch<RootDispatch>();
  const { id: workItemNumber } = useParams<{ id: string }>();
  const { invoiceDetail, lineItems, loading, error } =
    useSelector(selectInvoiceDetail);

  // Local state for form field changes
  const [fieldChanges, setFieldChanges] = useState<Partial<InvoiceDetail>>({});

  // Merge invoiceDetail with field changes
  const formData = useMemo(() => {
    if (!invoiceDetail) return fieldChanges;
    return { ...invoiceDetail, ...fieldChanges };
  }, [invoiceDetail, fieldChanges]);

  // Timeline rules data
  const rulesData: TimelineRule[] = [
    { title: "Touchless Posting Check", status: "success", message: "Success" },
    { title: "Extraction Check", status: "success", message: "Success" },
    { title: "Baseline Check", status: "failed", message: "Failed" },
    { title: "GL Coding", status: "success", message: "Success" },
  ];

  // Fetch invoice detail on component mount
  useEffect(() => {
    if (workItemNumber) {
      dispatch(fetchInvoiceDetail(workItemNumber));
    }
  }, [dispatch, workItemNumber]);

  // Handle input change for nested fields
  const handleInputChange = (path: string, value: string | number) => {
    setFieldChanges((prev) => {
      const keys = path.split(".");
      const updated = { ...prev } as Partial<InvoiceDetail>;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let current: Record<string, any> = updated as Record<string, any>;

      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current[keys[i]] = { ...current[keys[i]] };
        current = current[keys[i]];
      }

      current[keys[keys.length - 1]] = value;
      return updated;
    });
  };

  // Handle date change
  const handleDateChange = (field: string, date: dayjs.Dayjs | null) => {
    handleInputChange(field, date ? date.format("YYYY-MM-DD") : "");
  };

  // Line items table columns
  const lineItemColumns: ColumnsType<InvoiceLineItem> = [
    {
      title: "#",
      dataIndex: "lineNumber",
      key: "lineNumber",
      width: 60,
      fixed: "left",
      align: "center",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 100,
      fixed: "left",
    },
    {
      title: "PO Number",
      dataIndex: "poNumber",
      key: "poNumber",
      width: 120,
    },
    {
      title: "PO Line Item",
      dataIndex: "poLineItem",
      key: "poLineItem",
      width: 100,
    },
    {
      title: "Material #",
      dataIndex: "materialNumber",
      key: "materialNumber",
      width: 120,
    },
    {
      title: "Material Description",
      dataIndex: "materialDescription",
      key: "materialDescription",
      width: 200,
    },
    {
      title: "PO Qty",
      dataIndex: "poQty",
      key: "poQty",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "PO Price",
      dataIndex: "poPrice",
      key: "poPrice",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "PO Amount",
      dataIndex: "poAmount",
      key: "poAmount",
      width: 120,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "GRN Qty",
      dataIndex: "grnQty",
      key: "grnQty",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "GR Price",
      dataIndex: "grPrice",
      key: "grPrice",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "GRN Amount",
      dataIndex: "grnAmount",
      key: "grnAmount",
      width: 120,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "GRN Number",
      dataIndex: "grnNumber",
      key: "grnNumber",
      width: 120,
    },
    {
      title: "Inv Qty",
      dataIndex: "invQty",
      key: "invQty",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "Inv Price",
      dataIndex: "invPrice",
      key: "invPrice",
      width: 100,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "Invoice Amount",
      dataIndex: "invoiceAmount",
      key: "invoiceAmount",
      width: 120,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "UOM",
      dataIndex: "uom",
      key: "uom",
      width: 80,
      align: "center",
    },
    {
      title: "GL Code",
      dataIndex: "glCode",
      key: "glCode",
      width: 100,
    },
    {
      title: "GL Code Desc",
      dataIndex: "glCodeDesc",
      key: "glCodeDesc",
      width: 150,
    },
    {
      title: "Business Area",
      dataIndex: "businessArea",
      key: "businessArea",
      width: 120,
    },
    {
      title: "Cost Center",
      dataIndex: "costCenter",
      key: "costCenter",
      width: 100,
    },
    {
      title: "Profit Center",
      dataIndex: "profitCenter",
      key: "profitCenter",
      width: 100,
    },
    {
      title: "WBS",
      dataIndex: "wbs",
      key: "wbs",
      width: 100,
    },
    {
      title: "Tax Code",
      dataIndex: "taxCode",
      key: "taxCode",
      width: 100,
    },
    {
      title: "Tax Amount",
      dataIndex: "taxAmount",
      key: "taxAmount",
      width: 120,
      align: "right",
      render: (value: number) => value?.toFixed(2),
    },
    {
      title: "Buyer",
      dataIndex: "buyer",
      key: "buyer",
      width: 120,
    },
    {
      title: "PO Requestioner",
      dataIndex: "poRequestioner",
      key: "poRequestioner",
      width: 150,
    },
    {
      title: "Plant",
      dataIndex: "plant",
      key: "plant",
      width: 100,
    },
    {
      title: "Text",
      dataIndex: "text",
      key: "text",
      width: 200,
    },
  ];

  // Document type and classification options
  const documentTypeOptions = [
    { label: "Standard Invoice", value: "Standard Invoice" },
    { label: "Credit Note", value: "Credit Note" },
    { label: "Debit Note", value: "Debit Note" },
  ];

  const classificationOptions = [
    { label: "PO", value: "PO" },
    { label: "Non-PO", value: "Non-PO" },
    { label: "GR Based", value: "GR Based" },
  ];

  const invoiceTypeOptions = [
    { label: "Standard", value: "Standard" },
    { label: "Credit", value: "Credit" },
    { label: "Debit", value: "Debit" },
  ];

  const currencyOptions = [
    { label: "INR", value: "INR" },
    { label: "USD", value: "USD" },
    { label: "EUR", value: "EUR" },
    { label: "GBP", value: "GBP" },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        <p>Error: {error}</p>
      </div>
    );
  }

  if (!invoiceDetail) {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        <p>No invoice data available</p>
      </div>
    );
  }

  return (
    <div className={styles.quickOverviewTab}>
      <Row gutter={[24, 24]}>
        {/* Left Side - Rules Execution Timeline */}
        <Col xs={24} sm={24} md={6} lg={6} xl={6}>
          <Card
            title="Rules Execution Timeline"
            className={styles.timelineCard}
          >
            <RulesTimeline data={rulesData} />
          </Card>
        </Col>

        {/* Right Side - Input Fields */}
        <Col xs={24} sm={24} md={18} lg={18} xl={18}>
          {/* General Info */}
          <Card title="General Info" className={styles.detailsCard}>
            <Row gutter={[16, 8]}>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Work Id"
                  value={formData.workId || ""}
                  onChange={(e) => handleInputChange("workId", e.target.value)}
                  disabled
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Company Code"
                  value={formData.entity?.companyCode || ""}
                  onChange={(e) =>
                    handleInputChange("entity.companyCode", e.target.value)
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Entity Name"
                  value={formData.entity?.entityName || ""}
                  onChange={(e) =>
                    handleInputChange("entity.entityName", e.target.value)
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Location"
                  value={formData.entity?.location || ""}
                  onChange={(e) =>
                    handleInputChange("entity.location", e.target.value)
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Initiator Email Id"
                  value={formData.assignment?.assignedToEmail || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "assignment.assignedToEmail",
                      e.target.value
                    )
                  }
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Classification"
                  value={formData.classification || ""}
                  onChange={(value) =>
                    handleInputChange("classification", value as string)
                  }
                  options={classificationOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Document Type"
                  value={formData.documentType || ""}
                  onChange={(value) =>
                    handleInputChange("documentType", value as string)
                  }
                  options={documentTypeOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Posting date"
                  value={
                    formData.postingDate ? dayjs(formData.postingDate) : null
                  }
                  onChange={(date) => handleDateChange("postingDate", date)}
                  required
                />
              </Col>
            </Row>
          </Card>

          {/* Vendor Details */}
          <Card
            title="Vendor Details"
            className={styles.detailsCard}
            style={{ marginTop: 24 }}
          >
            <Row gutter={[16, 8]}>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Vendor Name"
                  value={formData.vendor?.vendorName || ""}
                  onChange={(e) =>
                    handleInputChange("vendor.vendorName", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Vendor Code"
                  value={formData.vendor?.vendorCode || ""}
                  onChange={(e) =>
                    handleInputChange("vendor.vendorCode", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Vendor PAN/ GST/ TIN"
                  value={formData.vendor?.vendorTaxId || ""}
                  onChange={(e) =>
                    handleInputChange("vendor.vendorTaxId", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Vendor Payment terms"
                  value={formData.vendor?.paymentTerms || ""}
                  onChange={(e) =>
                    handleInputChange("vendor.paymentTerms", e.target.value)
                  }
                  required
                />
              </Col>
            </Row>
          </Card>

          {/* Invoice Details */}
          <Card
            title="Invoice Details"
            className={styles.detailsCard}
            style={{ marginTop: 24 }}
          >
            <Row gutter={[16, 8]}>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Invoice number"
                  value={formData.invoiceNumber || ""}
                  onChange={(e) =>
                    handleInputChange("invoiceNumber", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Invoice Date"
                  value={
                    formData.invoiceDate ? dayjs(formData.invoiceDate) : null
                  }
                  onChange={(date) => handleDateChange("invoiceDate", date)}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Invoice Currency"
                  value={formData.currency || ""}
                  onChange={(value) =>
                    handleInputChange("currency", value as string)
                  }
                  options={currencyOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledDatePicker
                  label="Invoice receipt date"
                  value={
                    formData.receiptDate ? dayjs(formData.receiptDate) : null
                  }
                  onChange={(date) => handleDateChange("receiptDate", date)}
                  required
                  disabled
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledSelect
                  label="Invoice Type"
                  value={formData.invoiceType || ""}
                  onChange={(value) =>
                    handleInputChange("invoiceType", value as string)
                  }
                  options={invoiceTypeOptions}
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Total Amount"
                  value={formData.amounts?.totalAmount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "amounts.totalAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  required
                  isPriceInput
                  decimals={2}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="PO number"
                  value={formData.poDetails?.poNumber || ""}
                  onChange={(e) =>
                    handleInputChange("poDetails.poNumber", e.target.value)
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Assignment"
                  value={formData.assignment?.assignedToName || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "assignment.assignedToName",
                      e.target.value
                    )
                  }
                />
              </Col>
            </Row>
          </Card>

          {/* Other Details */}
          <Card
            title="Other Details"
            className={styles.detailsCard}
            style={{ marginTop: 24 }}
          >
            <Row gutter={[16, 8]}>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Vendor Line Item text"
                  value={formData.vendor?.vendorLineItemText || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "vendor.vendorLineItemText",
                      e.target.value
                    )
                  }
                  required
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Base Amount"
                  value={formData.amounts?.baseAmount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "amounts.baseAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  isPriceInput
                  decimals={2}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Freight/ Conditions"
                  value={formData.amounts?.freightAmount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "amounts.freightAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  required
                  isPriceInput
                  decimals={2}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <LabeledInput
                  label="Unplanned Delivery cost"
                  value={formData.amounts?.discountAmount?.toString() || ""}
                  onChange={(e) =>
                    handleInputChange(
                      "amounts.discountAmount",
                      parseFloat(e.target.value) || 0
                    )
                  }
                  isPriceInput
                  decimals={2}
                />
              </Col>
            </Row>
          </Card>

          {/* Line Items Table */}
          <Card
            title="Line Items"
            className={styles.detailsCard}
            style={{ marginTop: 24 }}
          >
            <DataTable
              data={lineItems || []}
              columns={lineItemColumns}
              size="small"
              loading={loading}
              pagination={false}
              rowKey="lineItemId"
            />
            {lineItems && lineItems.length > 0 && (
              <div
                className={styles.lineItemsSummary}
                style={{ textAlign: "right", marginTop: "12px" }}
              >
                <strong>
                  Total: {formData.currency || "INR"}{" "}
                  {lineItems
                    .reduce((sum, item) => sum + item.invoiceAmount, 0)
                    .toFixed(2)}
                </strong>
              </div>
            )}
          </Card>
        </Col>
      </Row>
    </div>
  );
}
