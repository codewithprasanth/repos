import React from "react";
import { CheckCircleOutlined, ClockCircleOutlined } from "@ant-design/icons";
import styles from "./WorkflowTimeline.module.scss";

export interface WorkflowStep {
  id: string;
  status: string;
  title: string;
  subtitle?: string;
  timestamp: string;
  isCompleted: boolean;
  isActive?: boolean;
}

interface WorkflowTimelineProps {
  steps: WorkflowStep[];
  className?: string;
}

export default function WorkflowTimeline({
  steps,
  className,
}: WorkflowTimelineProps) {
  return (
    <div className={`${styles.workflowTimeline} ${className || ""}`}>
      <div className={styles.timelineContainer}>
        {steps.map((step, index) => (
          <div key={step.id} className={styles.timelineItem}>
            <div className={styles.timelineNode}>
              <div
                className={`${styles.nodeIcon} ${
                  step.isCompleted
                    ? styles.completed
                    : step.isActive
                    ? styles.active
                    : styles.pending
                }`}
              >
                {step.isCompleted ? (
                  <CheckCircleOutlined />
                ) : step.isActive ? (
                  <CheckCircleOutlined />
                ) : (
                  <ClockCircleOutlined />
                )}
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`${styles.connector} ${
                    step.isCompleted ? styles.connectorCompleted : ""
                  }`}
                />
              )}
            </div>
            <div
              className={`${styles.timelineContent} ${
                step.isCompleted
                  ? styles.contentCompleted
                  : step.isActive
                  ? styles.contentActive
                  : styles.contentPending
              }`}
            >
              <div className={styles.contentHeader}>
                <div className={styles.stepStatus}>{step.status}</div>
                {step.timestamp && (
                  <div className={styles.stepTimestamp}>{step.timestamp}</div>
                )}
              </div>
              <div className={styles.stepTitle}>{step.title}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
