import React from "react";
import { useForm, Controller } from "react-hook-form";
import LiveSearch from "../../../../components/LiveSearch/LiveSearch";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import { userService } from "../../../admin/user-management/user-management.service";
import type { UserDTO } from "../../../admin/user-management/user-management.types";
import styles from "./SendToQueryForm.module.scss";

export interface SendToQueryFormData {
  queryUser: string;
  queryType: string;
  autoComments: string;
}

interface SendToQueryFormProps {
  onSubmit: (data: SendToQueryFormData) => void;
  initialData?: Partial<SendToQueryFormData>;
  onFormReady?: (submit: () => void) => void;
}

const SendToQueryForm: React.FC<SendToQueryFormProps> = ({
  onSubmit,
  initialData,
  onFormReady,
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<SendToQueryFormData>({
    defaultValues: initialData || {
      queryUser: "",
      queryType: "",
      autoComments: "",
    },
  });

  const queryTypeOptions = [
    { value: "Vendor Mismatch", label: "Vendor Mismatch" },
    { value: "Amount Mismatch", label: "Amount Mismatch" },
    { value: "Missing Information", label: "Missing Information" },
    { value: "PO Not Found", label: "PO Not Found" },
    { value: "Invoice Duplicate", label: "Invoice Duplicate" },
    { value: "Other", label: "Other" },
  ];

  React.useEffect(() => {
    if (onFormReady) {
      onFormReady(() => handleSubmit(onSubmit)());
    }
  }, [onFormReady, handleSubmit, onSubmit]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={styles.queryForm}>
      <Controller
        name="queryUser"
        control={control}
        rules={{ required: "Query user is required" }}
        render={({ field }) => (
          <LiveSearch<UserDTO>
            label="Query User"
            placeholder="Search user by name or email"
            required
            error={errors.queryUser?.message}
            fetchFunction={async (keyword) => {
              try {
                const response = await userService.getAllUsers(keyword);
                return response.data;
              } catch (error) {
                console.error("Error fetching users:", error);
                return [];
              }
            }}
            getOptionValue={(user) => user.id}
            getOptionLabel={(user) =>
              `${user.firstName} ${user.lastName} (${user.email})`
            }
            value={field.value}
            onChange={(value) => field.onChange(value)}
          />
        )}
      />

      <Controller
        name="queryType"
        control={control}
        rules={{ required: "Query type is required" }}
        render={({ field }) => (
          <LabeledSelect
            label="Query Type"
            placeholder="Select query type"
            required
            options={queryTypeOptions}
            error={errors.queryType?.message}
            {...field}
          />
        )}
      />

      <Controller
        name="autoComments"
        control={control}
        rules={{
          required: "Comments are required",
          minLength: {
            value: 10,
            message: "Comments must be at least 10 characters",
          },
        }}
        render={({ field }) => (
          <div className={styles.textareaWrapper}>
            <label className={styles.label}>
              Auto Comments <span className={styles.required}>*</span>
            </label>
            <textarea
              {...field}
              className={`${styles.textarea} ${
                errors.autoComments ? styles.error : ""
              }`}
              placeholder="Enter comments for the query..."
              rows={6}
            />
            {errors.autoComments && (
              <span className={styles.errorMessage}>
                {errors.autoComments.message}
              </span>
            )}
          </div>
        )}
      />
    </form>
  );
};

export default SendToQueryForm;
