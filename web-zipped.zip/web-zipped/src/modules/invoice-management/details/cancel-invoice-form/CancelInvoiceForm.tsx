import React, { useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import styles from "./CancelInvoiceForm.module.scss";

export interface CancelInvoiceFormData {
  reason: string;
  comments: string;
}

interface CancelInvoiceFormProps {
  onSubmit: (data: CancelInvoiceFormData) => void;
  onFormReady?: (submitFn: () => void) => void;
}

const CancelInvoiceForm: React.FC<CancelInvoiceFormProps> = ({
  onSubmit,
  onFormReady,
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<CancelInvoiceFormData>({
    defaultValues: {
      reason: "",
      comments: "",
    },
  });

  useEffect(() => {
    if (onFormReady) {
      onFormReady(handleSubmit(onSubmit));
    }
  }, [onFormReady, handleSubmit, onSubmit]);

  const reasonOptions = [
    { value: "duplicate", label: "Duplicate Invoice" },
    { value: "incorrect", label: "Incorrect Information" },
    { value: "vendor_request", label: "Vendor Request" },
    { value: "not_required", label: "Service Not Required" },
    { value: "budget", label: "Budget Constraints" },
    { value: "other", label: "Other" },
  ];

  return (
    <form className={styles.cancelInvoiceForm}>
      <div className={styles.formField}>
        <Controller
          name="reason"
          control={control}
          rules={{ required: "Reason is required" }}
          render={({ field }) => (
            <LabeledSelect
              label="Reason"
              placeholder="Select reason for cancellation"
              options={reasonOptions}
              value={field.value}
              onChange={field.onChange}
              required
            />
          )}
        />
        {errors.reason && (
          <span className={styles.errorMessage}>{errors.reason.message}</span>
        )}
      </div>

      <div className={styles.formField}>
        <label className={styles.label}>
          Comments <span className={styles.required}>*</span>
        </label>
        <Controller
          name="comments"
          control={control}
          rules={{
            required: "Comments are required",
            minLength: {
              value: 10,
              message: "Comments must be at least 10 characters",
            },
          }}
          render={({ field }) => (
            <textarea
              {...field}
              className={`${styles.textarea} ${
                errors.comments ? styles.error : ""
              }`}
              placeholder="Enter comments for cancellation"
              rows={4}
            />
          )}
        />
        {errors.comments && (
          <span className={styles.errorMessage}>{errors.comments.message}</span>
        )}
      </div>
    </form>
  );
};

export default CancelInvoiceForm;
