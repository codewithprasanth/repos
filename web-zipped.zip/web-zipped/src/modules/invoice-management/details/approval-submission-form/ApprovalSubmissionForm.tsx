import React from "react";
import { useForm, Controller } from "react-hook-form";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import styles from "./ApprovalSubmissionForm.module.scss";

export interface ApprovalSubmissionFormData {
  comments: string;
}

interface ApprovalSubmissionFormProps {
  onSubmit: (data: ApprovalSubmissionFormData) => void;
  initialData?: Partial<ApprovalSubmissionFormData>;
  onFormReady?: (submit: () => void) => void;
}

const ApprovalSubmissionForm: React.FC<ApprovalSubmissionFormProps> = ({
  onSubmit,
  initialData,
  onFormReady,
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<ApprovalSubmissionFormData>({
    defaultValues: initialData || {
      comments: "",
    },
  });

  React.useEffect(() => {
    if (onFormReady) {
      onFormReady(() => handleSubmit(onSubmit)());
    }
  }, [onFormReady, handleSubmit, onSubmit]);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={styles.approvalForm}>
      <Controller
        name="comments"
        control={control}
        rules={{
          required: "Comments are required",
          minLength: {
            value: 10,
            message: "Comments must be at least 10 characters",
          },
        }}
        render={({ field }) => (
          <div className={styles.textareaWrapper}>
            <label className={styles.label}>
              Comments <span className={styles.required}>*</span>
            </label>
            <textarea
              {...field}
              className={`${styles.textarea} ${
                errors.comments ? styles.error : ""
              }`}
              placeholder="Enter comments for approval submission..."
              rows={6}
            />
            {errors.comments && (
              <span className={styles.errorMessage}>
                {errors.comments.message}
              </span>
            )}
          </div>
        )}
      />
    </form>
  );
};

export default ApprovalSubmissionForm;
