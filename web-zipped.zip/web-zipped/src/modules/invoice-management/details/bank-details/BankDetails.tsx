import React, { useState } from "react";
import type { ColumnsType } from "antd/es/table";
import DataTable from "../../../../components/DataTable/DataTable";
import styles from "../InvoiceDetails.module.scss";

// Sample data for Bank Details table
interface BankDetailsData {
  key: string;
  bankCountry: string;
  bankKey: string;
  bankAccount: string;
  accountHolder: string;
  beneficiary: string;
  swiftCode: string;
  iban: string;
  partnerType: string;
  bsbKey: string;
  isHeader?: boolean;
}

const bankDetailsData: BankDetailsData[] = [
  {
    key: "header1",
    bankCountry: "Vendor Bank Information",
    bankKey: "",
    bankAccount: "",
    accountHolder: "",
    beneficiary: "",
    swiftCode: "",
    iban: "",
    partnerType: "",
    bsbKey: "",
    isHeader: true,
  },
  {
    key: "1",
    bankCountry: "Singapore",
    bankKey: "DBSSSGSG",
    bankAccount: "1234567890",
    accountHolder: "FGV TRADING SDN BHD",
    beneficiary: "FGV TRADING SDN BHD",
    swiftCode: "DBSSSGSG",
    iban: "",
    partnerType: "Vendor",
    bsbKey: "",
  },
  {
    key: "header2",
    bankCountry: "Company Bank Information",
    bankKey: "",
    bankAccount: "",
    accountHolder: "",
    beneficiary: "",
    swiftCode: "",
    iban: "",
    partnerType: "",
    bsbKey: "",
    isHeader: true,
  },
  {
    key: "2",
    bankCountry: "Singapore",
    bankKey: "OCBCSGSG",
    bankAccount: "9876543210",
    accountHolder: "Olam Global Agri Pte. Ltd",
    beneficiary: "Olam Global Agri Pte. Ltd",
    swiftCode: "OCBCSGSG",
    iban: "",
    partnerType: "Company",
    bsbKey: "",
  },
];

export default function BankDetails() {
  const [data] = useState<BankDetailsData[]>(bankDetailsData);

  // Define columns for Bank Details table
  const bankDetailsColumns: ColumnsType<BankDetailsData> = [
    {
      title: "Bank Country",
      dataIndex: "bankCountry",
      key: "bankCountry",
      width: 200,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            children: <strong>{text}</strong>,
            props: {
              colSpan: 9,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Bank Key",
      dataIndex: "bankKey",
      key: "bankKey",
      width: 120,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Bank Account",
      dataIndex: "bankAccount",
      key: "bankAccount",
      width: 150,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Account Holder",
      dataIndex: "accountHolder",
      key: "accountHolder",
      width: 200,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Beneficiary",
      dataIndex: "beneficiary",
      key: "beneficiary",
      width: 200,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Swift Code",
      dataIndex: "swiftCode",
      key: "swiftCode",
      width: 120,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Iban",
      dataIndex: "iban",
      key: "iban",
      width: 120,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Partner Type",
      dataIndex: "partnerType",
      key: "partnerType",
      width: 120,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
    {
      title: "Bsb Key",
      dataIndex: "bsbKey",
      key: "bsbKey",
      width: 120,
      render: (text: string, record: BankDetailsData) => {
        if (record.isHeader) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return text;
      },
    },
  ];

  return (
    <div className={styles.bankDetailsTab}>
      <DataTable<BankDetailsData>
        data={data}
        columns={bankDetailsColumns}
        pagination={false}
        size="middle"
        bordered={true}
        className={styles.bankDetailsTable}
      />
    </div>
  );
}
