import React, { useState } from "react";
import { Checkbox } from "antd";
import type { ColumnsType } from "antd/es/table";
import DataTable from "../../../../components/DataTable/DataTable";
import styles from "../InvoiceDetails.module.scss";

// Sample data for Approvers table
interface ApproverData {
  key: string;
  level: number;
  approvalType: string;
  approver: string;
  isSelected: boolean;
}

const initialApproversData: ApproverData[] = [
  {
    key: "1",
    level: 1,
    approvalType: "Functional Approver",
    approver: "null",
    isSelected: true,
  },
  {
    key: "2",
    level: 2,
    approvalType: "NCP Approver",
    approver: "rajesh.lokhande",
    isSelected: true,
  },
];

export default function Approvers() {
  const [approversData, setApproversData] =
    useState<ApproverData[]>(initialApproversData);

  // Handle checkbox toggle for approvers
  const handleApproverToggle = (key: string) => {
    setApproversData((prev) =>
      prev.map((approver) =>
        approver.key === key
          ? { ...approver, isSelected: !approver.isSelected }
          : approver
      )
    );
  };

  // Define columns for Approvers table
  const approversColumns: ColumnsType<ApproverData> = [
    {
      title: "",
      key: "checkbox",
      width: 50,
      render: (_, record) => (
        <Checkbox
          checked={record.isSelected}
          onChange={() => handleApproverToggle(record.key)}
          className={styles.approverCheckbox}
        />
      ),
    },
    {
      title: "Level",
      dataIndex: "level",
      key: "level",
      width: 100,
      align: "center",
    },
    {
      title: "Approval Type",
      dataIndex: "approvalType",
      key: "approvalType",
      width: 200,
    },
    {
      title: "Approver",
      dataIndex: "approver",
      key: "approver",
      width: 200,
    },
  ];

  return (
    <div className={styles.approversTab}>
      <DataTable<ApproverData>
        data={approversData}
        columns={approversColumns}
        pagination={false}
        size="middle"
        bordered={false}
        className={styles.approversTable}
      />
    </div>
  );
}
