import React from "react";
import styles from "../InvoiceDetails.module.scss";

export default function Simulate() {
  return (
    <div className={styles.simulateTab}>
      <div>Simulate content goes here</div>
    </div>
  );
}
