import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Spinner from "../../../../components/spinner";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import styles from "./Comments.module.scss";
import type { RootDispatch } from "../../../../store/store";
import {
  fetchComments,
  createComment,
  selectComments,
} from "../../../../store/invoice-management/invoice-management-slice";

interface CommentsProps {
  workItemNumber: string;
  className?: string;
}

const Comments: React.FC<CommentsProps> = ({
  workItemNumber,
  className = "",
}) => {
  const dispatch = useDispatch<RootDispatch>();
  const { comments, loading, error } = useSelector(selectComments);
  const [commentText, setCommentText] = useState("");

  useEffect(() => {
    if (workItemNumber) {
      dispatch(fetchComments(workItemNumber));
    }
  }, [dispatch, workItemNumber]);

  const handleSubmit = async () => {
    if (commentText.trim()) {
      await dispatch(
        createComment({
          workItemNumber,
          request: { commentText: commentText.trim() },
        })
      );
      setCommentText("");
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  if (error) {
    return <div className={styles.error}>Error loading comments: {error}</div>;
  }

  if (loading) {
    return <Spinner />;
  }

  return (
    <div className={`${styles.commentsContainer} ${className}`}>
      <div className={styles.commentsGrid}>
        {/* Add Comments Section */}
        <div className={styles.addCommentsSection}>
          <div className={styles.sectionHeader}>
            <span className={styles.headerIcon}>+</span>
            <span className={styles.headerTitle}>Add Comments</span>
          </div>
          <div className={styles.sectionContent}>
            <textarea
              className={styles.commentTextarea}
              placeholder="Add Comments"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              rows={10}
            />
            <div className={styles.submitButtonContainer}>
              <ReusableButton
                variant="primary"
                onClick={handleSubmit}
                disabled={!commentText.trim() || loading}
                className={styles.submitButton}
              >
                Submit
              </ReusableButton>
            </div>
          </div>
        </div>

        {/* Comments History Section */}
        <div className={styles.commentsHistorySection}>
          <div className={styles.sectionHeader}>
            <span className={styles.headerIcon}>🕒</span>
            <span className={styles.headerTitle}>Comments History</span>
            <span className={styles.commentsCount}>{comments.length}</span>
          </div>
          <div className={styles.sectionContent}>
            {comments.length === 0 ? (
              <div className={styles.noComments}>No comments yet</div>
            ) : (
              <div className={styles.commentsList}>
                {comments.map((comment) => (
                  <div key={comment.commentId} className={styles.commentItem}>
                    <div className={styles.commentHeader}>
                      <span className={styles.commentAuthor}>
                        {comment.createdBy.name}
                      </span>
                      <span className={styles.commentTimestamp}>
                        {formatDate(comment.createdAt)}
                      </span>
                    </div>
                    <div className={styles.commentText}>{comment.text}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Comments;
