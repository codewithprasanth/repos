import styles from './QCModule.module.scss';

export default function QCModule() {
  return (
    <div className={styles.qcModule}>
      <h1>QC Module</h1>
      <p>This is the Quality Control Module page</p>
    </div>
  );
}
