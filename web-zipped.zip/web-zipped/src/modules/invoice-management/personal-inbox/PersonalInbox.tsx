import React, { useEffect } from "react";
import {
  UnorderedListOutlined,
  CheckOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined,
  SearchOutlined,
  PlusOutlined,
  MinusOutlined,
  UsergroupAddOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";

import { Link, useNavigate } from "react-router-dom";
import type { ColumnsType } from "antd/es/table";
import KPIVertical from "../../../components/KPI_Vertical/KPIVertical";
import styles from "./PersonalInbox.module.scss";
import DataTable from "../../../components/DataTable/DataTable";
import IconActionButton from "../../../components/IconActionButton/IconActionButton";
import StatusTag from "../../../components/StatusTag/StatusTag";
import LabeledSelect from "../../../components/LabeledSelect/LabeledSelect";
import LabeledInput from "../../../components/LabeledInput/LabeledInput";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchInvoiceList,
  selectInvoices,
} from "../../../store/invoice-management/invoice-management-slice";
import type { RootDispatch } from "../../../store/store";

export default function PersonalInbox() {
  const dispatch = useDispatch<RootDispatch>();
  const responseData = useSelector(selectInvoices);
  const navigate = useNavigate();
  const [sortParams, setSortParams] = React.useState<{
    sortBy: string;
    sortOrder: "asc" | "desc";
  }>({ sortBy: "workItemNumber", sortOrder: "desc" });

  const [paginationParams, setPaginationParams] = React.useState<{
    pageNo: number;
    pageSize: number;
  }>({ pageNo: 1, pageSize: 10 });

  const [filterColumn, setFilterColumn] = React.useState<string | undefined>(
    undefined
  );
  const [filterValue, setFilterValue] = React.useState<string | undefined>(
    undefined
  );
  const [searchBy, setSearchBy] = React.useState<string>("workItemNumber");
  const [searchValue, setSearchValue] = React.useState<string>("");
  const [selectedRowKeys, setSelectedRowKeys] = React.useState<React.Key[]>([]);

  // Search options matching the image
  const searchOptions = [
    { label: "Work Item Number", value: "workItemNumber" },
    { label: "Work Item Status", value: "status" },
    { label: "Invoice Number", value: "invoiceNumber" },
    { label: "PO Number", value: "poNumber" },
    { label: "Initiator", value: "initiator" },
    { label: "Queue", value: "queue" },
  ];

  useEffect(() => {
    dispatch(
      fetchInvoiceList({
        pageSize: paginationParams.pageSize,
        pageNo: paginationParams.pageNo,
        sortBy: sortParams.sortBy,
        sortOrder: sortParams.sortOrder,
        filterColumn,
        filterValue,
      })
    );
  }, [dispatch, sortParams, paginationParams, filterColumn, filterValue]);

  const handleSortChange = (sortBy: string, sortOrder: "asc" | "desc") => {
    setSortParams({ sortBy, sortOrder });
    // Reset to page 1 when sorting changes
    setPaginationParams({ pageNo: 1, pageSize: paginationParams.pageSize });
  };

  const handlePaginationChange = (page: number, pageSize: number) => {
    setPaginationParams({ pageNo: page, pageSize });
  };

  const handleSearch = () => {
    if (searchValue.trim()) {
      setFilterColumn(searchBy);
      setFilterValue(searchValue.trim());
      // Reset to page 1 when filter changes
      setPaginationParams({ pageNo: 1, pageSize: paginationParams.pageSize });
    }
  };

  const handleSelectChange = (newSelectedRowKeys: React.Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const handleClaimTask = () => {
    if (selectedRowKeys.length === 0) {
      alert("Please select at least one work item to claim.");
      return;
    }
    console.log("Claiming tasks:", selectedRowKeys);
    // TODO: Implement claim task API call
  };

  const handleRevokeClaim = () => {
    if (selectedRowKeys.length === 0) {
      alert("Please select at least one work item to revoke.");
      return;
    }
    console.log("Revoking claim for tasks:", selectedRowKeys);
    // TODO: Implement revoke claim API call
  };

  const handleDelegate = () => {
    if (selectedRowKeys.length === 0) {
      alert("Please select at least one work item to delegate.");
      return;
    }
    console.log("Delegating tasks:", selectedRowKeys);
    // TODO: Implement delegate API call
  };

  const handleForward = () => {
    if (selectedRowKeys.length === 0) {
      alert("Please select at least one work item to forward.");
      return;
    }
    console.log("Forwarding tasks:", selectedRowKeys);
    // TODO: Implement forward API call
  };

  // Row selection configuration
  const rowSelection = {
    selectedRowKeys,
    onChange: handleSelectChange,
  };

  // Column definitions for PersonalInbox DataTable
  const columns: ColumnsType<(typeof responseData.invoices)[0]> = [
    {
      title: "Work Item Number",
      dataIndex: "workItemNumber",
      key: "workItemNumber",
      width: 180,
      sorter: true,
      render: (text: string, record: (typeof responseData.invoices)[0]) => (
        <Link
          to={`/invoice-management/details/${record.workItemNumber}`}
          className={styles.workItemLink}
        >
          {text}
        </Link>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 160,
      sorter: true,
      render: (status: string) => <StatusTag status={status} />,
    },
    {
      title: "Invoice Number",
      dataIndex: "invoiceNumber",
      key: "invoiceNumber",
      width: 120,
      sorter: true,
    },
    {
      title: "Classification",
      dataIndex: "classification",
      key: "classification",
      width: 100,
      align: "center",
    },
    {
      title: "PO Number",
      dataIndex: "poNumber",
      key: "poNumber",
      width: 120,
    },
    {
      title: "Vendor Name",
      dataIndex: "vendorName",
      key: "vendorName",
      width: 140,
      sorter: true,
    },
    {
      title: "Company Code",
      dataIndex: "companyCode",
      key: "companyCode",
      width: 100,
      align: "center",
      sorter: true,
    },
    {
      title: "Invoice Amount",
      dataIndex: "invoiceAmount",
      key: "invoiceAmount",
      width: 120,
      align: "right",
      sorter: true,
      render: (amount: number) => (
        <span className={styles.invoiceAmount}>
          {amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
        </span>
      ),
    },
    {
      title: "Currency",
      dataIndex: "currency",
      key: "currency",
      width: 80,
      align: "center",
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDate",
      width: 100,
      sorter: true,
    },
    {
      title: "Assignee",
      dataIndex: "assignee",
      key: "assignee",
      width: 80,
      align: "center",
    },
    {
      title: "Queue",
      dataIndex: "queue",
      key: "queue",
      width: 80,
      align: "center",
    },
  ];

  const handleRowClick = (record: (typeof responseData.invoices)[0]) => {
    navigate(`/invoice-management/details/${record.workItemNumber}`);
  };

  return (
    <div className={styles.personalInbox}>
      <div className={styles.kpiContainer}>
        <KPIVertical
          icon={<UnorderedListOutlined />}
          value={271}
          label="Total"
          backgroundColor="#ffffff"
          iconColor="#ffffff"
          className="primary"
        />
        <KPIVertical
          icon={<CheckOutlined />}
          value={0}
          label="Assigned"
          backgroundColor="#ffffff"
          iconColor="#ffffff"
          className="success"
        />
        <KPIVertical
          icon={<ClockCircleOutlined />}
          value={271}
          label="Un Assigned"
          backgroundColor="#ffffff"
          iconColor="#ffffff"
          className="neutral"
        />
        <KPIVertical
          icon={<ExclamationCircleOutlined />}
          value={2}
          label="SLA Breached"
          backgroundColor="#ffffff"
          iconColor="#ffffff"
          className="danger"
        />
      </div>
      <div className={styles.gridSection}>
        <div className={styles.filterRow}>
          <div className={styles.searchFilter}>
            <LabeledSelect
              label="Search Task"
              value={searchBy}
              onChange={(value) => setSearchBy(value as string)}
              options={searchOptions}
              size="large"
              required
              allowClear={false}
              className={styles.searchSelect}
            />
            <LabeledInput
              label="Search Text"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Enter search value"
              size="large"
              required
              className={styles.searchInput}
            />
            <IconActionButton
              icon={<SearchOutlined />}
              onClick={handleSearch}
              tooltip="Filter"
              className={styles.filterButton}
            />
          </div>
          <div className={styles.actionButtons}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Claim Task"
              onClick={handleClaimTask}
            />
            <IconActionButton
              icon={<MinusOutlined />}
              tooltip="Revoke Claim"
              onClick={handleRevokeClaim}
            />
            <IconActionButton
              icon={<UsergroupAddOutlined />}
              tooltip="Delegate"
              onClick={handleDelegate}
            />
            <IconActionButton
              icon={<ArrowRightOutlined />}
              tooltip="Forward"
              onClick={handleForward}
            />
          </div>
        </div>
        <DataTable
          data={responseData.invoices}
          columns={columns}
          size="small"
          rowKey="workItemNumber"
          loading={responseData.loading}
          onSortChange={handleSortChange}
          onPaginationChange={handlePaginationChange}
          totalRecords={responseData.totalItems}
          onRowClick={handleRowClick}
          rowSelection={rowSelection}
        />
      </div>
    </div>
  );
}
