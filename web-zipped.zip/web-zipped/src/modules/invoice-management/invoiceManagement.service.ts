import { axiosInstance } from "../../auth/axios-config";
import type {
  InvoiceApiResponse,
  InvoiceListRequest,
  InvoiceDetailResponse,
  AdditionalDetailsResponse,
  CommentsResponse,
  CreateCommentRequest,
  CreateCommentResponse,
} from "../../types/invoice-management";
import type { UploadsResponse } from "../../types/uploads";
import { API_ENDPOINTS } from "../../config/apis";
// Mock data imports (commented out for production)
import {
  mockInvoices,
  getMockInvoiceDetail,
  getMockAdditionalDetails,
  getMockComments,
} from "../../mock/invoices";
import { getMockUploads } from "../../mock/uploads";

// Service function for invoice list
export const getInvoiceList = async (
  request: InvoiceListRequest
): Promise<InvoiceApiResponse> => {
  try {
    // Build query parameters
    const params = new URLSearchParams({
      pageSize: request.pageSize.toString(),
      pageNo: request.pageNo.toString(),
      sortBy: request.sortBy,
      sortOrder: request.sortOrder,
    });

    // Add filter parameters if they exist
    if (request.filterColumn && request.filterValue) {
      params.append("filterColumn", request.filterColumn);
      params.append("filterValue", request.filterValue);
    }

    // Mock data (commented out for production)
    return mockInvoices as InvoiceApiResponse;
    const response = await axiosInstance.get<InvoiceApiResponse>(
      `${
        API_ENDPOINTS.INVOICE_MANAGEMENT.GET_INVOICE_LIST
      }?${params.toString()}`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching invoice list:", error);
    throw error;
  }
};

// Service function for invoice detail
export const getInvoiceDetail = async (
  workItemNumber: string
): Promise<InvoiceDetailResponse> => {
  try {
    // Mock data (commented out for production)
    await new Promise((resolve) => setTimeout(resolve, 500));
    return getMockInvoiceDetail(workItemNumber);
    const response = await axiosInstance.get<InvoiceDetailResponse>(
      `${API_ENDPOINTS.INVOICE_MANAGEMENT.GET_INVOICE_DETAIL}/${workItemNumber}`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching invoice detail:", error);
    throw error;
  }
};

// Service function for additional details
export const getAdditionalDetails = async (
  workItemNumber: string
): Promise<AdditionalDetailsResponse> => {
  try {
    // Mock data (commented out for production)
    await new Promise((resolve) => setTimeout(resolve, 500));
    return getMockAdditionalDetails(workItemNumber);
    const response = await axiosInstance.get<AdditionalDetailsResponse>(
      `${API_ENDPOINTS.INVOICE_MANAGEMENT.GET_ADDITIONAL_DETAILS}/${workItemNumber}/additional-details`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching additional details:", error);
    throw error;
  }
};

// Service function for fetching comments
export const getComments = async (
  workItemNumber: string
): Promise<CommentsResponse> => {
  try {
    // Mock data (commented out for production)
    await new Promise((resolve) => setTimeout(resolve, 500));
    return getMockComments(workItemNumber);
    const response = await axiosInstance.get<CommentsResponse>(
      `${API_ENDPOINTS.INVOICE_MANAGEMENT.GET_COMMENTS}/${workItemNumber}/comments`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching comments:", error);
    throw error;
  }
};

// Service function for posting a comment
export const postComment = async (
  workItemNumber: string,
  request: CreateCommentRequest
): Promise<CreateCommentResponse> => {
  try {
    // Mock data (commented out for production)
    await new Promise((resolve) => setTimeout(resolve, 500));
    console.log("Creating comment for workItem:", workItemNumber);
    const mockResponse: CreateCommentResponse = {
      success: true,
      message: "Comment created successfully",
      data: {
        commentId: Math.random().toString(36).substr(2, 9),
        text: request.commentText,
        createdBy: {
          userId: "f6c4e3c2-9b0e-4c2a-9d6a-4be9f3a1bfa8",
          name: "Current User",
          email: "user@guidant.com",
        },
        createdAt: new Date().toISOString(),
      },
      timestamp: new Date().toISOString(),
    };
    return mockResponse;
    const response = await axiosInstance.post<CreateCommentResponse>(
      `${API_ENDPOINTS.INVOICE_MANAGEMENT.POST_COMMENT}/${workItemNumber}/comments`,
      request
    );
    return response.data;
  } catch (error) {
    console.error("Error posting comment:", error);
    throw error;
  }
};

// Service function for fetching uploads
export const getUploads = async (
  workItemNumber: string
): Promise<UploadsResponse> => {
  try {
    // Mock data (commented out for production)
    await new Promise((resolve) => setTimeout(resolve, 500));
    return getMockUploads(workItemNumber);
    const response = await axiosInstance.get<UploadsResponse>(
      `${API_ENDPOINTS.INVOICE_MANAGEMENT.GET_UPLOADS}/${workItemNumber}/uploads`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching uploads:", error);
    throw error;
  }
};
