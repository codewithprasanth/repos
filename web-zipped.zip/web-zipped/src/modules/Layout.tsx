import { Outlet } from "react-router-dom";
import { LogoutOutlined } from "@ant-design/icons";
import style from "./layout.module.scss";
import Sidebar from "../components/Sider";
import AppBreadcrumb from "../components/AppBreadcrumb";
import { useDispatch, useSelector } from "react-redux";
import type { RootDispatch } from "../store/store";
import { logout } from "../store/auth/auth-slice";
import { selectUser } from "../store/auth/auth-selector";

export default function Layout() {
  const dispatch = useDispatch<RootDispatch>();
  const user = useSelector(selectUser);

  const handleLogout = () => {
    dispatch(logout());
  };

  return (
    <>
      <div className={style.mainLayout}>
        <Sidebar />
        <div className={style.contentContainer}>
          <div className={style.breadcrumbHeader}>
            <AppBreadcrumb />
            <div className={style.userSection}>
              <div className={style.userInfo}>
                <div className={style.username}>{`${user?.fullName}`}</div>
                <div className={style.userEmail}>{user?.email}</div>
              </div>
              <LogoutOutlined
                className={style.logoutIcon}
                onClick={handleLogout}
                title="Logout"
              />
            </div>
          </div>
          <div className={style.outletContainer}>
            <Outlet />
          </div>
        </div>
      </div>
    </>
  );
}
