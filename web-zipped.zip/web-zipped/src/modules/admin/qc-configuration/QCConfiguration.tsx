import React, { useState } from "react";
import { Checkbox } from "antd";
import {
  PlusOutlined,
  ReloadOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import ReusableTab from "../../../components/ReusableTab/ReusableTab";
import DataTable from "../../../components/DataTable/DataTable";
import type { TabItem } from "../../../components/ReusableTab/ReusableTab";
import LabeledSelect from "../../../components/LabeledSelect/LabeledSelect";
import LabeledCheckbox from "../../../components/LabeledCheckbox";
import IconActionButton from "../../../components/IconActionButton/IconActionButton";
import styles from "./QCConfiguration.module.scss";

export default function QCConfiguration() {
  const [selectedCountry, setSelectedCountry] = useState<string | undefined>(
    undefined
  );
  const [disableQC, setDisableQC] = useState<boolean>(false);

  const countryOptions = [
    { value: "us", label: "United States" },
    { value: "uk", label: "United Kingdom" },
    { value: "ca", label: "Canada" },
    { value: "au", label: "Australia" },
    { value: "de", label: "Germany" },
    { value: "fr", label: "France" },
    { value: "in", label: "India" },
    { value: "jp", label: "Japan" },
  ];

  // Sample data for User tab QC table
  const userQCData = [
    {
      key: "1",
      processor: "John Smith",
      product: "Software License",
      samplingPercent: 25,
      enableQC: true,
    },
    {
      key: "2",
      processor: "Sarah Johnson",
      product: "Hardware Equipment",
      samplingPercent: 50,
      enableQC: false,
    },
  ];

  // Sample data for Invoice Type tab QC table
  const invoiceTypeQCData = [
    {
      key: "1",
      classification: "Standard",
      invoiceType: "Purchase Order",
      enableQC: true,
    },
    {
      key: "2",
      classification: "Priority",
      invoiceType: "Service Invoice",
      enableQC: false,
    },
    {
      key: "3",
      classification: "Urgent",
      invoiceType: "Credit Note",
      enableQC: true,
    },
  ];

  // Define columns for QC table
  interface QCUserData {
    key: string;
    processor: string;
    product: string;
    samplingPercent: number;
    enableQC: boolean;
  }

  interface QCInvoiceTypeData {
    key: string;
    classification: string;
    invoiceType: string;
    enableQC: boolean;
  }

  // Sample data for Currency tab QC table
  const currencyQCData = [
    {
      key: "1",
      currency: "USD",
      enableQC: true,
    },
    {
      key: "2",
      currency: "EUR",
      enableQC: false,
    },
    {
      key: "3",
      currency: "GBP",
      enableQC: true,
    },
    {
      key: "4",
      currency: "JPY",
      enableQC: false,
    },
  ];

  interface QCCurrencyData {
    key: string;
    currency: string;
    enableQC: boolean;
  }

  // Sample data for Product & Invoice Value tab QC table
  const productInvoiceValueQCData = [
    {
      key: "1",
      productName: "Software License",
      invoiceValue: "$0 - $10,000",
      enableQC: true,
    },
    {
      key: "2",
      productName: "Hardware Equipment",
      invoiceValue: "$10,001 - $50,000",
      enableQC: false,
    },
    {
      key: "3",
      productName: "Professional Services",
      invoiceValue: "$50,001 - $100,000",
      enableQC: true,
    },
    {
      key: "4",
      productName: "Cloud Subscription",
      invoiceValue: "$100,001+",
      enableQC: true,
    },
  ];

  interface QCProductInvoiceValueData {
    key: string;
    productName: string;
    invoiceValue: string;
    enableQC: boolean;
  }

  // Sample data for QC Critical Vendor tab QC table
  const qcCriticalVendorQCData = [
    {
      key: "1",
      companyCode: "TECH001",
      vendorCode: "V001",
      vendorName: "TechCorp Solutions",
      enableQC: true,
    },
    {
      key: "2",
      companyCode: "SOFT002",
      vendorCode: "V002",
      vendorName: "Software Innovations Inc",
      enableQC: false,
    },
    {
      key: "3",
      companyCode: "HARD003",
      vendorCode: "V003",
      vendorName: "Hardware Supplies Ltd",
      enableQC: true,
    },
    {
      key: "4",
      companyCode: "SERV004",
      vendorCode: "V004",
      vendorName: "Professional Services Group",
      enableQC: true,
    },
  ];

  interface QCCriticalVendorData {
    key: string;
    companyCode: string;
    vendorCode: string;
    vendorName: string;
    enableQC: boolean;
  }

  // Sample data for QC Sampling tab QC table
  const qcSamplingQCData = [
    {
      key: "1",
      entity: "North America",
      companyCode: "NA001",
      samplingPercent: 25,
      enableQC: true,
    },
    {
      key: "2",
      entity: "Europe",
      companyCode: "EU002",
      samplingPercent: 50,
      enableQC: false,
    },
    {
      key: "3",
      entity: "Asia Pacific",
      companyCode: "AP003",
      samplingPercent: 75,
      enableQC: true,
    },
    {
      key: "4",
      entity: "Latin America",
      companyCode: "LA004",
      samplingPercent: 30,
      enableQC: true,
    },
  ];

  interface QCSamplingData {
    key: string;
    entity: string;
    companyCode: string;
    samplingPercent: number;
    enableQC: boolean;
  }

  const qcColumns: ColumnsType<QCUserData> = [
    {
      title: "Processor",
      dataIndex: "processor",
      key: "processor",
      width: 200,
    },
    {
      title: "Product",
      dataIndex: "product",
      key: "product",
      width: 250,
    },
    {
      title: "Sampling %",
      dataIndex: "samplingPercent",
      key: "samplingPercent",
      width: 120,
      align: "center",
      render: (percent: number) => `${percent}%`,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  // Define columns for Invoice Type QC table
  const invoiceTypeQCColumns: ColumnsType<QCInvoiceTypeData> = [
    {
      title: "Classification",
      dataIndex: "classification",
      key: "classification",
      width: 200,
    },
    {
      title: "Invoice Type",
      dataIndex: "invoiceType",
      key: "invoiceType",
      width: 250,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  // Define columns for Currency QC table
  const currencyQCColumns: ColumnsType<QCCurrencyData> = [
    {
      title: "Currency",
      dataIndex: "currency",
      key: "currency",
      width: 200,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  // Define columns for Product & Invoice Value QC table
  const productInvoiceValueQCColumns: ColumnsType<QCProductInvoiceValueData> = [
    {
      title: "Product Name",
      dataIndex: "productName",
      key: "productName",
      width: 250,
    },
    {
      title: "Invoice Value",
      dataIndex: "invoiceValue",
      key: "invoiceValue",
      width: 200,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  // Define columns for QC Critical Vendor QC table
  const qcCriticalVendorQCColumns: ColumnsType<QCCriticalVendorData> = [
    {
      title: "Company Code",
      dataIndex: "companyCode",
      key: "companyCode",
      width: 150,
    },
    {
      title: "Vendor Code",
      dataIndex: "vendorCode",
      key: "vendorCode",
      width: 150,
    },
    {
      title: "Vendor Name",
      dataIndex: "vendorName",
      key: "vendorName",
      width: 250,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  // Define columns for QC Sampling QC table
  const qcSamplingQCColumns: ColumnsType<QCSamplingData> = [
    {
      title: "Entity",
      dataIndex: "entity",
      key: "entity",
      width: 200,
    },
    {
      title: "Company Code",
      dataIndex: "companyCode",
      key: "companyCode",
      width: 150,
    },
    {
      title: "Sampling%",
      dataIndex: "samplingPercent",
      key: "samplingPercent",
      width: 120,
      align: "center",
      render: (percent: number) => `${percent}%`,
    },
    {
      title: "Enable QC",
      dataIndex: "enableQC",
      key: "enableQC",
      width: 120,
      align: "center",
      render: (enableQC: boolean) => <Checkbox checked={enableQC} />,
    },
  ];

  const tabItems: TabItem[] = [
    {
      key: "user",
      label: "User",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new QC configuration"
              variant="primary"
              onClick={() => console.log("Add clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() => console.log("Refresh clicked")}
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() => console.log("Delete clicked")}
            />
          </div>
          <DataTable<QCUserData>
            data={userQCData}
            columns={qcColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
    {
      key: "invoiceType",
      label: "Invoice Type",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new Invoice Type configuration"
              variant="primary"
              onClick={() => console.log("Add Invoice Type clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() => console.log("Refresh Invoice Type clicked")}
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() => console.log("Delete Invoice Type clicked")}
            />
          </div>
          <DataTable<QCInvoiceTypeData>
            data={invoiceTypeQCData}
            columns={invoiceTypeQCColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
    {
      key: "currency",
      label: "Currency",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new Currency configuration"
              variant="primary"
              onClick={() => console.log("Add Currency clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() => console.log("Refresh Currency clicked")}
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() => console.log("Delete Currency clicked")}
            />
          </div>
          <DataTable<QCCurrencyData>
            data={currencyQCData}
            columns={currencyQCColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
    {
      key: "productInvoiceValue",
      label: "Product & Invoice Value",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new Product & Invoice Value configuration"
              variant="primary"
              onClick={() => console.log("Add Product & Invoice Value clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() =>
                console.log("Refresh Product & Invoice Value clicked")
              }
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() =>
                console.log("Delete Product & Invoice Value clicked")
              }
            />
          </div>
          <DataTable<QCProductInvoiceValueData>
            data={productInvoiceValueQCData}
            columns={productInvoiceValueQCColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
    {
      key: "qcCriticalVendor",
      label: "QC Critical Vendor",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new QC Critical Vendor configuration"
              variant="primary"
              onClick={() => console.log("Add QC Critical Vendor clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() => console.log("Refresh QC Critical Vendor clicked")}
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() => console.log("Delete QC Critical Vendor clicked")}
            />
          </div>
          <DataTable<QCCriticalVendorData>
            data={qcCriticalVendorQCData}
            columns={qcCriticalVendorQCColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
    {
      key: "qcSampling",
      label: "QC Sampling",
      children: (
        <div className={styles.tabContent}>
          <div className={styles.actionButtonsContainer}>
            <IconActionButton
              icon={<PlusOutlined />}
              tooltip="Add new QC Sampling configuration"
              variant="primary"
              onClick={() => console.log("Add QC Sampling clicked")}
            />
            <IconActionButton
              icon={<ReloadOutlined />}
              tooltip="Refresh table"
              variant="secondary"
              onClick={() => console.log("Refresh QC Sampling clicked")}
            />
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete selected"
              variant="danger"
              onClick={() => console.log("Delete QC Sampling clicked")}
            />
          </div>
          <DataTable<QCSamplingData>
            data={qcSamplingQCData}
            columns={qcSamplingQCColumns}
            pagination={false}
            size="middle"
            bordered={false}
            className={styles.qcUserTable}
          />
        </div>
      ),
    },
  ];

  return (
    <div className={styles.qcConfiguration}>
      <h1>QC Configuration</h1>

      <div className={styles.controlsSection}>
        <div className={styles.controlsRow}>
          <div className={styles.selectWrapper}>
            <LabeledSelect
              label="Country"
              placeholder=""
              value={selectedCountry}
              onChange={(value) => setSelectedCountry(value as string)}
              options={countryOptions}
              className={styles.countrySelect}
              allowClear
            />
          </div>
          <div className={styles.checkboxWrapper}>
            <LabeledCheckbox
              label="Disable QC"
              checked={disableQC}
              onChange={(e) => setDisableQC(e.target.checked)}
              className={styles.disableQCCheckbox}
            />
          </div>
        </div>
      </div>

      <div className={styles.tabsSection}>
        <h2 className={styles.tabsTitle}>QC Check Details</h2>
        <ReusableTab
          items={tabItems}
          defaultActiveKey="user"
          className={styles.qcTabs}
        />
      </div>
    </div>
  );
}
