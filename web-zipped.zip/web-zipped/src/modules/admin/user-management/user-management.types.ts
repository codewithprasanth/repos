// ============= Types/Interfaces =============

export interface PaginationInfo {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
  sortBy?: string;
  sortOrder?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: PaginationInfo;
}

export interface RoleDTO {
  id: string;
  name: string;
  displayName: string;
  description: string;
  composite: boolean;
}

export interface PrivilegeDTO {
  id: string;
  name: string;
  displayName: string;
  description: string;
}

export interface GroupDTO {
  id: string;
  name: string;
  userCount?: number;
}

export interface UserRoleInfo {
  roleId: string;
  roleName: string;
  roleDisplayName: string;
}

export interface UserGroupInfo {
  groupId: string;
  groupName: string;
}

export interface UserDTO {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  enabled: boolean;
  emailVerified: boolean;
  createdTimestamp: number;
  roles: UserRoleInfo[];
  groups: UserGroupInfo[];
  attributes?: {
    [key: string]: string[];
  };
}

export interface CreateRoleRequest {
  roleName: string;
  description: string;
  privilegeIds: string[];
}

export interface UpdateRoleRequest {
  description?: string;
  privilegeIdsToAdd?: string[];
  privilegeIdsToRemove?: string[];
}

export interface CreateGroupRequest {
  groupName: string;
  userIds?: string[];
}

export interface UpdateGroupUsersRequest {
  userIdsToAdd: string[];
  userIdsToRemove: string[];
}

export interface UpdateGroupRolesPrivilegesRequest {
  roleIdsToAdd?: string[];
  roleIdsToRemove?: string[];
  privilegeIdsToAdd?: string[];
  privilegeIdsToRemove?: string[];
}

export interface CreateUserRequest {
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  enabled?: boolean;
  emailVerified?: boolean;
  entityCode?: string;
  countryCode?: string;
  roleIds?: string[];
  groupIds?: string[];
}

export interface UpdateUserRequest {
  email: string;
  firstName: string;
  lastName: string;
  enabled: boolean;
  emailVerified?: boolean;
  entityCode?: string;
  countryCode?: string;
  roleIdsToAdd?: string[];
  roleIdsToRemove?: string[];
  groupIdsToAdd?: string[];
  groupIdsToRemove?: string[];
}

export interface ApiResponse<T> {
  message: string;
  timestamp: string;
  data?: T;
}
