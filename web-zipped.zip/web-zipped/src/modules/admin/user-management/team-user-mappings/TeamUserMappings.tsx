import React, { useState, useEffect, useCallback } from "react";
import { Tag, Transfer } from "antd";
import { useNavigate } from "react-router-dom";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import type { ColumnsType } from "antd/es/table";
import styles from "./TeamUserMappings.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import Spinner from "../../../../components/spinner";
import EmptyData from "../../../../components/EmptyData/EmptyData";
import { groupService, userService } from "../user-management.service";
import type { GroupDTO, UserDTO } from "../user-management.types";

interface Team {
  id: string;
  name: string;
}

interface User {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  roles: { roleId: string; roleName: string; roleDisplayName: string }[];
  country: string[];
  enabled: boolean;
}

export default function TeamUserMappings() {
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [originalUserIds, setOriginalUserIds] = useState<string[]>([]);

  const fetchTeamUsers = useCallback(async (teamId: string) => {
    try {
      setLoading(true);

      // Fetch users for the selected team
      const data = await groupService.getGroupUsers(teamId);

      // Transform UserDTO to User interface
      const transformedUsers: User[] = data.map((user: UserDTO) => ({
        id: user.id,
        firstname: user.firstName,
        lastname: user.lastName,
        email: user.email,
        roles: user.roles || [],
        country: user?.attributes?.country_code || [],
        enabled: user.enabled,
      }));

      setUsers(transformedUsers);

      // Set selected and original user IDs
      const userIds = transformedUsers.map((u) => u.id);
      setSelectedUserIds(userIds);
      setOriginalUserIds(userIds);
      setIsEditMode(false);
    } catch (error) {
      console.error("Error loading users:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to load users for selected team.")
      );
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch teams on mount
  useEffect(() => {
    fetchTeams();
  }, []);

  // Fetch team users when team is selected
  useEffect(() => {
    if (selectedTeam) {
      fetchTeamUsers(selectedTeam);
    }
  }, [selectedTeam, fetchTeamUsers]);

  const fetchTeams = async () => {
    try {
      setLoading(true);
      const data = await groupService.getAllGroups();

      const transformedTeams: Team[] = data.map((group: GroupDTO) => ({
        id: group.id,
        name: group.name,
      }));

      setTeams(transformedTeams);

      // Set first team as selected if available
      if (transformedTeams.length > 0) {
        setSelectedTeam(transformedTeams[0].id);
      }
    } catch (error) {
      console.error("Error loading teams:", error);
      showMessage.error(getErrorMessage(error, "Failed to load teams."));
    } finally {
      setLoading(false);
    }
  };

  const handleTeamClick = (teamId: string) => {
    if (isEditMode) {
      const hasChanges =
        JSON.stringify(selectedUserIds.sort()) !==
        JSON.stringify(originalUserIds.sort());
      if (hasChanges) {
        const confirmed = window.confirm(
          "You have unsaved changes. Do you want to discard them?"
        );
        if (!confirmed) return;
      }
    }
    setSelectedTeam(teamId);
  };

  const handleEdit = async () => {
    // Fetch all users when entering edit mode (needed for Transfer component)
    if (allUsers.length === 0) {
      try {
        const allUsersResponse = await userService.getAllUsers();
        const transformedAllUsers: User[] = allUsersResponse.data.map(
          (user: UserDTO) => ({
            id: user.id,
            firstname: user.firstName,
            lastname: user.lastName,
            email: user.email,
            roles: user.roles || [],
            country: user?.attributes?.country_code || [],
            enabled: user.enabled,
          })
        );
        setAllUsers(transformedAllUsers);
      } catch (error) {
        console.error("Error loading all users:", error);
        showMessage.error(getErrorMessage(error, "Failed to load users."));
        return; // Don't enter edit mode if we can't load users
      }
    }
    setIsEditMode(true);
  };

  const handleCancel = () => {
    setSelectedUserIds([...originalUserIds]);
    setIsEditMode(false);
  };

  const handleSave = async () => {
    try {
      setSaving(true);

      const userIdsToAdd = selectedUserIds.filter(
        (id) => !originalUserIds.includes(id)
      );
      const userIdsToRemove = originalUserIds.filter(
        (id) => !selectedUserIds.includes(id)
      );

      await groupService.updateGroupUsers(selectedTeam, {
        userIdsToAdd,
        userIdsToRemove,
      });

      showMessage.success("Team users updated successfully");
      setOriginalUserIds([...selectedUserIds]);
      setIsEditMode(false);

      // Refresh the users list
      await fetchTeamUsers(selectedTeam);
    } catch (error) {
      console.error("Error saving team users:", error);
      showMessage.error(getErrorMessage(error, "Failed to update team users."));
    } finally {
      setSaving(false);
    }
  };

  const handleTransferChange = (newTargetKeys: React.Key[]) => {
    setSelectedUserIds(newTargetKeys as string[]);
  };

  // Column definitions for Team User DataTable
  const columns: ColumnsType<User> = [
    {
      title: "User Name",
      key: "username",
      width: 200,
      sorter: true,
      render: (_: unknown, record: User) => (
        <span>{`${record.firstname} ${record.lastname}`}</span>
      ),
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
      width: 220,
      sorter: true,
    },
    {
      title: "Role",
      dataIndex: "roles",
      key: "roles",
      width: 200,
      render: (
        roles: { roleId: string; roleName: string; roleDisplayName: string }[]
      ) => (
        <>
          {roles && roles.length > 0 ? (
            roles.map((role) => {
              return <Tag key={role.roleId}>{role.roleDisplayName}</Tag>;
            })
          ) : (
            <span>-</span>
          )}
        </>
      ),
    },
    {
      title: "Country",
      dataIndex: "country",
      key: "country",
      width: 180,
      sorter: true,
      render: (countries: string[]) => (
        <>
          {countries && countries.length > 0 ? (
            countries.map((country, index) => (
              <Tag key={index} color="blue">
                {country}
              </Tag>
            ))
          ) : (
            <span>-</span>
          )}
        </>
      ),
    },
    {
      title: "Enabled",
      dataIndex: "enabled",
      key: "enabled",
      width: 100,
      align: "center",
      sorter: true,
      render: (enabled: boolean) => (
        <Tag color={enabled ? "success" : "default"}>
          {enabled ? "Active" : "Inactive"}
        </Tag>
      ),
    },
  ];

  const hasChanges =
    JSON.stringify(selectedUserIds.sort()) !==
    JSON.stringify(originalUserIds.sort());

  if (loading && teams.length === 0) {
    return <Spinner />;
  }

  return (
    <div className={styles.teamUserMappings}>
      {!isEditMode && (
        <div className={styles.actionButtons}>
          <ReusableButton
            variant="primary"
            onClick={() => navigate("/admin/user-management/create-team")}
          >
            Create Team
          </ReusableButton>
        </div>
      )}

      {teams.length === 0 && !loading ? (
        <EmptyData
          icon="📋"
          title="No Teams Available"
          description="There are no teams configured in the system yet."
        />
      ) : (
        <div className={styles.content}>
          <div className={styles.teamsPanel}>
            <h3 className={styles.panelTitle}>Teams</h3>
            <div className={styles.teamsList}>
              {teams.map((team) => (
                <div
                  key={team.id}
                  className={`${styles.teamItem} ${
                    selectedTeam === team.id ? styles.active : ""
                  }`}
                  onClick={() => handleTeamClick(team.id)}
                >
                  {team.name}
                </div>
              ))}
            </div>
          </div>

          <div className={styles.usersPanel}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "16px",
                borderBottom: "1px solid #d9d9d9",
              }}
            >
              <h3 className={styles.panelTitle}>
                Users mapped({users.length})
              </h3>
              <div style={{ display: "flex", gap: "8px" }}>
                {!isEditMode ? (
                  <ReusableButton
                    variant="primary"
                    onClick={handleEdit}
                    disabled={!selectedTeam}
                  >
                    Edit Team Members
                  </ReusableButton>
                ) : (
                  <>
                    <ReusableButton
                      variant="primary"
                      onClick={handleSave}
                      disabled={!hasChanges || saving}
                    >
                      {saving ? "Saving..." : "Save"}
                    </ReusableButton>
                    <ReusableButton
                      variant="secondary"
                      onClick={handleCancel}
                      disabled={saving}
                    >
                      Cancel
                    </ReusableButton>
                  </>
                )}
              </div>
            </div>
            <div className={styles.usersContent}>
              {isEditMode ? (
                <Transfer
                  dataSource={allUsers.map((user) => ({
                    key: user.id,
                    title: `${user.firstname} ${user.lastname}`,
                    description: user.email,
                    disabled: false,
                  }))}
                  targetKeys={selectedUserIds}
                  onChange={handleTransferChange}
                  render={(item) => `${item.title} - ${item.description}`}
                  showSearch
                  filterOption={(inputValue, option) =>
                    option
                      .title!.toLowerCase()
                      .indexOf(inputValue.toLowerCase()) > -1 ||
                    option
                      .description!.toLowerCase()
                      .indexOf(inputValue.toLowerCase()) > -1
                  }
                  listStyle={{
                    width: 300,
                    height: 400,
                  }}
                  titles={["Available Users", "Team Users"]}
                />
              ) : users.length === 0 && !loading ? (
                <EmptyData
                  icon="👥"
                  title="No Users Found"
                  description="This team has no users assigned yet."
                />
              ) : (
                <DataTable
                  data={users}
                  columns={columns}
                  size="small"
                  rowKey="id"
                  pagination={true}
                  loading={loading}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
