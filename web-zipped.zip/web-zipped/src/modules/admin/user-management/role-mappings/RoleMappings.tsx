import React, { useState, useEffect } from "react";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import styles from "./RoleMappings.module.scss";
import LabeledCheckbox from "../../../../components/LabeledCheckbox/LabeledCheckbox";
import Spinner from "../../../../components/spinner";
import EmptyData from "../../../../components/EmptyData/EmptyData";
import { roleService } from "../user-management.service";
import type { RoleDTO, PrivilegeDTO } from "../user-management.types";

interface Privilege {
  id: string;
  name: string;
  displayName: string;
}

interface Role {
  id: string;
  name: string;
  displayName: string;
}

interface RolePrivilegeMapping {
  [roleId: string]: string[]; // roleId -> array of privilegeIds
}

export default function RoleMappings() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [privileges, setPrivileges] = useState<Privilege[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingPrivileges, setLoadingPrivileges] = useState<boolean>(false);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [mappings, setMappings] = useState<RolePrivilegeMapping>({});

  // Fetch roles and privileges on mount
  useEffect(() => {
    fetchInitialData();
  }, []);

  // Fetch role privileges when role is selected
  useEffect(() => {
    if (selectedRole) {
      fetchRolePrivileges(selectedRole);
    }
  }, [selectedRole]);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      // Only load roles on initial page load
      const rolesData = await roleService.getAllRoles();

      // Transform roles
      const transformedRoles: Role[] = rolesData.map((role: RoleDTO) => ({
        id: role.id,
        name: role.name,
        displayName: role.displayName,
      }));

      setRoles(transformedRoles);

      // Set first role as selected if available
      // This will trigger fetchRolePrivileges via useEffect
      if (transformedRoles.length > 0) {
        setSelectedRole(transformedRoles[0].id);
      }
    } catch (error) {
      console.error("Error loading roles:", error);
      showMessage.error(getErrorMessage(error, "Failed to load roles."));
    } finally {
      setLoading(false);
    }
  };

  const fetchRolePrivileges = async (roleId: string) => {
    try {
      setLoadingPrivileges(true);
      const privilegesData = await roleService.getRolePrivileges(roleId);

      // Transform and store privileges for display
      const transformedPrivileges: Privilege[] = privilegesData.map(
        (privilege: PrivilegeDTO) => ({
          id: privilege.id,
          name: privilege.name,
          displayName: privilege.displayName,
        })
      );

      setPrivileges(transformedPrivileges);

      // Store privilege IDs in mapping
      const privilegeIds = privilegesData.map((p: PrivilegeDTO) => p.id);
      setMappings((prev) => ({
        ...prev,
        [roleId]: privilegeIds,
      }));
    } catch (error) {
      console.error("Error fetching role privileges:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to load privileges for selected role.")
      );
    } finally {
      setLoadingPrivileges(false);
    }
  };

  const handleRoleClick = (roleId: string) => {
    setSelectedRole(roleId);
  };

  const isPrivilegeSelected = (privilegeId: string): boolean => {
    const currentPrivileges = mappings[selectedRole] || [];
    return currentPrivileges.includes(privilegeId);
  };

  if (loading) {
    return <Spinner />;
  }

  if (roles.length === 0 && !loading) {
    return (
      <EmptyData
        icon="🔐"
        title="No Roles Available"
        description="There are no roles configured in the system yet."
      />
    );
  }

  return (
    <div className={styles.roleMappings}>
      <div className={styles.content}>
        <div className={styles.rolesPanel}>
          <h3 className={styles.panelTitle}>Roles</h3>
          <div className={styles.rolesList}>
            {roles.map((role) => (
              <div
                key={role.id}
                className={`${styles.roleItem} ${
                  selectedRole === role.id ? styles.active : ""
                }`}
                onClick={() => handleRoleClick(role.id)}
              >
                {role.displayName}
              </div>
            ))}
          </div>
        </div>

        <div className={styles.privilegesPanel}>
          <h3 className={styles.panelTitle}>Privileges mapped</h3>
          <div className={styles.privilegesContent}>
            {loadingPrivileges ? (
              <Spinner />
            ) : privileges.length === 0 ? (
              <EmptyData
                icon="🔒"
                title="No Privileges Found"
                description="No privileges are mapped to this role."
              />
            ) : (
              <div className={styles.privilegesList}>
                {privileges.map((privilege) => (
                  <LabeledCheckbox
                    key={privilege.id}
                    label={privilege.displayName}
                    checked={isPrivilegeSelected(privilege.id)}
                    disabled={true}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
