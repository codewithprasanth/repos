import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import styles from "./CreateRole.module.scss";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import { roleService } from "../user-management.service";
import type { CreateRoleRequest, PrivilegeDTO } from "../user-management.types";

interface RoleFormData {
  roleName: string;
  description: string;
  privilegeIds: string[];
}

export default function CreateRole() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [privileges, setPrivileges] = useState<PrivilegeDTO[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<RoleFormData>({
    mode: "onBlur",
    defaultValues: {
      roleName: "",
      description: "",
      privilegeIds: [],
    },
  });

  useEffect(() => {
    fetchPrivileges();
  }, []);

  const fetchPrivileges = async () => {
    try {
      setLoadingData(true);
      const privilegesData = await roleService.getAllPrivileges();
      setPrivileges(privilegesData);
    } catch (error) {
      console.error("Error fetching privileges:", error);
      showMessage.error(getErrorMessage(error, "Failed to load privileges"));
    } finally {
      setLoadingData(false);
    }
  };

  const onSubmit = async (data: RoleFormData) => {
    try {
      setLoading(true);
      const createData: CreateRoleRequest = {
        roleName: data.roleName,
        description: data.description,
        privilegeIds: data.privilegeIds,
      };
      await roleService.createRole(createData);
      showMessage.success("Role created successfully");
      navigate("/admin/user-management/overview");
    } catch (error) {
      console.error("Error creating role:", error);
      showMessage.error(getErrorMessage(error, "Failed to create role"));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/admin/user-management/overview");
  };

  const privilegeOptions = privileges.map((privilege) => ({
    label: privilege.displayName,
    value: privilege.id,
  }));

  return (
    <div className={styles.createRole}>
      <div className={styles.header}>
        <h2>Create Role</h2>
        <div className={styles.actions}>
          <ReusableButton variant="secondary" onClick={handleCancel}>
            Cancel
          </ReusableButton>
          <ReusableButton
            variant="primary"
            onClick={handleSubmit(onSubmit)}
            disabled={loading}
          >
            {loading ? "Creating..." : "Create"}
          </ReusableButton>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className={styles.formContent}>
        <div className={styles.formGrid}>
          <Controller
            name="roleName"
            control={control}
            rules={{ required: "Role name is required" }}
            render={({ field }) => (
              <LabeledInput
                label="Role Name"
                placeholder="Enter role name"
                required
                error={errors.roleName?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="description"
            control={control}
            rules={{ required: "Description is required" }}
            render={({ field }) => (
              <LabeledInput
                label="Role Description"
                placeholder="Enter role description"
                required
                error={errors.description?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="privilegeIds"
            control={control}
            render={({ field }) => (
              <LabeledSelect
                label="Privileges"
                placeholder="Select privileges"
                options={privilegeOptions}
                mode="multiple"
                error={errors.privilegeIds?.message}
                loading={loadingData}
                showSearch
                {...field}
              />
            )}
          />
        </div>
      </form>
    </div>
  );
}
