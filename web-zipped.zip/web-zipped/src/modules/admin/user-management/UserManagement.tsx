import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import styles from "./UserManagement.module.scss";
import ReusableTab from "../../../components/ReusableTab/ReusableTab";
import type { TabItem } from "../../../components/ReusableTab/ReusableTab";
import UserList from "./user-list/UserList";
import RoleMappings from "./role-mappings/RoleMappings";
import TeamUserMappings from "./team-user-mappings/TeamUserMappings";

export default function UserManagement() {
  const location = useLocation();
  const navigate = useNavigate();

  // Tab items
  const tabItems: TabItem[] = [
    {
      key: "users",
      label: "Users",
      children: <UserList />,
    },
    // {
    //   key: "roles",
    //   label: "Roles",
    //   children: <RoleList />,
    // },
    // {
    //   key: "privileges",
    //   label: "Privileges",
    //   children: <PrivilegeList />,
    // },
    // {
    //   key: "teams",
    //   label: "Teams",
    //   children: <TeamList />,
    // },
    {
      key: "role-mappings",
      label: "Roles",
      children: <RoleMappings />,
    },
    {
      key: "team-user-mappings",
      label: "Teams",
      children: <TeamUserMappings />,
    },
    // {
    //   key: "team-role-privilege-mappings",
    //   label: "Team Role Privilege Mappings",
    //   children: <TeamRolePrivilegeMappings />,
    // },
  ];

  // Derive active tab from URL hash
  const hash = location.hash.replace("#", "") || "";
  const activeKey = tabItems.some((item) => item.key === hash) ? hash : "users";

  // Handle tab change
  const handleTabChange = (key: string) => {
    navigate(`#${key}`, { replace: true });
  };

  // Set default hash if none exists on mount
  React.useEffect(() => {
    const currentHash = location.hash.replace("#", "");
    if (!currentHash) {
      navigate("#users", { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only on mount

  return (
    <div className={styles.userManagement}>
      <h1>User Management</h1>
      <ReusableTab
        items={tabItems}
        activeKey={activeKey}
        onChange={handleTabChange}
      />
    </div>
  );
}
