import { axiosInstance } from "../../../auth/axios-config";
import { API_ENDPOINTS } from "../../../config/apis";
import type {
  RoleDTO,
  PrivilegeDTO,
  GroupDTO,
  UserDTO,
  CreateRoleRequest,
  UpdateRoleRequest,
  CreateGroupRequest,
  UpdateGroupUsersRequest,
  UpdateGroupRolesPrivilegesRequest,
  CreateUserRequest,
  UpdateUserRequest,
  ApiResponse,
  PaginatedResponse,
} from "./user-management.types";

// ============= Role Management Services =============

export const roleService = {
  /**
   * Get all roles
   */
  getAllRoles: async (): Promise<RoleDTO[]> => {
    const response = await axiosInstance.get<RoleDTO[]>(
      API_ENDPOINTS.USER_MANAGEMENT.GET_ALL_ROLES
    );
    return response.data;
  },

  /**
   * Create a new role
   */
  createRole: async (
    data: CreateRoleRequest
  ): Promise<ApiResponse<RoleDTO>> => {
    const response = await axiosInstance.post<ApiResponse<RoleDTO>>(
      API_ENDPOINTS.USER_MANAGEMENT.CREATE_ROLE,
      data
    );
    return response.data;
  },

  /**
   * Get privileges for a specific role
   */
  getRolePrivileges: async (roleId: string): Promise<PrivilegeDTO[]> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.GET_ROLE_PRIVILEGES.replace(
      ":roleId",
      roleId
    );
    const response = await axiosInstance.get<PrivilegeDTO[]>(url);
    return response.data;
  },

  /**
   * Get all available privileges
   */
  getAllPrivileges: async (): Promise<PrivilegeDTO[]> => {
    const response = await axiosInstance.get<PrivilegeDTO[]>(
      API_ENDPOINTS.USER_MANAGEMENT.GET_ALL_PRIVILEGES
    );
    return response.data;
  },

  /**
   * Update a role
   */
  updateRole: async (
    roleId: string,
    data: UpdateRoleRequest
  ): Promise<ApiResponse<RoleDTO>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.UPDATE_ROLE.replace(
      ":roleId",
      roleId
    );
    const response = await axiosInstance.put<ApiResponse<RoleDTO>>(url, data);
    return response.data;
  },

  /**
   * Delete a role
   */
  deleteRole: async (roleId: string): Promise<ApiResponse<void>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.DELETE_ROLE.replace(
      ":roleId",
      roleId
    );
    const response = await axiosInstance.delete<ApiResponse<void>>(url);
    return response.data;
  },
};

// ============= Group Management Services =============

export const groupService = {
  /**
   * Get all groups
   */
  getAllGroups: async (): Promise<GroupDTO[]> => {
    const response = await axiosInstance.get<GroupDTO[]>(
      API_ENDPOINTS.USER_MANAGEMENT.GET_ALL_GROUPS
    );
    return response.data;
  },

  /**
   * Create a new group
   */
  createGroup: async (
    data: CreateGroupRequest
  ): Promise<ApiResponse<GroupDTO>> => {
    const response = await axiosInstance.post<ApiResponse<GroupDTO>>(
      API_ENDPOINTS.USER_MANAGEMENT.CREATE_GROUP,
      data
    );
    return response.data;
  },

  /**
   * Get roles and privileges for a group
   */
  getGroupRolesPrivileges: async (
    groupId: string
  ): Promise<{ roles: RoleDTO[]; privileges: PrivilegeDTO[] }> => {
    const url =
      API_ENDPOINTS.USER_MANAGEMENT.GET_GROUP_ROLES_PRIVILEGES.replace(
        ":groupId",
        groupId
      );
    const response = await axiosInstance.get<{
      roles: RoleDTO[];
      privileges: PrivilegeDTO[];
    }>(url);
    return response.data;
  },

  /**
   * Get users in a group
   */
  getGroupUsers: async (groupId: string): Promise<UserDTO[]> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.GET_GROUP_USERS.replace(
      ":groupId",
      groupId
    );
    const response = await axiosInstance.get<UserDTO[]>(url);
    return response.data;
  },

  /**
   * Update users in a group
   */
  updateGroupUsers: async (
    groupId: string,
    data: UpdateGroupUsersRequest
  ): Promise<ApiResponse<void>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.UPDATE_GROUP_USERS.replace(
      ":groupId",
      groupId
    );
    const response = await axiosInstance.put<ApiResponse<void>>(url, data);
    return response.data;
  },

  /**
   * Update roles and privileges for a group
   */
  updateGroupRolesPrivileges: async (
    groupId: string,
    data: UpdateGroupRolesPrivilegesRequest
  ): Promise<ApiResponse<void>> => {
    const url =
      API_ENDPOINTS.USER_MANAGEMENT.UPDATE_GROUP_ROLES_PRIVILEGES.replace(
        ":groupId",
        groupId
      );
    const response = await axiosInstance.put<ApiResponse<void>>(url, data);
    return response.data;
  },

  /**
   * Delete a group
   */
  deleteGroup: async (groupId: string): Promise<ApiResponse<void>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.DELETE_GROUP.replace(
      ":groupId",
      groupId
    );
    const response = await axiosInstance.delete<ApiResponse<void>>(url);
    return response.data;
  },
};

// ============= User Management Services =============

export const userService = {
  /**
   * Get all users with optional search filter and pagination
   */
  getAllUsers: async (
    keyword?: string,
    pageSize?: number,
    pageNumber?: number,
    sortBy?: string,
    sortOrder?: string,
    role?: string
  ): Promise<PaginatedResponse<UserDTO>> => {
    const params: any = {};
    if (keyword) params.keyword = keyword;
    if (pageSize) params.pageSize = pageSize;
    if (pageNumber) params.pageNumber = pageNumber;
    if (sortBy) params.sortBy = sortBy;
    if (sortOrder) params.sortOrder = sortOrder;
    if (role) params.role = role;

    const response = await axiosInstance.get<PaginatedResponse<UserDTO>>(
      API_ENDPOINTS.USER_MANAGEMENT.GET_ALL_USERS,
      { params }
    );
    return response.data;
  },

  /**
   * Create a new user
   */
  createUser: async (
    data: CreateUserRequest
  ): Promise<ApiResponse<UserDTO>> => {
    const response = await axiosInstance.post<ApiResponse<UserDTO>>(
      API_ENDPOINTS.USER_MANAGEMENT.CREATE_USER,
      data
    );
    return response.data;
  },

  /**
   * Get user by ID
   */
  getUserById: async (userId: string): Promise<UserDTO> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.GET_USER_BY_ID.replace(
      ":userId",
      userId
    );
    const response = await axiosInstance.get<UserDTO>(url);
    return response.data;
  },

  /**
   * Update a user
   */
  updateUser: async (
    userId: string,
    data: UpdateUserRequest
  ): Promise<ApiResponse<UserDTO>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.UPDATE_USER.replace(
      ":userId",
      userId
    );
    const response = await axiosInstance.put<ApiResponse<UserDTO>>(url, data);
    return response.data;
  },

  /**
   * Delete a user
   */
  deleteUser: async (userId: string): Promise<ApiResponse<void>> => {
    const url = API_ENDPOINTS.USER_MANAGEMENT.DELETE_USER.replace(
      ":userId",
      userId
    );
    const response = await axiosInstance.delete<ApiResponse<void>>(url);
    return response.data;
  },
};
