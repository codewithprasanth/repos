import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import styles from "./CreateTeam.module.scss";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LiveSearch from "../../../../components/LiveSearch/LiveSearch";
import { groupService, userService } from "../user-management.service";
import type { CreateGroupRequest, UserDTO } from "../user-management.types";

interface TeamFormData {
  groupName: string;
  userIds: string[];
}

export default function CreateTeam() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<TeamFormData>({
    mode: "onBlur",
    defaultValues: {
      groupName: "",
      userIds: [],
    },
  });

  const onSubmit = async (data: TeamFormData) => {
    try {
      setLoading(true);
      const createData: CreateGroupRequest = {
        groupName: data.groupName,
        userIds: data.userIds,
      };
      await groupService.createGroup(createData);
      showMessage.success("Team created successfully");
      navigate("/admin/user-management/overview");
    } catch (error) {
      console.error("Error creating team:", error);
      showMessage.error(getErrorMessage(error, "Failed to create team"));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/admin/user-management/overview");
  };

  const fetchUsers = async (keyword?: string): Promise<UserDTO[]> => {
    try {
      const response = await userService.getAllUsers();
      const users = response.data;
      if (keyword) {
        const lowerKeyword = keyword.toLowerCase();
        return users.filter(
          (user) =>
            user.firstName.toLowerCase().includes(lowerKeyword) ||
            user.lastName.toLowerCase().includes(lowerKeyword) ||
            user.email.toLowerCase().includes(lowerKeyword)
        );
      }
      return users;
    } catch (error) {
      console.error("Error fetching users:", error);
      return [];
    }
  };

  return (
    <div className={styles.createTeam}>
      <div className={styles.header}>
        <h2>Create Team</h2>
        <div className={styles.actions}>
          <ReusableButton variant="secondary" onClick={handleCancel}>
            Cancel
          </ReusableButton>
          <ReusableButton
            variant="primary"
            onClick={handleSubmit(onSubmit)}
            disabled={loading}
          >
            {loading ? "Creating..." : "Create"}
          </ReusableButton>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className={styles.formContent}>
        <div className={styles.formGrid}>
          <Controller
            name="groupName"
            control={control}
            rules={{ required: "Team name is required" }}
            render={({ field }) => (
              <LabeledInput
                label="Team Name"
                placeholder="Enter team name"
                required
                error={errors.groupName?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="userIds"
            control={control}
            render={({ field }) => (
              <LiveSearch<UserDTO>
                label="Users"
                placeholder="Search and select users"
                mode="multiple"
                allowClear
                fetchFunction={fetchUsers}
                getOptionValue={(user) => user.id}
                getOptionLabel={(user) =>
                  `${user.firstName} ${user.lastName} (${user.email})`
                }
                value={field.value}
                onChange={(value) => field.onChange(value)}
                error={errors.userIds?.message}
              />
            )}
          />
        </div>
      </form>
    </div>
  );
}
