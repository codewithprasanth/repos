import React, { useState, useEffect } from "react";
import { Tag } from "antd";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import styles from "./TeamRolePrivilegeMappings.module.scss";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledCheckbox from "../../../../components/LabeledCheckbox/LabeledCheckbox";
import { groupService, roleService } from "../user-management.service";
import type { GroupDTO, RoleDTO, PrivilegeDTO } from "../user-management.types";

interface Team {
  id: string;
  name: string;
}

interface Role {
  id: string;
  name: string;
  displayName: string;
}

interface Privilege {
  id: string;
  name: string;
  displayName: string;
}

interface TeamRoleMapping {
  [teamId: string]: string[]; // teamId -> array of roleIds
}

interface TeamPrivilegeMapping {
  [teamId: string]: string[]; // teamId -> array of privilegeIds
}

export default function TeamRolePrivilegeMappings() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [privileges, setPrivileges] = useState<Privilege[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState<string>("");
  const [roleMappings, setRoleMappings] = useState<TeamRoleMapping>({});
  const [privilegeMappings, setPrivilegeMappings] =
    useState<TeamPrivilegeMapping>({});
  const [savedRoleMappings, setSavedRoleMappings] = useState<TeamRoleMapping>(
    {}
  );
  const [savedPrivilegeMappings, setSavedPrivilegeMappings] =
    useState<TeamPrivilegeMapping>({});
  const [hasChanges, setHasChanges] = useState(false);
  const [enableMappings, setEnableMappings] = useState(true);

  // Fetch initial data
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        setLoading(true);
        const [groupsRes, rolesRes, privilegesRes] = await Promise.all([
          groupService.getAllGroups(),
          roleService.getAllRoles(),
          roleService.getAllPrivileges(),
        ]);

        const fetchedTeams: Team[] = groupsRes.map((g: GroupDTO) => ({
          id: g.id,
          name: g.name,
        }));

        const fetchedRoles: Role[] = rolesRes.map((r: RoleDTO) => ({
          id: r.id,
          name: r.name,
          displayName: r.displayName,
        }));

        const fetchedPrivileges: Privilege[] = privilegesRes.map(
          (p: PrivilegeDTO) => ({
            id: p.id,
            name: p.name,
            displayName: p.displayName,
          })
        );

        setTeams(fetchedTeams);
        setRoles(fetchedRoles);
        setPrivileges(fetchedPrivileges);

        if (fetchedTeams.length > 0) {
          setSelectedTeam(fetchedTeams[0].id);
        }
      } catch (error) {
        console.error("Error fetching initial data:", error);
        showMessage.error(getErrorMessage(error, "Failed to load data"));
      } finally {
        setLoading(false);
      }
    };

    fetchInitialData();
  }, []);

  // Fetch team roles and privileges when team is selected
  useEffect(() => {
    if (!selectedTeam) return;

    const fetchTeamMappings = async () => {
      try {
        const result = await groupService.getGroupRolesPrivileges(selectedTeam);

        const roleIds = result.roles.map((r: RoleDTO) => r.id);
        const privilegeIds = result.privileges.map((p: PrivilegeDTO) => p.id);

        setRoleMappings((prev) => ({ ...prev, [selectedTeam]: roleIds }));
        setPrivilegeMappings((prev) => ({
          ...prev,
          [selectedTeam]: privilegeIds,
        }));
        setSavedRoleMappings((prev) => ({ ...prev, [selectedTeam]: roleIds }));
        setSavedPrivilegeMappings((prev) => ({
          ...prev,
          [selectedTeam]: privilegeIds,
        }));
      } catch (error) {
        console.error("Error fetching team mappings:", error);
        showMessage.error(
          getErrorMessage(error, "Failed to load team mappings")
        );
      }
    };

    fetchTeamMappings();
  }, [selectedTeam]);

  // Check if there are unsaved changes
  useEffect(() => {
    const currentRoles = roleMappings[selectedTeam] || [];
    const savedRoles = savedRoleMappings[selectedTeam] || [];
    const currentPrivileges = privilegeMappings[selectedTeam] || [];
    const savedPrivileges = savedPrivilegeMappings[selectedTeam] || [];

    const rolesChanged =
      currentRoles.length !== savedRoles.length ||
      currentRoles.some((id) => !savedRoles.includes(id));

    const privilegesChanged =
      currentPrivileges.length !== savedPrivileges.length ||
      currentPrivileges.some((id) => !savedPrivileges.includes(id));

    setHasChanges(rolesChanged || privilegesChanged);
  }, [
    roleMappings,
    privilegeMappings,
    savedRoleMappings,
    savedPrivilegeMappings,
    selectedTeam,
  ]);

  const handleTeamClick = (teamId: string) => {
    setSelectedTeam(teamId);
  };

  const handleRoleChange = (roleId: string, checked: boolean) => {
    if (!enableMappings) return;

    setRoleMappings((prev) => {
      const currentRoles = prev[selectedTeam] || [];
      const newRoles = checked
        ? [...currentRoles, roleId]
        : currentRoles.filter((id) => id !== roleId);

      return {
        ...prev,
        [selectedTeam]: newRoles,
      };
    });
  };

  const handlePrivilegeChange = (privilegeId: string, checked: boolean) => {
    if (!enableMappings) return;

    setPrivilegeMappings((prev) => {
      const currentPrivileges = prev[selectedTeam] || [];
      const newPrivileges = checked
        ? [...currentPrivileges, privilegeId]
        : currentPrivileges.filter((id) => id !== privilegeId);

      return {
        ...prev,
        [selectedTeam]: newPrivileges,
      };
    });
  };

  const handleEnableMappingsChange = (checked: boolean) => {
    setEnableMappings(checked);

    // If disabled, clear all mappings for the current team
    if (!checked) {
      setRoleMappings((prev) => ({
        ...prev,
        [selectedTeam]: [],
      }));
      setPrivilegeMappings((prev) => ({
        ...prev,
        [selectedTeam]: [],
      }));
    }
  };

  const isRoleSelected = (roleId: string): boolean => {
    const currentRoles = roleMappings[selectedTeam] || [];
    return currentRoles.includes(roleId);
  };

  const isPrivilegeSelected = (privilegeId: string): boolean => {
    const currentPrivileges = privilegeMappings[selectedTeam] || [];
    return currentPrivileges.includes(privilegeId);
  };

  const handleSave = async () => {
    try {
      const currentRoles = roleMappings[selectedTeam] || [];
      const savedRoles = savedRoleMappings[selectedTeam] || [];
      const currentPrivileges = privilegeMappings[selectedTeam] || [];
      const savedPrivileges = savedPrivilegeMappings[selectedTeam] || [];

      // Calculate differences
      const roleIdsToAdd = currentRoles.filter(
        (id) => !savedRoles.includes(id)
      );
      const roleIdsToRemove = savedRoles.filter(
        (id) => !currentRoles.includes(id)
      );
      const privilegeIdsToAdd = currentPrivileges.filter(
        (id) => !savedPrivileges.includes(id)
      );
      const privilegeIdsToRemove = savedPrivileges.filter(
        (id) => !currentPrivileges.includes(id)
      );

      await groupService.updateGroupRolesPrivileges(selectedTeam, {
        roleIdsToAdd,
        roleIdsToRemove,
        privilegeIdsToAdd,
        privilegeIdsToRemove,
      });

      setSavedRoleMappings({ ...roleMappings });
      setSavedPrivilegeMappings({ ...privilegeMappings });
      setHasChanges(false);
      showMessage.success(
        "Team role and privilege mappings saved successfully"
      );
    } catch (error) {
      console.error("Error saving mappings:", error);
      showMessage.error(getErrorMessage(error, "Failed to save mappings"));
    }
  };

  const handleDiscard = () => {
    console.log("Discarding changes");
    setRoleMappings({ ...savedRoleMappings });
    setPrivilegeMappings({ ...savedPrivilegeMappings });
    setHasChanges(false);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (teams.length === 0) {
    return (
      <div className={styles.teamRolePrivilegeMappings}>
        <div className={styles.pageEmptyState}>
          <div className={styles.emptyIcon}>📋</div>
          <h3>No Teams Available</h3>
          <p>There are no teams configured in the system yet.</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.teamRolePrivilegeMappings}>
      {(roles.length > 0 || privileges.length > 0) && (
        <div className={styles.actionButtons}>
          <ReusableButton
            variant="primary"
            onClick={handleSave}
            disabled={!hasChanges}
          >
            Save
          </ReusableButton>
          <ReusableButton
            variant="secondary"
            onClick={handleDiscard}
            disabled={!hasChanges}
          >
            Discard
          </ReusableButton>
        </div>
      )}

      <div className={styles.content}>
        <div className={styles.teamsPanel}>
          <h3 className={styles.panelTitle}>Teams</h3>
          <div className={styles.teamsList}>
            {teams.map((team) => (
              <div
                key={team.id}
                className={`${styles.teamItem} ${
                  selectedTeam === team.id ? styles.active : ""
                }`}
                onClick={() => handleTeamClick(team.id)}
              >
                {team.name}
              </div>
            ))}
          </div>
        </div>

        <div className={styles.rolesPrivilegesPanel}>
          <h3 className={styles.panelTitle}>Roles & Privileges</h3>
          <div className={styles.rolesPrivilegesContent}>
            {/* Toggle Checkbox */}
            <div className={styles.toggleSection}>
              <LabeledCheckbox
                label="Enable Role/Privilege mappings for teams"
                checked={enableMappings}
                onChange={(e) => handleEnableMappingsChange(e.target.checked)}
              />
            </div>

            {/* Roles Section */}
            {enableMappings && roles.length > 0 && (
              <div className={styles.rolesSection}>
                <h4 className={styles.sectionTitle}>Roles</h4>
                <div className={styles.rolesTags}>
                  {roles.map((role) => (
                    <Tag
                      key={role.id}
                      color={isRoleSelected(role.id) ? "#2d5a5a" : "default"}
                      className={styles.roleTag}
                      onClick={() =>
                        handleRoleChange(role.id, !isRoleSelected(role.id))
                      }
                    >
                      {role.displayName}
                    </Tag>
                  ))}
                </div>
              </div>
            )}

            {/* Privileges Section */}
            {enableMappings && privileges.length > 0 && (
              <div className={styles.privilegesSection}>
                <h4 className={styles.sectionTitle}>Privileges</h4>
                <div className={styles.privilegesGrid}>
                  {privileges.map((privilege) => (
                    <LabeledCheckbox
                      key={privilege.id}
                      label={privilege.displayName}
                      checked={isPrivilegeSelected(privilege.id)}
                      onChange={(e) =>
                        handlePrivilegeChange(privilege.id, e.target.checked)
                      }
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
