import React, { useState, useEffect } from "react";
import { message } from "antd";
import type { ColumnsType } from "antd/es/table";
import styles from "../UserManagement.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import Spinner from "../../../../components/spinner";
import { roleService } from "../user-management.service";
import type { PrivilegeDTO } from "../user-management.types";

export interface Privilege {
  id: string;
  name: string;
  displayName: string;
  description: string;
}

export default function PrivilegeList() {
  const [privileges, setPrivileges] = useState<Privilege[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch privileges from API
  useEffect(() => {
    fetchPrivileges();
  }, []);

  const fetchPrivileges = async () => {
    try {
      setLoading(true);
      const data = await roleService.getAllPrivileges();

      // Transform PrivilegeDTO to Privilege interface
      const transformedPrivileges: Privilege[] = data.map(
        (privilege: PrivilegeDTO) => ({
          id: privilege.id,
          name: privilege.name,
          displayName: privilege.displayName,
          description: privilege.description,
        })
      );

      setPrivileges(transformedPrivileges);
    } catch (error) {
      console.error("Error fetching privileges:", error);
      message.error("Failed to load privileges. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Column definitions for Privileges DataTable
  const privilegeColumns: ColumnsType<Privilege> = [
    {
      title: "Privilege Name",
      dataIndex: "displayName",
      key: "displayName",
      width: 250,
      sorter: true,
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
      sorter: true,
    },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (privileges.length === 0) {
    return (
      <div className={styles.pageEmptyState}>
        <div className={styles.emptyIcon}>🔑</div>
        <h3>No Privileges Available</h3>
        <p>There are no privileges configured in the system yet.</p>
      </div>
    );
  }

  return (
    <>
      <DataTable
        data={privileges}
        columns={privilegeColumns}
        size="small"
        rowKey="id"
        pagination={true}
        loading={loading}
      />
    </>
  );
}
