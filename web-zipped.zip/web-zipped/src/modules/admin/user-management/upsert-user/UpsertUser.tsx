import React, { useEffect, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import styles from "./UpsertUser.module.scss";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import LabeledToggle from "../../../../components/LabeledToggle/LabeledToggle";
import {
  userService,
  roleService,
  groupService,
} from "../user-management.service";
import type {
  CreateUserRequest,
  UpdateUserRequest,
  RoleDTO,
  GroupDTO,
} from "../user-management.types";

interface UserFormData {
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  enabled: boolean;
  entityCode: string;
  countryCode: string;
  roleIds: string[];
  groupIds: string[];
}

// Sample data for entity and country
const ENTITY_OPTIONS = [
  { label: "Entity 001", value: "ENT001" },
  { label: "Entity 002", value: "ENT002" },
  { label: "Entity 003", value: "ENT003" },
];

const COUNTRY_OPTIONS = [
  { label: "United States", value: "US" },
  { label: "United Kingdom", value: "UK" },
  { label: "Canada", value: "CA" },
  { label: "India", value: "IN" },
  { label: "Australia", value: "AU" },
];

export default function UpsertUser() {
  const navigate = useNavigate();
  const { userId } = useParams<{ userId: string }>();
  const location = useLocation();

  const [loading, setLoading] = useState(false);
  const [roles, setRoles] = useState<RoleDTO[]>([]);
  const [groups, setGroups] = useState<GroupDTO[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [originalRoleIds, setOriginalRoleIds] = useState<string[]>([]);
  const [originalGroupIds, setOriginalGroupIds] = useState<string[]>([]);

  const isCreateMode = location.pathname.includes("create-user");
  const isUpdateMode = location.pathname.includes("update-user");

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<UserFormData>({
    mode: "onBlur",
    defaultValues: {
      email: "",
      firstName: "",
      lastName: "",
      password: "",
      enabled: true,
      entityCode: "",
      countryCode: "",
      roleIds: [],
      groupIds: [],
    },
  });

  useEffect(() => {
    fetchDropdownData();
  }, []);

  useEffect(() => {
    if (isUpdateMode && userId) {
      fetchUserDetails(userId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isUpdateMode, userId]);

  const fetchDropdownData = async () => {
    try {
      setLoadingData(true);
      const [rolesData, groupsData] = await Promise.all([
        roleService.getAllRoles(),
        groupService.getAllGroups(),
      ]);
      setRoles(rolesData);
      setGroups(groupsData);
    } catch (error) {
      console.error("Error fetching dropdown data:", error);
      showMessage.error("Failed to load roles and groups");
    } finally {
      setLoadingData(false);
    }
  };

  const fetchUserDetails = async (id: string) => {
    try {
      const user = await userService.getUserById(id);
      const userRoleIds = user.roles.map((r) => r.roleId);
      const userGroupIds = user.groups.map((g) => g.groupId);

      setValue("email", user.email);
      setValue("firstName", user.firstName);
      setValue("lastName", user.lastName);
      setValue("enabled", user.enabled);
      setValue("entityCode", user.attributes?.entity_code?.[0] || "");
      setValue("countryCode", user.attributes?.country_code?.[0] || "");
      setValue("roleIds", userRoleIds);
      setValue("groupIds", userGroupIds);

      // Store original values for comparison during update
      setOriginalRoleIds(userRoleIds);
      setOriginalGroupIds(userGroupIds);
    } catch (error) {
      console.error("Error fetching user details:", error);
      showMessage.error("Failed to load user details");
    }
  };

  const onSubmit = async (data: UserFormData) => {
    try {
      setLoading(true);
      if (isCreateMode) {
        const createData: CreateUserRequest = {
          email: data.email,
          firstName: data.firstName,
          lastName: data.lastName,
          password: data.password,
          enabled: data.enabled,
          emailVerified: false,
          entityCode: data.entityCode,
          countryCode: data.countryCode,
          roleIds: data.roleIds,
          groupIds: data.groupIds,
        };
        await userService.createUser(createData);
        showMessage.success("User created successfully");
      } else if (isUpdateMode && userId) {
        // Calculate which roles to add and remove
        const roleIdsToAdd = data.roleIds.filter(
          (id) => !originalRoleIds.includes(id)
        );
        const roleIdsToRemove = originalRoleIds.filter(
          (id) => !data.roleIds.includes(id)
        );

        // Calculate which groups to add and remove
        const groupIdsToAdd = data.groupIds.filter(
          (id) => !originalGroupIds.includes(id)
        );
        const groupIdsToRemove = originalGroupIds.filter(
          (id) => !data.groupIds.includes(id)
        );

        const updateData: UpdateUserRequest = {
          email: data.email,
          firstName: data.firstName,
          lastName: data.lastName,
          enabled: data.enabled,
          emailVerified: false,
          entityCode: data.entityCode,
          countryCode: data.countryCode,
          roleIdsToAdd: roleIdsToAdd.length > 0 ? roleIdsToAdd : undefined,
          roleIdsToRemove:
            roleIdsToRemove.length > 0 ? roleIdsToRemove : undefined,
          groupIdsToAdd: groupIdsToAdd.length > 0 ? groupIdsToAdd : undefined,
          groupIdsToRemove:
            groupIdsToRemove.length > 0 ? groupIdsToRemove : undefined,
        };

        await userService.updateUser(userId, updateData);
        showMessage.success("User updated successfully");
      }
      navigate("/admin/user-management/overview");
    } catch (error) {
      console.error("Error saving user:", error);
      showMessage.error(getErrorMessage(error, "Failed to save user"));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/admin/user-management/overview");
  };

  const roleOptions = roles.map((role) => ({
    label: role.displayName,
    value: role.id,
  }));

  const groupOptions = groups.map((group) => ({
    label: group.name,
    value: group.id,
  }));

  return (
    <div className={styles.upsertUser}>
      <div className={styles.header}>
        <h2>{isCreateMode ? "Create User" : "Edit User"}</h2>
        <div className={styles.actions}>
          <ReusableButton variant="secondary" onClick={handleCancel}>
            Cancel
          </ReusableButton>
          <ReusableButton
            variant="primary"
            onClick={handleSubmit(onSubmit)}
            disabled={loading}
          >
            {loading ? "Saving..." : isCreateMode ? "Create" : "Update"}
          </ReusableButton>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className={styles.formContent}>
        <div className={styles.formGrid}>
          <Controller
            name="email"
            control={control}
            rules={{
              required: "Email is required",
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: "Invalid email address",
              },
            }}
            render={({ field }) => (
              <LabeledInput
                label="Email"
                type="email"
                placeholder="Enter email"
                required
                disabled={isUpdateMode}
                error={errors.email?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="firstName"
            control={control}
            rules={{ required: "First name is required" }}
            render={({ field }) => (
              <LabeledInput
                label="First Name"
                placeholder="Enter first name"
                required
                disabled={isUpdateMode}
                error={errors.firstName?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="lastName"
            control={control}
            rules={{ required: "Last name is required" }}
            render={({ field }) => (
              <LabeledInput
                label="Last Name"
                placeholder="Enter last name"
                required
                disabled={isUpdateMode}
                error={errors.lastName?.message}
                {...field}
              />
            )}
          />

          {isCreateMode && (
            <Controller
              name="password"
              control={control}
              rules={{
                required: "Password is required",
                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters",
                },
              }}
              render={({ field }) => (
                <LabeledInput
                  label="Password"
                  type="password"
                  placeholder="Enter password"
                  required
                  error={errors.password?.message}
                  {...field}
                />
              )}
            />
          )}

          <Controller
            name="entityCode"
            control={control}
            render={({ field }) => (
              <LabeledSelect
                label="Entity"
                placeholder="Select entity"
                options={ENTITY_OPTIONS}
                error={errors.entityCode?.message}
                showSearch
                {...field}
              />
            )}
          />

          <Controller
            name="countryCode"
            control={control}
            render={({ field }) => (
              <LabeledSelect
                label="Country"
                placeholder="Select country"
                options={COUNTRY_OPTIONS}
                error={errors.countryCode?.message}
                showSearch
                {...field}
              />
            )}
          />

          <Controller
            name="roleIds"
            control={control}
            rules={{ required: "At least one role is required" }}
            render={({ field }) => (
              <LabeledSelect
                label="Roles"
                placeholder="Select roles"
                options={roleOptions}
                mode="multiple"
                required
                error={errors.roleIds?.message}
                loading={loadingData}
                showSearch
                {...field}
              />
            )}
          />

          <Controller
            name="groupIds"
            control={control}
            render={({ field }) => (
              <LabeledSelect
                label="Groups"
                placeholder="Select groups"
                options={groupOptions}
                mode="multiple"
                error={errors.groupIds?.message}
                loading={loadingData}
                showSearch
                {...field}
              />
            )}
          />

          <Controller
            name="enabled"
            control={control}
            render={({ field: { value, onChange, ...field } }) => (
              <LabeledToggle
                label="Enabled"
                checked={value}
                onChange={onChange}
                {...field}
              />
            )}
          />
        </div>
      </form>
    </div>
  );
}
