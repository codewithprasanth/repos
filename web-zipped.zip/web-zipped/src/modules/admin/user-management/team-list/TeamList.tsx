import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { Tag, Button } from "antd";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import { ConfirmPopover } from "../../../../components/ConfirmPopover";
import type { ColumnsType } from "antd/es/table";
import styles from "../UserManagement.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import IconActionButton from "../../../../components/IconActionButton/IconActionButton";
import Spinner from "../../../../components/spinner";
import EmptyData from "../../../../components/EmptyData/EmptyData";
import { groupService } from "../user-management.service";
import type { GroupDTO } from "../user-management.types";

export interface Team {
  id: string;
  name: string;
  userCount?: number;
}

export default function TeamList() {
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch teams (groups) from API
  useEffect(() => {
    fetchTeams();
  }, []);

  const fetchTeams = async () => {
    try {
      setLoading(true);
      const data = await groupService.getAllGroups();

      // Transform GroupDTO to Team interface
      const transformedTeams: Team[] = data.map((group: GroupDTO) => ({
        id: group.id,
        name: group.name,
        userCount: group.userCount,
      }));

      setTeams(transformedTeams);
    } catch (error) {
      console.error("Error fetching teams:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to load teams. Please try again.")
      );
    } finally {
      setLoading(false);
    }
  };

  const handleAddTeam = () => {
    navigate("/admin/user-management/create-team");
  };

  const handleDeleteTeam = async (team: Team) => {
    try {
      await groupService.deleteGroup(team.id);
      showMessage.success(`Team "${team.name}" deleted successfully`);
      // Refresh the teams list
      fetchTeams();
    } catch (error) {
      console.error("Error deleting team:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to delete team. Please try again.")
      );
    }
  };

  // Column definitions for Teams DataTable
  const teamColumns: ColumnsType<Team> = [
    {
      title: "Team Name",
      dataIndex: "name",
      key: "name",
      width: 150,
      sorter: true,
      render: (name: string) => {
        return <Tag>{name}</Tag>;
      },
    },
    {
      title: "Members",
      dataIndex: "userCount",
      key: "userCount",
      width: 100,
      align: "center",
      sorter: true,
      render: (memberCount?: number) => (
        <span>{memberCount !== undefined ? memberCount : "-"}</span>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      width: 120,
      align: "center",
      render: (_: unknown, record: Team) => (
        <div className={styles.actionButtons}>
          <ConfirmPopover
            title="Delete Team"
            description={`Are you sure you want to delete the team "${record.name}"? This action cannot be undone.`}
            onConfirm={() => handleDeleteTeam(record)}
            type="danger"
          >
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete Team"
              danger
            />
          </ConfirmPopover>
        </div>
      ),
    },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (teams.length === 0) {
    return (
      <EmptyData
        icon="👥"
        title="No Teams Available"
        description="There are no teams configured in the system yet."
      />
    );
  }

  return (
    <>
      <div className={styles.tabHeader}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAddTeam}
          className={styles.addButton}
        >
          Add Team
        </Button>
      </div>
      <DataTable
        data={teams}
        columns={teamColumns}
        size="small"
        rowKey="id"
        pagination={true}
        loading={loading}
      />
    </>
  );
}
