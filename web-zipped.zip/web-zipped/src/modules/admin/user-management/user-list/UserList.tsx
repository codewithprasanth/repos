import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { EditOutlined, PlusOutlined } from "@ant-design/icons";
import { Tag, Button } from "antd";
import type { ColumnsType } from "antd/es/table";
import styles from "../UserManagement.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import IconActionButton from "../../../../components/IconActionButton/IconActionButton";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import EmptyData from "../../../../components/EmptyData/EmptyData";
import { userService } from "../user-management.service";
import type { UserDTO, PaginatedResponse } from "../user-management.types";
import showMessage, { getErrorMessage } from "../../../../components/Message";

export interface User {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  roles: { roleId: string; roleName: string; roleDisplayName: string }[];
  teams: { groupId: string; groupName: string }[];
  country: string[];
  entity: string[];
  enabled: boolean;
}

export default function UserList() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchKeyword, setSearchKeyword] = useState<string>("");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [sortBy, setSortBy] = useState<string>("createdAt");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  // Fetch users from API
  useEffect(() => {
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, pageSize, sortBy, sortOrder]);

  const fetchUsers = async (keyword?: string) => {
    try {
      setLoading(true);
      const response: PaginatedResponse<UserDTO> =
        await userService.getAllUsers(
          keyword ?? searchKeyword,
          pageSize,
          currentPage,
          sortBy,
          sortOrder
        );

      console.log("Raw user data:", response);

      // Transform UserDTO to User interface
      const transformedUsers: User[] = response.data.map((user: UserDTO) => ({
        id: user.id,
        firstname: user.firstName,
        lastname: user.lastName,
        email: user.email,
        roles: user.roles || [],
        teams: user.groups || [],
        country: user?.attributes?.country_code || [],
        entity: user?.attributes?.entity_code || [],
        enabled: user.enabled,
      }));

      console.log("Transformed users:", transformedUsers);
      setUsers(transformedUsers);
      setTotalItems(response.pagination.totalItems);
    } catch (error) {
      console.error("Error fetching users:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to load users. Please try again.")
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setCurrentPage(1);
    fetchUsers(searchKeyword);
  };

  const handleAddUser = () => {
    navigate("/admin/user-management/create-user");
  };

  const handleEditUser = (user: User) => {
    navigate(`/admin/user-management/update-user/${user.id}`);
  };

  const handlePageChange = (page: number, size: number) => {
    setCurrentPage(page);
    if (size !== pageSize) {
      setPageSize(size);
      setCurrentPage(1); // Reset to first page when page size changes
    }
  };

  const handleSortChange = (field: string, order: "asc" | "desc") => {
    setSortBy(field);
    setSortOrder(order);
    setCurrentPage(1); // Reset to first page when sorting changes
  };

  // Column definitions for User Management DataTable
  const columns: ColumnsType<User> = [
    {
      title: "User Name",
      key: "username",
      width: 200,
      sorter: true,
      render: (_: unknown, record: User) => (
        <span>{`${record.firstname} ${record.lastname}`}</span>
      ),
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
      width: 220,
      sorter: true,
    },
    {
      title: "Role",
      dataIndex: "roles",
      key: "roles",
      width: 200,
      render: (
        roles: { roleId: string; roleName: string; roleDisplayName: string }[]
      ) => (
        <>
          {roles && roles.length > 0 ? (
            roles.map((role) => {
              if (!role) return null;
              return (
                <Tag color="yellow" key={role.roleId}>
                  {role.roleDisplayName}
                </Tag>
              );
            })
          ) : (
            <span>-</span>
          )}
        </>
      ),
    },
    {
      title: "Team",
      dataIndex: "teams",
      key: "teams",
      width: 200,
      render: (teams: { groupId: string; groupName: string }[]) => (
        <>
          {teams && teams.length > 0 ? (
            teams.map((team) => (
              <Tag key={team.groupId} color="green">
                {team.groupName}
              </Tag>
            ))
          ) : (
            <span>-</span>
          )}
        </>
      ),
    },
    {
      title: "Country",
      dataIndex: "country",
      key: "country",
      width: 180,
      sorter: true,
      render: (countries: string[]) => (
        <>
          {countries.map((country, index) => (
            <Tag key={index} color="blue">
              {country}
            </Tag>
          ))}
        </>
      ),
    },
    {
      title: "Entity",
      dataIndex: "entity",
      key: "entity",
      width: 180,
      sorter: true,
      render: (entities: string[]) => (
        <>
          {entities.map((entity, index) => (
            <Tag key={index} color="purple">
              {entity}
            </Tag>
          ))}
        </>
      ),
    },
    {
      title: "Enabled",
      dataIndex: "enabled",
      key: "enabled",
      width: 100,
      align: "center",
      sorter: true,
      render: (enabled: boolean) => (
        <Tag color={enabled ? "success" : "default"}>
          {enabled ? "Active" : "Inactive"}
        </Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      width: 120,
      align: "center",
      fixed: "right",
      render: (_: unknown, record: User) => (
        <div className={styles.actionButtons}>
          <IconActionButton
            icon={<EditOutlined />}
            tooltip="Edit User"
            onClick={() => handleEditUser(record)}
          />
        </div>
      ),
    },
  ];

  return (
    <>
      <div className={styles.tabHeader}>
        <div className={styles.searchContainer}>
          <LabeledInput
            label="Search Users"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            placeholder="Search by username, email, firstname or lastname"
            className={styles.searchInput}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSearch();
              }
            }}
          />
          <ReusableButton
            variant="primary"
            onClick={handleSearch}
            className={styles.searchButton}
          >
            Search
          </ReusableButton>
        </div>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAddUser}
          className={styles.addButton}
        >
          Add User
        </Button>
      </div>
      {users.length === 0 && !loading ? (
        <EmptyData
          icon="👤"
          title="No Users Found"
          description="There are no users in the system yet."
        />
      ) : (
        <DataTable
          data={users}
          columns={columns}
          size="small"
          rowKey="id"
          pagination={{
            current: currentPage,
            pageSize: pageSize,
            total: totalItems,
            onChange: handlePageChange,
            showSizeChanger: true,
            showTotal: (total: number) => `Total ${total} users`,
            pageSizeOptions: ["10", "20", "50", "100"],
          }}
          loading={loading}
          onSortChange={handleSortChange}
        />
      )}
    </>
  );
}
