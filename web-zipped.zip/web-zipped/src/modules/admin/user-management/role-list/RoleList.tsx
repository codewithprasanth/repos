import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { Button } from "antd";
import showMessage, { getErrorMessage } from "../../../../components/Message";
import { ConfirmPopover } from "../../../../components/ConfirmPopover";
import type { ColumnsType } from "antd/es/table";
import styles from "../UserManagement.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import IconActionButton from "../../../../components/IconActionButton/IconActionButton";
import Spinner from "../../../../components/spinner";
import { roleService } from "../user-management.service";
import type { RoleDTO } from "../user-management.types";

export interface Role {
  id: string;
  name: string;
  displayName: string;
  description: string;
  composite: boolean;
}

export default function RoleList() {
  const navigate = useNavigate();
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch roles from API
  useEffect(() => {
    fetchRoles();
  }, []);

  const fetchRoles = async () => {
    try {
      setLoading(true);
      const data = await roleService.getAllRoles();

      // Transform RoleDTO to Role interface
      const transformedRoles: Role[] = data.map((role: RoleDTO) => ({
        id: role.id,
        name: role.name,
        displayName: role.displayName,
        description: role.description,
        composite: role.composite,
      }));

      setRoles(transformedRoles);
    } catch (error) {
      console.error("Error fetching roles:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to load roles. Please try again.")
      );
    } finally {
      setLoading(false);
    }
  };

  const handleAddRole = () => {
    navigate("/admin/user-management/create-role");
  };

  const handleDeleteRole = async (role: Role) => {
    try {
      await roleService.deleteRole(role.id);
      showMessage.success(`Role "${role.displayName}" deleted successfully`);
      // Refresh the roles list
      fetchRoles();
    } catch (error) {
      console.error("Error deleting role:", error);
      showMessage.error(
        getErrorMessage(error, "Failed to delete role. Please try again.")
      );
    }
  };

  // Column definitions for Roles DataTable
  const roleColumns: ColumnsType<Role> = [
    {
      title: "Role Name",
      dataIndex: "displayName",
      key: "displayName",
      width: 200,
      sorter: true,
    },
    {
      title: "Role Description",
      dataIndex: "description",
      key: "description",
      sorter: true,
    },
    {
      title: "Privileges Mapped",
      dataIndex: "composite",
      key: "composite",
      width: 150,
      align: "center",
      sorter: true,
      render: (composite: boolean) => <span>{composite ? "Yes" : "No"}</span>,
    },
    {
      title: "Action",
      key: "action",
      width: 120,
      align: "center",
      render: (_: unknown, record: Role) => (
        <div className={styles.actionButtons}>
          <ConfirmPopover
            title="Delete Role"
            description={`Are you sure you want to delete the role "${record.displayName}"? This action cannot be undone.`}
            onConfirm={() => handleDeleteRole(record)}
            type="danger"
          >
            <IconActionButton
              icon={<DeleteOutlined />}
              tooltip="Delete Role"
              danger
            />
          </ConfirmPopover>
        </div>
      ),
    },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (roles.length === 0) {
    return (
      <div className={styles.pageEmptyState}>
        <div className={styles.emptyIcon}>🔐</div>
        <h3>No Roles Available</h3>
        <p>There are no roles configured in the system yet.</p>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAddRole}
          className={styles.addButton}
          style={{ marginTop: "24px" }}
        >
          Add Role
        </Button>
      </div>
    );
  }

  return (
    <>
      <div className={styles.tabHeader}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAddRole}
          className={styles.addButton}
        >
          Add Role
        </Button>
      </div>
      <DataTable
        data={roles}
        columns={roleColumns}
        size="small"
        rowKey="id"
        pagination={true}
        loading={loading}
      />
    </>
  );
}
