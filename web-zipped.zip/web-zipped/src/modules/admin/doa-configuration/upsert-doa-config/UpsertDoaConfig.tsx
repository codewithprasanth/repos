import React, { useEffect, useState } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import showMessage from "../../../../components/Message";
import styles from "./UpsertDoaConfig.module.scss";
import ReusableButton from "../../../../components/ReusableButton/ReusableButton";
import LabeledInput from "../../../../components/LabeledInput/LabeledInput";
import LabeledSelect from "../../../../components/LabeledSelect/LabeledSelect";
import LabeledToggle from "../../../../components/LabeledToggle";
import LiveSearch from "../../../../components/LiveSearch/LiveSearch";
import { userService } from "../../user-management/user-management.service";
import type { UserDTO } from "../../user-management/user-management.types";
import { AppRoles } from "../../../../auth/roles-privileges";
import {
  createDoaConfig,
  updateDoaConfig,
  getDoaConfigById,
} from "../doa-configuration.service";
import type { DoaConfig } from "../overview/Overview";

interface DoaConfigFormData {
  userId: string;
  entity: string;
  emailId: string;
  country: string;
  fromAmount: string;
  toAmount: string;
  currency: string;
  vendorCode: string;
  poNumber: string;
  approverLevel: string;
  classification: string;
  companyCode: string;
  enabled: boolean;
}

// Sample dropdown options
const CLASSIFICATION_OPTIONS = [
  { label: "Direct", value: "Direct" },
  { label: "Indirect", value: "Indirect" },
];

const CURRENCY_OPTIONS = [
  { label: "USD", value: "USD" },
  { label: "EUR", value: "EUR" },
  { label: "GBP", value: "GBP" },
  { label: "JPY", value: "JPY" },
  { label: "INR", value: "INR" },
  { label: "AUD", value: "AUD" },
  { label: "CAD", value: "CAD" },
  { label: "SGD", value: "SGD" },
];

const VENDOR_CODE_OPTIONS = [
  { label: "VEN001", value: "VEN001" },
  { label: "VEN002", value: "VEN002" },
  { label: "VEN003", value: "VEN003" },
  { label: "VEN004", value: "VEN004" },
  { label: "VEN005", value: "VEN005" },
];

const ENTITY_OPTIONS = [
  { label: "Entity A", value: "entity-a-uuid" },
  { label: "Entity B", value: "entity-b-uuid" },
  { label: "Entity C", value: "entity-c-uuid" },
  { label: "Entity D", value: "entity-d-uuid" },
  { label: "Entity E", value: "entity-e-uuid" },
];

export default function UpsertDoaConfig() {
  const navigate = useNavigate();
  const { configId } = useParams<{ configId: string }>();
  const location = useLocation();

  const [loading, setLoading] = useState(false);

  const isCreateMode = location.pathname.includes("create-config");
  const isUpdateMode = location.pathname.includes("update-config");

  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<DoaConfigFormData>({
    mode: "onBlur",
    defaultValues: {
      userId: "",
      entity: "",
      emailId: "",
      country: "",
      fromAmount: "",
      toAmount: "",
      currency: "",
      vendorCode: "",
      poNumber: "",
      approverLevel: "",
      classification: "",
      companyCode: "",
      enabled: true,
    },
  });

  const formData = watch();

  useEffect(() => {
    console.log("Form data changed:", formData);
  }, [formData]);

  useEffect(() => {
    if (isUpdateMode && configId) {
      fetchConfigDetails(configId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isUpdateMode, configId]);

  const fetchConfigDetails = async (id: string) => {
    try {
      setLoading(true);
      const config = await getDoaConfigById(id);
      if (config) {
        setValue("userId", config.userName);
        setValue("entity", config.entity);
        setValue("emailId", config.emailId);
        setValue("country", config.country);
        setValue("fromAmount", config.fromAmount.toString());
        setValue("toAmount", config.toAmount.toString());
        setValue("currency", config.currency);
        setValue("vendorCode", config.vendorCode);
        setValue("poNumber", config.poNumber);
        setValue("approverLevel", config.approverLevel);
        setValue("classification", config.classification);
        setValue("companyCode", config.companyCode);
        setValue("enabled", config.isActive);
      }
    } catch (error) {
      console.error("Error fetching config details:", error);
      showMessage.error("Failed to load configuration details");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: DoaConfigFormData) => {
    try {
      setLoading(true);

      const configData: Partial<DoaConfig> = {
        userName: data.userId,
        country: data.country,
        emailId: data.emailId,
        fromAmount: parseFloat(data.fromAmount),
        toAmount: parseFloat(data.toAmount),
        currency: data.currency,
        vendorCode: data.vendorCode,
        poNumber: data.poNumber,
        approverLevel: data.approverLevel,
        classification: data.classification,
        companyCode: data.companyCode,
        entity: data.entity,
        isActive: data.enabled,
        product: "",
        location: "",
        department: "",
        userCountries: [],
      };

      if (isCreateMode) {
        await createDoaConfig(configData as Omit<DoaConfig, "id">);
        showMessage.success("Configuration created successfully");
      } else if (isUpdateMode && configId) {
        await updateDoaConfig(configId, configData);
        showMessage.success("Configuration updated successfully");
      }

      navigate("/admin/doa-configuration/overview");
    } catch (error) {
      console.error("Error saving configuration:", error);
      showMessage.error("Failed to save configuration");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/admin/doa-configuration/overview");
  };

  return (
    <div className={styles.upsertDoaConfig}>
      <div className={styles.header}>
        <h2>
          {isCreateMode ? "Create DOA Configuration" : "Edit DOA Configuration"}
        </h2>
        <div className={styles.actions}>
          <ReusableButton variant="secondary" onClick={handleCancel}>
            Cancel
          </ReusableButton>
          <ReusableButton
            variant="primary"
            onClick={handleSubmit(onSubmit)}
            disabled={loading}
          >
            {loading ? "Saving..." : isCreateMode ? "Create" : "Update"}
          </ReusableButton>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className={styles.formContent}>
        <div className={styles.formGrid}>
          <Controller
            name="userId"
            control={control}
            rules={{ required: "User name is required" }}
            render={({ field }) => (
              <LiveSearch<UserDTO>
                label="User"
                placeholder="Search user by name or email"
                required
                error={errors.userId?.message}
                fetchFunction={async (keyword) => {
                  const response = await userService.getAllUsers(
                    keyword,
                    5,
                    undefined,
                    undefined,
                    undefined,
                    AppRoles.APPROVER
                  );
                  return response.data;
                }}
                getOptionValue={(user) => user.id}
                getOptionLabel={(user) => `${user.firstName} ${user.lastName}`}
                renderOption={(user) => `${user.firstName} ${user.lastName}`}
                renderSelectedValue={(user) =>
                  `${user.firstName} ${user.lastName}`
                }
                {...field}
              />
            )}
          />

          <Controller
            name="emailId"
            control={control}
            render={({ field }) => (
              <LabeledInput
                label="Email ID"
                placeholder="Email ID"
                readOnly
                {...field}
              />
            )}
          />

          <Controller
            name="country"
            control={control}
            render={({ field }) => (
              <LabeledInput
                label="Country"
                placeholder="Country"
                readOnly
                {...field}
              />
            )}
          />

          <Controller
            name="fromAmount"
            control={control}
            rules={{
              required: "From amount is required",
              min: { value: 0, message: "Amount cannot be negative" },
            }}
            render={({ field }) => (
              <LabeledInput
                label="From Amount"
                type="number"
                placeholder="Enter from amount"
                required
                min={0}
                error={errors.fromAmount?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="toAmount"
            control={control}
            rules={{
              required: "To amount is required",
              min: { value: 0, message: "Amount cannot be negative" },
            }}
            render={({ field }) => (
              <LabeledInput
                label="To Amount"
                type="number"
                placeholder="Enter to amount"
                required
                min={0}
                error={errors.toAmount?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="currency"
            control={control}
            rules={{ required: "Currency is required" }}
            render={({ field }) => (
              <LabeledSelect
                label="Currency"
                placeholder="Select currency"
                required
                options={CURRENCY_OPTIONS}
                error={errors.currency?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="vendorCode"
            control={control}
            rules={{ required: "Vendor code is required" }}
            render={({ field }) => (
              <LabeledSelect
                label="Vendor Code"
                placeholder="Select vendor code"
                required
                options={VENDOR_CODE_OPTIONS}
                error={errors.vendorCode?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="poNumber"
            control={control}
            rules={{ required: "PO number is required" }}
            render={({ field }) => (
              <LabeledInput
                label="Po Number"
                placeholder="Enter PO number"
                required
                error={errors.poNumber?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="approverLevel"
            control={control}
            rules={{
              required: "Approver level is required",
              min: { value: 0, message: "Approver level cannot be negative" },
            }}
            render={({ field }) => (
              <LabeledInput
                label="Approver Level"
                type="number"
                placeholder="Enter approver level"
                required
                min={0}
                error={errors.approverLevel?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="classification"
            control={control}
            rules={{ required: "Classification is required" }}
            render={({ field }) => (
              <LabeledSelect
                label="Classification"
                placeholder="Select classification"
                required
                options={CLASSIFICATION_OPTIONS}
                error={errors.classification?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="companyCode"
            control={control}
            render={({ field }) => (
              <LabeledInput
                label="Company Code"
                placeholder="Company Code"
                readOnly
                {...field}
              />
            )}
          />

          <Controller
            name="entity"
            control={control}
            rules={{ required: "Entity is required" }}
            render={({ field }) => (
              <LabeledSelect
                label="Entity"
                placeholder="Select entity"
                required
                options={ENTITY_OPTIONS}
                error={errors.entity?.message}
                {...field}
              />
            )}
          />

          <Controller
            name="enabled"
            control={control}
            render={({ field }) => (
              <LabeledToggle
                label="Enabled"
                checked={field.value}
                onChange={field.onChange}
              />
            )}
          />
        </div>
      </form>
    </div>
  );
}
