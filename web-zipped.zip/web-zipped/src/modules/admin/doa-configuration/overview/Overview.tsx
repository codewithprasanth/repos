import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { EditOutlined, DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { Tag, Button, Modal } from "antd";
import type { ColumnsType } from "antd/es/table";
import styles from "./Overview.module.scss";
import DataTable from "../../../../components/DataTable/DataTable";
import IconActionButton from "../../../../components/IconActionButton/IconActionButton";
import Spinner from "../../../../components/spinner";
import showMessage from "../../../../components/Message";
import { fetchDoaConfigs, deleteDoaConfig } from "../doa-configuration.service";

export interface DoaConfig {
  id: string;
  userName: string;
  country: string;
  emailId: string;
  fromAmount: number;
  toAmount: number;
  currency: string;
  product: string;
  location: string;
  vendorCode: string;
  poNumber: string;
  approverLevel: string;
  classification: string;
  department: string;
  userCountries: string[];
  companyCode: string;
  entity: string;
  isActive: boolean;
}

export default function Overview() {
  const navigate = useNavigate();
  const [configs, setConfigs] = useState<DoaConfig[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch DOA configs from API
  useEffect(() => {
    loadConfigs();
  }, []);

  const loadConfigs = async () => {
    try {
      setLoading(true);
      const data = await fetchDoaConfigs();
      setConfigs(data);
    } catch (error) {
      console.error("Error fetching DOA configs:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddConfig = () => {
    navigate("/admin/doa-configuration/create-config");
  };

  const handleEditConfig = (config: DoaConfig) => {
    navigate(`/admin/doa-configuration/update-config/${config.id}`);
  };

  const handleDeleteConfig = (config: DoaConfig) => {
    Modal.confirm({
      title: "Delete DOA Configuration",
      content: `Are you sure you want to delete the DOA configuration for ${config.userName}?`,
      okText: "Delete",
      okType: "danger",
      cancelText: "Cancel",
      onOk: async () => {
        try {
          await deleteDoaConfig(config.id);
          showMessage.success("Configuration deleted successfully");
          loadConfigs(); // Reload the list
        } catch (error) {
          console.error("Error deleting config:", error);
          showMessage.error("Failed to delete configuration");
        }
      },
    });
  };

  // Column definitions
  const columns: ColumnsType<DoaConfig> = [
    {
      title: "User Name",
      dataIndex: "userName",
      key: "userName",
      width: 180,
      sorter: true,
    },
    {
      title: "Country",
      dataIndex: "country",
      key: "country",
      width: 120,
      sorter: true,
    },
    {
      title: "Email Id",
      dataIndex: "emailId",
      key: "emailId",
      width: 200,
      sorter: true,
    },
    {
      title: "From Amount",
      dataIndex: "fromAmount",
      key: "fromAmount",
      width: 130,
      sorter: true,
      align: "right",
      render: (amount: number) => amount?.toLocaleString() || "-",
    },
    {
      title: "To Amount",
      dataIndex: "toAmount",
      key: "toAmount",
      width: 130,
      sorter: true,
      align: "right",
      render: (amount: number) => amount?.toLocaleString() || "-",
    },
    {
      title: "Currency",
      dataIndex: "currency",
      key: "currency",
      width: 100,
      sorter: true,
    },
    // {
    //   title: "Product",
    //   dataIndex: "product",
    //   key: "product",
    //   width: 150,
    //   sorter: true,
    // },
    // {
    //   title: "Location",
    //   dataIndex: "location",
    //   key: "location",
    //   width: 150,
    //   sorter: true,
    // },
    {
      title: "Vendor Code",
      dataIndex: "vendorCode",
      key: "vendorCode",
      width: 130,
      sorter: true,
    },
    {
      title: "Po Number",
      dataIndex: "poNumber",
      key: "poNumber",
      width: 130,
      sorter: true,
    },
    {
      title: "Approver Level",
      dataIndex: "approverLevel",
      key: "approverLevel",
      width: 140,
      sorter: true,
    },
    {
      title: "Classification",
      dataIndex: "classification",
      key: "classification",
      width: 140,
      sorter: true,
    },
    // {
    //   title: "Department",
    //   dataIndex: "department",
    //   key: "department",
    //   width: 140,
    //   sorter: true,
    // },
    {
      title: "Company Code",
      dataIndex: "companyCode",
      key: "companyCode",
      width: 140,
      sorter: true,
    },
    {
      title: "Entity",
      dataIndex: "entity",
      key: "entity",
      width: 140,
      sorter: true,
    },
    {
      title: "Is Active",
      dataIndex: "isActive",
      key: "isActive",
      width: 100,
      sorter: true,
      align: "center",
      render: (isActive: boolean) => (
        <Tag color={isActive ? "green" : "red"}>
          {isActive ? "Active" : "Inactive"}
        </Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      width: 120,
      align: "center",
      fixed: "right",
      render: (_: unknown, record: DoaConfig) => (
        <div className={styles.actionButtons}>
          <IconActionButton
            icon={<EditOutlined />}
            tooltip="Edit Config"
            onClick={() => handleEditConfig(record)}
          />
          <IconActionButton
            icon={<DeleteOutlined />}
            tooltip="Delete Config"
            danger
            onClick={() => handleDeleteConfig(record)}
          />
        </div>
      ),
    },
  ];

  if (loading) {
    return <Spinner />;
  }

  if (configs.length === 0) {
    return (
      <div className={styles.overview}>
        <div className={styles.pageEmptyState}>
          <div className={styles.emptyIcon}>📋</div>
          <h3>No DOA Configurations Available</h3>
          <p>There are no DOA configurations in the system yet.</p>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={handleAddConfig}
            className={styles.addButton}
            style={{ marginTop: "24px" }}
          >
            Add Configuration
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.overview}>
      <div className={styles.tabHeader}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAddConfig}
          className={styles.addButton}
        >
          Add Configuration
        </Button>
      </div>
      <DataTable
        data={configs}
        columns={columns}
        size="small"
        rowKey="id"
        pagination={true}
        loading={loading}
      />
    </div>
  );
}
