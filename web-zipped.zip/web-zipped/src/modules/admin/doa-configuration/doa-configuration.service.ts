import { axiosInstance } from "../../../auth/axios-config";
import { API_ENDPOINTS } from "../../../config/apis";
import type { DoaConfig } from "./overview/Overview";

// API response types
interface PageableResponse<T> {
  content: T[];
  pageable: {
    pageNumber: number;
    pageSize: number;
  };
  totalPages: number;
  totalElements: number;
  last: boolean;
  first: boolean;
  numberOfElements: number;
  size: number;
  number: number;
}

interface DoaRuleRequest {
  userId: string;
  entity: string;
  approvalLevel: number;
  minAmount: number;
  maxAmount: number;
  currency: string;
  vendorCode?: string;
  poNumber?: string;
  classification?: string;
  enabled: boolean;
  validFrom: string; // yyyy-MM-dd format
  validTo: string; // yyyy-MM-dd format
}

interface DoaRuleResponse {
  id: string;
  userName: string;
  userId: string;
  country: string;
  emailId: string;
  fromAmount: number;
  toAmount: number;
  currency: string;
  vendorCode: string;
  poNumber: string;
  approverLevel: string;
  classification: string;
  userCountries: string[] | null;
  companyCode: string;
  entityId: string;
  entity: string;
  isActive: boolean;
  enabled: boolean;
  validFrom: string;
  validTo: string;
  createdAt: string;
  updatedAt: string;
  createdByUserId: string;
}

// Helper function to map API response to DoaConfig
const mapApiResponseToDoaConfig = (response: DoaRuleResponse): DoaConfig => ({
  id: response.id,
  userName: response.userName,
  country: response.country,
  emailId: response.emailId,
  fromAmount: response.fromAmount,
  toAmount: response.toAmount,
  currency: response.currency,
  product: "", // Not in API response
  location: "", // Not in API response
  vendorCode: response.vendorCode,
  poNumber: response.poNumber,
  approverLevel: response.approverLevel,
  classification: response.classification,
  department: "", // Not in API response
  userCountries: response.userCountries || [],
  companyCode: response.companyCode,
  entity: response.entity,
  isActive: response.isActive,
});

// Service function to fetch DOA configurations
export const fetchDoaConfigs = async (
  page: number = 0,
  size: number = 100,
  sort: string = "createdAt,desc"
): Promise<DoaConfig[]> => {
  try {
    const response = await axiosInstance.get<PageableResponse<DoaRuleResponse>>(
      API_ENDPOINTS.DOA_CONFIGURATION.GET_ALL_DOA_RULES,
      {
        params: {
          page,
          size,
          sort,
        },
      }
    );
    return response.data.content.map(mapApiResponseToDoaConfig);
  } catch (error) {
    console.error("Error fetching DOA configs:", error);
    throw error;
  }
};

// Service function to create DOA configuration
export const createDoaConfig = async (
  config: Omit<DoaConfig, "id">
): Promise<DoaConfig> => {
  try {
    const requestBody: DoaRuleRequest = {
      userId: config.userName, // This should be the actual user ID
      entity: config.entity, // This should be the actual entity ID
      approvalLevel: parseInt(config.approverLevel),
      minAmount: config.fromAmount,
      maxAmount: config.toAmount,
      currency: config.currency,
      vendorCode: config.vendorCode,
      poNumber: config.poNumber,
      classification: config.classification,
      enabled: config.isActive,
      validFrom: "2025-01-01", // Should be from form
      validTo: "2025-12-31", // Should be from form
    };

    const response = await axiosInstance.post<DoaRuleResponse>(
      API_ENDPOINTS.DOA_CONFIGURATION.CREATE_DOA_RULE,
      requestBody
    );
    return mapApiResponseToDoaConfig(response.data);
  } catch (error) {
    console.error("Error creating DOA config:", error);
    throw error;
  }
};

// Service function to update DOA configuration
export const updateDoaConfig = async (
  id: string,
  config: Partial<DoaConfig>
): Promise<DoaConfig> => {
  try {
    const requestBody: DoaRuleRequest = {
      userId: config.userName!, // This should be the actual user ID
      entity: config.entity!, // This should be the actual entity ID
      approvalLevel: parseInt(config.approverLevel!),
      minAmount: config.fromAmount!,
      maxAmount: config.toAmount!,
      currency: config.currency!,
      vendorCode: config.vendorCode,
      poNumber: config.poNumber,
      classification: config.classification,
      enabled: config.isActive!,
      validFrom: "2025-01-01", // Should be from form
      validTo: "2025-12-31", // Should be from form
    };

    const response = await axiosInstance.put<DoaRuleResponse>(
      API_ENDPOINTS.DOA_CONFIGURATION.UPDATE_DOA_RULE.replace(":id", id),
      requestBody
    );
    return mapApiResponseToDoaConfig(response.data);
  } catch (error) {
    console.error("Error updating DOA config:", error);
    throw error;
  }
};

// Service function to delete DOA configuration
export const deleteDoaConfig = async (id: string): Promise<void> => {
  try {
    await axiosInstance.delete(
      API_ENDPOINTS.DOA_CONFIGURATION.DELETE_DOA_RULE.replace(":id", id)
    );
  } catch (error) {
    console.error("Error deleting DOA config:", error);
    throw error;
  }
};

// Service function to get DOA configuration by ID
export const getDoaConfigById = async (
  id: string
): Promise<DoaConfig | null> => {
  try {
    const response = await axiosInstance.get<DoaRuleResponse>(
      API_ENDPOINTS.DOA_CONFIGURATION.GET_DOA_RULE_BY_ID.replace(":id", id)
    );
    return mapApiResponseToDoaConfig(response.data);
  } catch (error) {
    console.error("Error fetching DOA config by ID:", error);
    throw error;
  }
};
