import { Outlet } from "react-router-dom";

export default function AnalyticsLayout() {
  return <Outlet />;
}
