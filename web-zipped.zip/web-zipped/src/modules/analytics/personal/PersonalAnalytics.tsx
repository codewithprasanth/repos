import styles from "./PersonalAnalytics.module.scss";

export default function PersonalAnalytics() {
  return (
    <div className={styles.personalAnalytics}>
      <h1>Personal Analytics</h1>
      <p>This is the Personal Analytics page</p>
    </div>
  );
}
