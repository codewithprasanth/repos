import styles from "./EmailReconReport.module.scss";

export default function EmailReconReport() {
  return (
    <div className={styles.emailReconReport}>
      <h1>Email Recon Report</h1>
      <p>This is the Email Reconciliation Report page</p>
    </div>
  );
}
