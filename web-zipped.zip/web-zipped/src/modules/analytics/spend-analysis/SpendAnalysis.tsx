import styles from "./SpendAnalysis.module.scss";

export default function SpendAnalysis() {
  return (
    <div className={styles.spendAnalysis}>
      <h1>Spend Analysis</h1>
      <p>This is the Spend Analysis page</p>
    </div>
  );
}
