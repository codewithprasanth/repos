import styles from "./VolumeForecast.module.scss";

export default function VolumeForecast() {
  return (
    <div className={styles.volumeForecast}>
      <h1>Volume Forecast</h1>
      <p>This is the Volume Forecast page</p>
    </div>
  );
}
