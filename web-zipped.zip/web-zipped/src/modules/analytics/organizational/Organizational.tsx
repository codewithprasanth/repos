import styles from "./Organizational.module.scss";

export default function Organizational() {
  return (
    <div className={styles.organizational}>
      <h1>Organizational Analytics</h1>
      <p>This is the Organizational Analytics page</p>
    </div>
  );
}
