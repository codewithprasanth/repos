import styles from "./QCAnalysis.module.scss";

export default function QCAnalysis() {
  return (
    <div className={styles.qcAnalysis}>
      <h1>QC Analysis</h1>
      <p>This is the QC Analysis page</p>
    </div>
  );
}
