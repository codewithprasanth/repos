import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import "antd/dist/reset.css";
import "./index.scss";
import "./styles/fonts.scss";
import App from "./App.tsx";
import { store } from "./store/store.ts";
import { getConfig } from "./auth/env-config.ts";
import { getKeycloakInstance, initOptions } from "./auth/keycloak-config.ts";
import { ReactKeycloakProvider } from "@react-keycloak/web";
import { axiosInstance } from "./auth/axios-config.ts";

const config = await getConfig();
axiosInstance.defaults.baseURL = config.baseUrl;
const keycloakIns = getKeycloakInstance(config.keycloak);
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Provider store={store}>
      <ReactKeycloakProvider authClient={keycloakIns} initOptions={initOptions}>
        <App />
      </ReactKeycloakProvider>
    </Provider>
  </StrictMode>
);
