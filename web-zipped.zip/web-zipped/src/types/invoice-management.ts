import type { DocumentItem } from "./uploads";

// Request interfaces
export interface InvoiceFilter {
  workitem_number?: string;
  workItemNumber?: string;
  status_id?: string;
  workItemStatus?: string;
  invoiceNo?: string;
  invoiceNumber?: string;
  po_number?: string;
  poNumber?: string;
  assigned_to_user?: string;
  initiator?: string;
  team?: string;
  queue?: string;
}

export interface InvoiceListRequest {
  pageSize: number;
  pageNo: number;
  sortBy: string;
  sortOrder: "asc" | "desc";
  filterColumn?: string;
  filterValue?: string;
  filter?: InvoiceFilter;
}

// Responses

// Line item interface for invoice
export interface LineItem {
  id: number;
  description: string;
  units: number;
  price: number;
  total_amount: number;
}

// Invoice data interface based on the API response
export interface InvoiceData {
  workItemNumber: string;
  invoiceNumber: string;
  erpDocumentNo?: string;
  invoiceDate?: string;
  invoiceType?: string;
  classification: string;
  vendorCode?: string;
  vendorName: string;
  vendorPanNumber?: string;
  vendorGstNumber?: string;
  poNumber?: string;
  paymentTerms?: string;
  entityId?: number;
  currency: string;
  invoiceAmount: number;
  status: string;
  companyCode: string;
  initiatorEmailId?: string;
  source?: string;
  invoiceReceiptDate?: string;
  erpDueDate?: string;
  dueDate?: string | null;
  receivedDate?: string;
  assignee?: string | null;
  delegatedTo?: string | null;
  assignedToTeam?: string;
  team?: string;
  completedBy?: string | null;
  completedOn?: string | null;
  queue?: string;
  sla?: boolean;
  initiator?: string;
  lineItems?: LineItem[];
}

// Pagination interface
export interface PaginationData {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalElements: number;
}

// API Response interface (flexible to handle different response formats)
export interface InvoiceApiResponse {
  success: boolean;
  message: string;
  data: {
    data: InvoiceData[];
    totalPages: number;
    totalElements: number;
    currentPage: number;
    pageSize: number;
  };
  timestamp: string;
}

// Vendor details interface
export interface VendorDetails {
  vendorCode: string;
  vendorName: string;
  vendorTaxId: string;
  paymentTerms: string;
  vendorLineItemText: string | null;
}

// Entity details interface
export interface EntityDetails {
  entityId: string;
  entityName: string;
  companyCode: string;
  location: string | null;
}

// PO details interface
export interface PODetails {
  poNumber: string;
  buyerName: string | null;
  requisitionerName: string | null;
}

// Amounts interface
export interface InvoiceAmounts {
  baseAmount: number;
  freightAmount: number;
  taxAmount: number;
  discountAmount: number | null;
  totalAmount: number;
}

// Status interface
export interface InvoiceStatus {
  code: string;
  name: string;
  queueType: string | null;
}

// Assignment interface
export interface InvoiceAssignment {
  assignedToUserId: string | null;
  assignedToName: string | null;
  assignedToEmail: string | null;
  assignedAt: string | null;
  isLocked: boolean;
  lockedByUserId: string | null;
  lockedByName: string | null;
  lockedAt: string | null;
}

// Audit interface
export interface InvoiceAudit {
  createdAt: string;
  updatedAt: string;
}

// Invoice line item interface
export interface InvoiceLineItem {
  lineItemId: string;
  lineNumber: number;
  status: string;
  poNumber: string;
  poLineItem: string;
  materialNumber: string;
  materialDescription: string;
  poQty: number;
  poPrice: number;
  poAmount: number;
  grnQty: number;
  grPrice: number;
  grnAmount: number;
  grnNumber: string;
  invQty: number;
  invPrice: number;
  invoiceAmount: number;
  uom: string;
  glCode: string;
  glCodeDesc: string;
  businessArea: string;
  costCenter: string;
  profitCenter: string;
  wbs: string;
  taxCode: string;
  taxAmount: number;
  buyer: string;
  poRequestioner: string;
  plant: string;
  text: string;
}

// Invoice Detail interface for Quick Overview
export interface InvoiceDetail {
  workId: string;
  invoiceNumber: string;
  invoiceDate: string;
  invoiceType: string;
  classification: string;
  documentType: string;
  currency: string;
  receiptDate: string;
  postingDate: string | null;
  vendor: VendorDetails;
  entity: EntityDetails;
  poDetails: PODetails;
  amounts: InvoiceAmounts;
  status: InvoiceStatus;
  assignment: InvoiceAssignment;
  audit: InvoiceAudit;
}

// Invoice detail API response
export interface InvoiceDetailResponse {
  success: boolean;
  message: string;
  data: {
    invoice: InvoiceDetail;
    lineItems: InvoiceLineItem[];
    primaryDocument: unknown;
  };
  timestamp: string;
}

// Additional Details Interfaces
export interface AdditionalDetailsCurrency {
  reportingCountry: string;
  exchangeRate: number;
  docCurrency: string;
  localCurrency: string | null;
}

export interface AdditionalDetailsFinancial {
  discount: number | null;
  reference1: string | null;
  reference2: string | null;
  reference3: string | null;
}

export interface AdditionalDetailsPosting {
  specialGLIndicator: string | null;
  postingDocumentNumber: string | null;
  postingDate: string;
  baselineDate: string;
  dueDate: string;
  documentHeaderText: string;
}

export interface AdditionalDetailsPayment {
  paymentBlock: string;
  partnerBank: string;
  paymentMethod: string;
}

export interface AdditionalDetailsAsset {
  serialNumber: string | null;
  assetNumber: string | null;
  transactionType: string | null;
  valueDate: string | null;
  materialPosting: string | null;
}

export interface AdditionalDetailsCondition {
  conditionAmount: number | null;
  conditionTaxAmount: number | null;
}

export interface AdditionalDetailsERPStatus {
  paymentStatus: string;
  paymentDate: string;
  postedBy: string;
}

export interface AdditionalDetailsFlags {
  isDoaRequired: boolean | null;
  preApproved: boolean | null;
  enablePosting: boolean;
  manuallyPosted: boolean | null;
}

export interface AdditionalDetails {
  workId: string;
  currency: AdditionalDetailsCurrency;
  financial: AdditionalDetailsFinancial;
  posting: AdditionalDetailsPosting;
  payment: AdditionalDetailsPayment;
  asset: AdditionalDetailsAsset;
  condition: AdditionalDetailsCondition;
  erpStatus: AdditionalDetailsERPStatus;
  flags: AdditionalDetailsFlags;
}

export interface AdditionalDetailsResponse {
  success: boolean;
  message: string;
  data: AdditionalDetails;
  timestamp: string;
}

// Comments interfaces
export interface CommentUser {
  userId: string;
  name: string;
  email: string;
}

export interface Comment {
  commentId: string;
  text: string;
  createdBy: CommentUser;
  createdAt: string;
}

export interface CommentsData {
  workId: string;
  comments: Comment[];
}

export interface CommentsResponse {
  success: boolean;
  message: string;
  data: CommentsData;
  timestamp: string;
}

export interface CreateCommentRequest {
  commentText: string;
}

export interface CreateCommentResponse {
  success: boolean;
  message: string;
  data: Comment;
  timestamp: string;
}

// Invoice state interface
export interface InvoiceState {
  invoices: InvoiceData[];
  pagination: PaginationData | null;
  isLoading: boolean;
  error: string | null;
  currentInvoiceDetail: InvoiceDetail | null;
  currentLineItems: InvoiceLineItem[];
  detailLoading: boolean;
  detailError: string | null;
  currentAdditionalDetails: AdditionalDetails | null;
  additionalDetailsLoading: boolean;
  additionalDetailsError: string | null;
  currentComments: Comment[];
  commentsLoading: boolean;
  commentsError: string | null;
  currentUploads: DocumentItem[];
  uploadsLoading: boolean;
  uploadsError: string | null;
}
