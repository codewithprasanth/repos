// Upload related types

export interface UploadedBy {
  userId: string;
  name: string;
}

export interface DocumentActions {
  canDownload: boolean;
  canView: boolean;
  canDelete: boolean;
}

export interface DocumentItem {
  documentId: string;
  documentName: string;
  documentType: string;
  uploadedBy: UploadedBy;
  uploadedOn: string;
  s3Url: string;
  fileSizeKB: number;
  mimeType: string;
  actions: DocumentActions;
}

export interface UploadsData {
  workId: string;
  documents: DocumentItem[];
}

export interface UploadsResponse {
  success: boolean;
  message: string;
  data: UploadsData;
  timestamp: string;
}

export interface UploadsState {
  uploads: DocumentItem[];
  isLoading: boolean;
  error: string | null;
}
