import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./auth/auth-slice";
import invoiceReducer from "./invoice-management/invoice-management-slice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    invoice: invoiceReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ["persist/PERSIST", "auth/login"],
        ignoredPaths: ["auth.keycloak"],
      },
    }),
});

export type RootState = ReturnType<typeof store.getState>;
export type RootDispatch = typeof store.dispatch;

// Export typed hooks
import { useDispatch } from "react-redux";
export const useAppDispatch = () => useDispatch<RootDispatch>();
