import type { RootState } from "../store";
import type { UserInfo } from "./auth-slice";

// Selector to get whether user is logged in
export const selectIsAuthenticated = (state: RootState): boolean =>
  state.auth.isAuthenticated;

// Selector to get user information
export const selectUser = (state: RootState): UserInfo | null =>
  state.auth.user;
