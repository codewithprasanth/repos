import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";

export interface UserInfo {
  userId: string;
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  roles: string[];
}

export interface AuthState {
  keycloak: Keycloak.KeycloakInstance | null;
  isAuthenticated: boolean;
  user: UserInfo | null;
  isLoading: boolean;
}

const initialState: AuthState = {
  keycloak: null,
  isAuthenticated: false,
  user: null,
  isLoading: false,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (state, action: PayloadAction<Keycloak.KeycloakInstance>) => {
      state.keycloak = action.payload;
      state.isLoading = false;
      state.isAuthenticated = action.payload.authenticated;
      state.user = {
        userId: state.keycloak.tokenParsed?.sub || "",
        firstName: state.keycloak.tokenParsed?.given_name || "",
        lastName: state.keycloak.tokenParsed?.family_name || "",
        fullName: `${state.keycloak.tokenParsed?.given_name || ""} ${
          state.keycloak.tokenParsed?.family_name || ""
        }`,
        email: state.keycloak.tokenParsed?.email || "",
        roles: state.keycloak.tokenParsed?.realm_access?.roles || [],
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(logout.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(logout.fulfilled, (state) => {
        state.isAuthenticated = false;
        state.user = null;
        state.isLoading = false;
      });
  },
});

// Async thunk for logout with Keycloak
export const logout = createAsyncThunk(
  "auth/logout",
  async (_, { getState }) => {
    const state = getState() as { auth: AuthState };
    const { keycloak } = state.auth;

    if (keycloak) {
      try {
        await keycloak.logout();
      } catch (error) {
        console.error("Keycloak logout failed:", error);
      }
    }
  }
);

export const { login } = authSlice.actions;

export default authSlice.reducer;
