import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  getInvoiceList,
  getInvoiceDetail,
  getAdditionalDetails,
  getComments,
  postComment,
  getUploads,
} from "../../modules/invoice-management/invoiceManagement.service";
import type {
  InvoiceApiResponse,
  InvoiceListRequest,
  InvoiceState,
  InvoiceDetailResponse,
  AdditionalDetailsResponse,
  CommentsResponse,
  CreateCommentRequest,
  CreateCommentResponse,
} from "../../types/invoice-management";
import type { UploadsResponse } from "../../types/uploads";
import type { RootState } from "../store";

const initialState: InvoiceState = {
  invoices: [],
  pagination: null,
  isLoading: false,
  error: null,
  currentInvoiceDetail: null,
  currentLineItems: [],
  detailLoading: false,
  detailError: null,
  currentAdditionalDetails: null,
  additionalDetailsLoading: false,
  additionalDetailsError: null,
  currentComments: [],
  commentsLoading: false,
  commentsError: null,
  currentUploads: [],
  uploadsLoading: false,
  uploadsError: null,
};

// Async thunk for fetching invoice data
export const fetchInvoiceList = createAsyncThunk<
  InvoiceApiResponse,
  InvoiceListRequest,
  { rejectValue: string }
>("invoice/fetchInvoiceList", async (request, { rejectWithValue }) => {
  try {
    console.log(request);
    const response = await getInvoiceList(request);
    return response;
  } catch (error) {
    console.error("Error fetching invoice data:", error);
    return rejectWithValue(
      error instanceof Error ? error.message : "Failed to fetch invoice data"
    );
  }
});

// Async thunk for fetching individual invoice detail
export const fetchInvoiceDetail = createAsyncThunk<
  InvoiceDetailResponse,
  string,
  { rejectValue: string }
>("invoice/fetchInvoiceDetail", async (workItemNumber, { rejectWithValue }) => {
  try {
    const response = await getInvoiceDetail(workItemNumber);
    return response;
  } catch (error) {
    console.error("Error fetching invoice detail:", error);
    return rejectWithValue(
      error instanceof Error ? error.message : "Failed to fetch invoice detail"
    );
  }
});

// Async thunk for fetching additional details
export const fetchAdditionalDetails = createAsyncThunk<
  AdditionalDetailsResponse,
  string,
  { rejectValue: string }
>(
  "invoice/fetchAdditionalDetails",
  async (workItemNumber, { rejectWithValue }) => {
    try {
      const response = await getAdditionalDetails(workItemNumber);
      return response;
    } catch (error) {
      console.error("Error fetching additional details:", error);
      return rejectWithValue(
        error instanceof Error
          ? error.message
          : "Failed to fetch additional details"
      );
    }
  }
);

// Async thunk for fetching comments
export const fetchComments = createAsyncThunk<
  CommentsResponse,
  string,
  { rejectValue: string }
>("invoice/fetchComments", async (workItemNumber, { rejectWithValue }) => {
  try {
    const response = await getComments(workItemNumber);
    return response;
  } catch (error) {
    console.error("Error fetching comments:", error);
    return rejectWithValue(
      error instanceof Error ? error.message : "Failed to fetch comments"
    );
  }
});

// Async thunk for posting a comment
export const createComment = createAsyncThunk<
  CreateCommentResponse,
  { workItemNumber: string; request: CreateCommentRequest },
  { rejectValue: string }
>(
  "invoice/createComment",
  async ({ workItemNumber, request }, { rejectWithValue }) => {
    try {
      const response = await postComment(workItemNumber, request);
      return response;
    } catch (error) {
      console.error("Error creating comment:", error);
      return rejectWithValue(
        error instanceof Error ? error.message : "Failed to create comment"
      );
    }
  }
);

// Async thunk for fetching uploads
export const fetchUploads = createAsyncThunk<
  UploadsResponse,
  string,
  { rejectValue: string }
>("invoice/fetchUploads", async (workItemNumber, { rejectWithValue }) => {
  try {
    const response = await getUploads(workItemNumber);
    return response;
  } catch (error) {
    console.error("Error fetching uploads:", error);
    return rejectWithValue(
      error instanceof Error ? error.message : "Failed to fetch uploads"
    );
  }
});

const invoiceSlice = createSlice({
  name: "invoice",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchInvoiceList.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchInvoiceList.fulfilled, (state, action) => {
        state.isLoading = false;
        state.invoices = action.payload.data.data;
        state.pagination = {
          currentPage: action.payload.data.currentPage,
          totalPages: action.payload.data.totalPages,
          pageSize: action.payload.data.pageSize,
          totalElements: action.payload.data.totalElements,
        };
        state.error = null;
      })
      .addCase(fetchInvoiceList.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload || "Failed to fetch invoice data";
      })
      // Invoice detail cases
      .addCase(fetchInvoiceDetail.pending, (state) => {
        state.detailLoading = true;
        state.detailError = null;
      })
      .addCase(fetchInvoiceDetail.fulfilled, (state, action) => {
        state.detailLoading = false;
        state.currentInvoiceDetail = action.payload.data.invoice;
        state.currentLineItems = action.payload.data.lineItems;
        state.detailError = null;
      })
      .addCase(fetchInvoiceDetail.rejected, (state, action) => {
        state.detailLoading = false;
        state.detailError = action.payload || "Failed to fetch invoice detail";
      })
      // Additional details cases
      .addCase(fetchAdditionalDetails.pending, (state) => {
        state.additionalDetailsLoading = true;
        state.additionalDetailsError = null;
      })
      .addCase(fetchAdditionalDetails.fulfilled, (state, action) => {
        state.additionalDetailsLoading = false;
        state.currentAdditionalDetails = action.payload.data;
        state.additionalDetailsError = null;
      })
      .addCase(fetchAdditionalDetails.rejected, (state, action) => {
        state.additionalDetailsLoading = false;
        state.additionalDetailsError =
          action.payload || "Failed to fetch additional details";
      })
      // Comments cases
      .addCase(fetchComments.pending, (state) => {
        state.commentsLoading = true;
        state.commentsError = null;
      })
      .addCase(fetchComments.fulfilled, (state, action) => {
        state.commentsLoading = false;
        state.currentComments = action.payload.data.comments;
        state.commentsError = null;
      })
      .addCase(fetchComments.rejected, (state, action) => {
        state.commentsLoading = false;
        state.commentsError = action.payload || "Failed to fetch comments";
      })
      // Create comment cases
      .addCase(createComment.pending, (state) => {
        state.commentsLoading = true;
        state.commentsError = null;
      })
      .addCase(createComment.fulfilled, (state, action) => {
        state.commentsLoading = false;
        // Add the new comment to the beginning of the list
        state.currentComments = [action.payload.data, ...state.currentComments];
        state.commentsError = null;
      })
      .addCase(createComment.rejected, (state, action) => {
        state.commentsLoading = false;
        state.commentsError = action.payload || "Failed to create comment";
      })
      // Fetch uploads cases
      .addCase(fetchUploads.pending, (state) => {
        state.uploadsLoading = true;
        state.uploadsError = null;
      })
      .addCase(fetchUploads.fulfilled, (state, action) => {
        state.uploadsLoading = false;
        state.currentUploads = action.payload.data.documents;
        state.uploadsError = null;
      })
      .addCase(fetchUploads.rejected, (state, action) => {
        state.uploadsLoading = false;
        state.uploadsError = action.payload || "Failed to fetch uploads";
      });
  },
});

export default invoiceSlice.reducer;

// // Selectors
// export const selectInvoices = (state: { invoice: InvoiceState }) =>
//   state.invoice.invoices;
// export const selectPagination = (state: { invoice: InvoiceState }) =>
//   state.invoice.pagination;
// export const selectInvoiceLoading = (state: { invoice: InvoiceState }) =>
//   state.invoice.isLoading;
// export const selectInvoiceError = (state: { invoice: InvoiceState }) =>
//   state.invoice.error;

export const selectInvoices = (state: RootState) => {
  return {
    invoices: state.invoice.invoices,
    totalItems: state.invoice.pagination?.totalElements,
    loading: state.invoice.isLoading,
  };
};

export const selectInvoiceDetail = (state: RootState) => {
  return {
    invoiceDetail: state.invoice.currentInvoiceDetail,
    lineItems: state.invoice.currentLineItems,
    loading: state.invoice.detailLoading,
    error: state.invoice.detailError,
  };
};

export const selectAdditionalDetails = (state: RootState) => {
  return {
    additionalDetails: state.invoice.currentAdditionalDetails,
    loading: state.invoice.additionalDetailsLoading,
    error: state.invoice.additionalDetailsError,
  };
};

export const selectComments = (state: RootState) => {
  return {
    comments: state.invoice.currentComments,
    loading: state.invoice.commentsLoading,
    error: state.invoice.commentsError,
  };
};

export const selectUploads = (state: RootState) => {
  return {
    uploads: state.invoice.currentUploads,
    loading: state.invoice.uploadsLoading,
    error: state.invoice.uploadsError,
  };
};
