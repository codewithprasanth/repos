import {
  createBrowserRouter,
  Navigate,
  RouterProvider,
} from "react-router-dom";
import "./App.scss";
import { App as AntdApp } from "antd";
import { useKeycloak } from "@react-keycloak/web";
import { PrivateRoute } from "./auth/private-route";
import { AppRoles } from "./auth/roles-privileges";
import { setMessageApi } from "./components/Message";
import HomePage from "./modules/home/HomePage";
import InvoiceManagementLayout from "./modules/invoice-management/InvoiceManagementLayout";
import PersonalInbox from "./modules/invoice-management/personal-inbox/PersonalInbox";
import Touchless from "./modules/invoice-management/touchless/Touchless";
import Indexing from "./modules/invoice-management/indexing/Indexing";
import InvoiceDetails from "./modules/invoice-management/details/InvoiceDetails";
// import QCModule from "./modules/invoice-management/qc-module/QCModule";
import AdminLayout from "./modules/admin/AdminLayout";
import DoaConfigOverview from "./modules/admin/doa-configuration/overview/Overview";
import UpsertDoaConfig from "./modules/admin/doa-configuration/upsert-doa-config/UpsertDoaConfig";
import UserManagement from "./modules/admin/user-management/UserManagement";
import UpsertUser from "./modules/admin/user-management/upsert-user/UpsertUser";
import CreateRole from "./modules/admin/user-management/create-role/CreateRole";
import CreateTeam from "./modules/admin/user-management/create-team/CreateTeam";
import AnalyticsLayout from "./modules/analytics/AnalyticsLayout";
import EmailReconReport from "./modules/analytics/email-recon-report/EmailReconReport";
import Organizational from "./modules/analytics/organizational/Organizational";
import PersonalAnalytics from "./modules/analytics/personal/PersonalAnalytics";
import QCAnalysis from "./modules/analytics/qc-analysis/QCAnalysis";
import SpendAnalysis from "./modules/analytics/spend-analysis/SpendAnalysis";
import VolumeForecast from "./modules/analytics/volume-forecast/VolumeForecast";
import Spinner from "./components/spinner";
import Layout from "./modules/Layout";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { login } from "./store/auth/auth-slice";
import { selectIsAuthenticated } from "./store/auth/auth-selector";
import { axiosInstance } from "./auth/axios-config";
// import QCModule from "./modules/invoice-management/qc-module/QCModule";

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      {
        path: "/",
        element: <Navigate to="/home"></Navigate>,
      },
      {
        path: "/home",
        element: (
          <PrivateRoute>
            <HomePage />
          </PrivateRoute>
        ),
      },
      {
        path: "/invoice-management",
        element: (
          <PrivateRoute>
            <InvoiceManagementLayout />
          </PrivateRoute>
        ),
        children: [
          {
            path: "personal-inbox",
            element: (
              <PrivateRoute>
                <PersonalInbox />
              </PrivateRoute>
            ),
          },
          {
            path: "touchless",
            element: (
              <PrivateRoute requiredRoles={[AppRoles.INDEXER, AppRoles.ADMIN]}>
                <Touchless />
              </PrivateRoute>
            ),
          },
          {
            path: "indexing",
            element: (
              <PrivateRoute requiredRoles={[AppRoles.INDEXER, AppRoles.ADMIN]}>
                <Indexing />
              </PrivateRoute>
            ),
          },
          // {
          //   path: "qc-module",
          //   element: <QCModule />,
          // },
          {
            path: "details/:id",
            element: (
              <PrivateRoute>
                <InvoiceDetails />
              </PrivateRoute>
            ),
          },
        ],
      },
      {
        path: "/admin",
        element: (
          <PrivateRoute requiredRoles={[AppRoles.ADMIN]}>
            <AdminLayout />
          </PrivateRoute>
        ),
        children: [
          {
            path: "doa-configuration",
            children: [
              {
                path: "",
                element: <Navigate to="overview" />,
              },
              {
                path: "overview",
                element: <DoaConfigOverview />,
              },
              {
                path: "create-config",
                element: <UpsertDoaConfig />,
              },
              {
                path: "update-config/:configId",
                element: <UpsertDoaConfig />,
              },
            ],
          },
          {
            path: "user-management",
            children: [
              {
                path: "",
                element: <Navigate to="overview" />,
              },
              {
                path: "overview",
                element: <UserManagement />,
              },
              {
                path: "create-user",
                element: <UpsertUser />,
              },
              {
                path: "update-user/:userId",
                element: <UpsertUser />,
              },
              {
                path: "create-role",
                element: <CreateRole />,
              },
              {
                path: "create-team",
                element: <CreateTeam />,
              },
            ],
          },
        ],
      },
      {
        path: "/analytics",
        element: (
          <PrivateRoute>
            <AnalyticsLayout />
          </PrivateRoute>
        ),
        children: [
          {
            path: "email-recon-report",
            element: <EmailReconReport />,
          },
          {
            path: "organizational",
            element: <Organizational />,
          },
          {
            path: "personal-analytics",
            element: <PersonalAnalytics />,
          },
          {
            path: "qc-analysis",
            element: <QCAnalysis />,
          },
          {
            path: "spend-analysis",
            element: <SpendAnalysis />,
          },
          {
            path: "volume-forecast",
            element: <VolumeForecast />,
          },
        ],
      },
    ],
    path: "/",
  },
  {
    path: "*",
    element: <Navigate to="/"></Navigate>,
  },
]);

function App() {
  const { initialized, keycloak } = useKeycloak();
  const dispatch = useDispatch();
  const isAuthenticated = useSelector(selectIsAuthenticated);

  useEffect(() => {
    if (initialized && keycloak) {
      dispatch(login(keycloak));
    }
  }, [dispatch, initialized, keycloak]);

  useEffect(() => {
    const interceptor = axiosInstance.interceptors.request.use(
      (config) => {
        config.headers.Authorization = `Bearer ${keycloak.token}`;
        return config;
      },
      (error) => Promise.reject(error)
    );
    return () => {
      axiosInstance.interceptors.request.eject(interceptor);
    };
  }, [keycloak.token]);

  if (!isAuthenticated) {
    return <Spinner fullscreen={true} />;
  } else {
    return (
      <AntdApp>
        <AppContent />
      </AntdApp>
    );
  }
}

function AppContent() {
  const { message } = AntdApp.useApp();

  useEffect(() => {
    setMessageApi(message);
  }, [message]);

  return <RouterProvider router={router}></RouterProvider>;
}

export default App;
