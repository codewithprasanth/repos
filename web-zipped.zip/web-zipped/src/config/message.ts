import { message as antdMessage } from "antd";

/**
 * Global message configuration
 * - Position: Top right corner (80px from top)
 * - Duration: 3 seconds
 * - Max visible: 3 messages at once
 * - All messages are closable
 */
antdMessage.config({
  top: 80,
  duration: 3,
  maxCount: 3,
});

/**
 * Centralized message utility for consistent notifications across the application.
 *
 * Usage:
 * ```ts
 * import { showMessage } from '@/config/message';
 *
 * showMessage.success('Operation completed successfully');
 * showMessage.error('Failed to save data');
 * showMessage.warning('Please review your input');
 * showMessage.info('New update available');
 *
 * // For loading states
 * const hide = showMessage.loading('Processing...');
 * // Later: hide();
 * ```
 */
export const showMessage = {
  /**
   * Show success message
   */
  success: (content: string) => {
    antdMessage.success({
      content,
      className: "custom-message",
    });
  },

  /**
   * Show error message
   */
  error: (content: string) => {
    antdMessage.error({
      content,
      className: "custom-message",
    });
  },

  /**
   * Show warning message
   */
  warning: (content: string) => {
    antdMessage.warning({
      content,
      className: "custom-message",
    });
  },

  /**
   * Show info message
   */
  info: (content: string) => {
    antdMessage.info({
      content,
      className: "custom-message",
    });
  },

  /**
   * Show loading message (does not auto-close)
   * Returns a function to manually close the message
   */
  loading: (content: string) => {
    return antdMessage.loading({
      content,
      duration: 0, // Loading messages don't auto-close
      className: "custom-message",
    });
  },

  /**
   * Destroy all messages
   */
  destroy: () => {
    antdMessage.destroy();
  },
};

export default showMessage;
