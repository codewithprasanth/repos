// Route metadata for breadcrumbs and navigation
export interface RouteMetadata {
  title: string;
  hasStandalonePage: boolean;
}

// Route segment metadata mapping
export const routeMetadata: Record<string, RouteMetadata> = {
  home: { title: "Home", hasStandalonePage: true },
  "invoice-management": {
    title: "Invoice Management",
    hasStandalonePage: false,
  },
  "personal-inbox": { title: "Personal Inbox", hasStandalonePage: true },
  touchless: { title: "Touchless", hasStandalonePage: true },
  indexing: { title: "Indexing (Manual)", hasStandalonePage: true },
  "qc-module": { title: "QC Module", hasStandalonePage: true },
  admin: { title: "Admin", hasStandalonePage: false },
  "doa-configuration": { title: "DOA Configuration", hasStandalonePage: true },
  "user-management": { title: "User Management", hasStandalonePage: true },
  analytics: { title: "Analytics", hasStandalonePage: false },
  "email-recon-report": {
    title: "Email Recon Report",
    hasStandalonePage: true,
  },
  organizational: { title: "Organizational", hasStandalonePage: true },
  "personal-analytics": {
    title: "Personal Analytics",
    hasStandalonePage: true,
  },
  "qc-analysis": { title: "QC Analysis", hasStandalonePage: true },
  "spend-analysis": { title: "Spend Analysis", hasStandalonePage: true },
  "volume-forecast": { title: "Volume Forecast", hasStandalonePage: true },
  overview: { title: "Overview", hasStandalonePage: true },
  details: { title: "Invoice Details", hasStandalonePage: true },
};

// Helper function to get route metadata by segment
export const getRouteMetadata = (segment: string): RouteMetadata | null => {
  return routeMetadata[segment] || null;
};
