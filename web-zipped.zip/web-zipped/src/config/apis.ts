// Centralized API endpoints configuration
export const API_ENDPOINTS = {
  INVOICE_MANAGEMENT: {
    GET_INVOICE_LIST: "/v1/invoices",
    GET_INVOICE_DETAIL: "/v1/invoices",
    GET_ADDITIONAL_DETAILS: "/v1/invoices",
    GET_COMMENTS: "/v1/invoices",
    POST_COMMENT: "/v1/invoices",
    GET_UPLOADS: "/v1/invoices",
  },
  USER_MANAGEMENT: {
    // Role Management
    GET_ALL_ROLES: "/roles",
    CREATE_ROLE: "/roles",
    GET_ROLE_PRIVILEGES: "/roles/:roleId/privileges",
    UPDATE_ROLE: "/roles/:roleId",
    DELETE_ROLE: "/roles/:roleId",
    GET_ALL_PRIVILEGES: "/roles/privileges",

    // Group Management
    GET_ALL_GROUPS: "/groups",
    CREATE_GROUP: "/groups",
    GET_GROUP_ROLES_PRIVILEGES: "/groups/:groupId/roles-privileges",
    GET_GROUP_USERS: "/groups/:groupId/users",
    UPDATE_GROUP_USERS: "/groups/:groupId/users",
    UPDATE_GROUP_ROLES_PRIVILEGES: "/groups/:groupId/roles-privileges",
    DELETE_GROUP: "/groups/:groupId",

    // User Management
    GET_ALL_USERS: "/users",
    CREATE_USER: "/users",
    GET_USER_BY_ID: "/users/:userId",
    UPDATE_USER: "/users/:userId",
    DELETE_USER: "/users/:userId",
  },
  DOA_CONFIGURATION: {
    GET_ALL_DOA_RULES: "/doa-rules",
    GET_DOA_RULE_BY_ID: "/doa-rules/:id",
    CREATE_DOA_RULE: "/doa-rules",
    UPDATE_DOA_RULE: "/doa-rules/:id",
    DELETE_DOA_RULE: "/doa-rules/:id",
    TOGGLE_DOA_RULE_STATUS: "/doa-rules/:id/toggle-status",
    GET_DOA_RULES_BY_USER: "/doa-rules/user/:userId",
    GET_DOA_RULES_BY_ENTITY: "/doa-rules/entity/:entityId",
  },
} as const;
