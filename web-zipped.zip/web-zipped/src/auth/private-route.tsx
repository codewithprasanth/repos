import { useKeycloak } from "@react-keycloak/web";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { selectUser } from "../store/auth/auth-selector";

type PrivateRouterProps = {
  children: React.ReactNode;
  requiredRoles?: string[];
  redirectTo?: string;
  allRolesRequired?: boolean;
};

export function PrivateRoute({
  children,
  requiredRoles,
  redirectTo = "/home",
  allRolesRequired = false,
}: Readonly<PrivateRouterProps>) {
  const { keycloak } = useKeycloak();
  const user = useSelector(selectUser);

  const isAuthorized = (roles?: string[]) => {
    if (keycloak) {
      if (roles) {
        return roles.some((r) => {
          const realm = keycloak.hasRealmRole(r);
          const resource = keycloak.hasResourceRole(r);
          return realm || resource;
        });
      }
      return !!keycloak.authenticated;
    }
    return false;
  };

  // Check authentication first
  if (!isAuthorized()) {
    return null;
  }

  // If specific roles are required, check them
  if (requiredRoles && requiredRoles.length > 0) {
    const hasRequiredRole = allRolesRequired
      ? requiredRoles.every((role) => user?.roles?.includes(role))
      : user?.roles?.some((role) => requiredRoles.includes(role));

    if (!hasRequiredRole) {
      return <Navigate to={redirectTo} replace />;
    }
  }

  return <>{children}</>;
}
