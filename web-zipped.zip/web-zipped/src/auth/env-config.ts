import type { KeycloakConfig } from "keycloak-js";
import { axiosInstance } from "./axios-config";

type EnvConfig = {
  baseUrl: string;
  keycloak: KeycloakConfig;
};

export async function getConfig() {
  const env = (await axiosInstance.get<{ env: string }>("/env/env.json")).data
    .env;
  return (await axiosInstance.get<EnvConfig>(`/config/env.${env}.json`)).data;
}
