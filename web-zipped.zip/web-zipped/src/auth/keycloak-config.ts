import Keycloak, { type KeycloakConfig } from "keycloak-js";

export function getKeycloakInstance(config: KeycloakConfig) {
  return new Keycloak(config);
}
export const initOptions = { onLoad: "login-required" };
