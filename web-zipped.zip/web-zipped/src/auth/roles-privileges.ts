// Roles - for role-based access control
export const AppRoles = {
  ADMIN: "role_Admin",
  APPROVER: "role_Approver",
  INDEXER: "role_Indexer",
  QUERY_USER: "role_Query User",
} as const;

export type AppRoles = (typeof AppRoles)[keyof typeof AppRoles];

// Privileges - for feature-based access control
// Not used now, but can be useful in future
export const AppPrivileges = {
  ANALYTICS_REPORTING: "priv_Analytics Reporting",
  DAO_CONFIGURATION: "priv_DAO Configuration",
  HOME: "priv_Home",
  INVOICE_MANUAL: "priv_Invoice Manual",
  INVOICE_SUMMARY: "priv_Invoice Summary",
  INVOICE_TOUCHLESS: "priv_Invoice Touchless",
  PERSONAL_INBOX: "priv_Personal Inbox",
  USER_MANAGEMENT: "priv_User Management",
} as const;

export type AppPrivileges = (typeof AppPrivileges)[keyof typeof AppPrivileges];

// Helper function to check if user has role
export const hasRole = (userRoles: string[], role: AppRoles): boolean => {
  return userRoles.includes(role);
};

// Helper function to check if user has privilege
export const hasPrivilege = (
  userRoles: string[],
  privilege: AppPrivileges
): boolean => {
  return userRoles.includes(privilege);
};

// Helper function to check if user has any of the specified roles
export const hasAnyRole = (userRoles: string[], roles: AppRoles[]): boolean => {
  return roles.some((role) => userRoles.includes(role));
};

// Helper function to check if user has any of the specified privileges
export const hasAnyPrivilege = (
  userRoles: string[],
  privileges: AppPrivileges[]
): boolean => {
  return privileges.some((privilege) => userRoles.includes(privilege));
};
