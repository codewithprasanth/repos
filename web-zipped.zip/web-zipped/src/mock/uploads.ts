import type { UploadsResponse } from "../types/uploads";

export const getMockUploads = (workId: string): UploadsResponse => {
  return {
    success: true,
    message: "Documents retrieved successfully",
    data: {
      workId: workId,
      documents: [
        {
          documentId: "12345",
          documentName: "compressed.tracemonkey-pldi-09.pdf",
          documentType: "Invoice",
          uploadedBy: {
            userId: "u001",
            name: "sysadmin",
          },
          uploadedOn: "2025-12-11T21:08:00Z",
          s3Url:
            "https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf",
          fileSizeKB: 512,
          mimeType: "application/pdf",
          actions: {
            canDownload: true,
            canView: true,
            canDelete: true,
          },
        },
        {
          documentId: "12346",
          documentName: "compressed.tracemonkey-pldi-09.pdf",
          documentType: "Mail_Body",
          uploadedBy: {
            userId: "u001",
            name: "sysadmin",
          },
          uploadedOn: "2025-12-11T21:08:00Z",
          s3Url:
            "https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf",
          fileSizeKB: 48,
          mimeType: "application/pdf",
          actions: {
            canDownload: true,
            canView: true,
            canDelete: true,
          },
        },
        {
          documentId: "12347",
          documentName: "compressed.tracemonkey-pldi-09.pdf",
          documentType: "Supporting_Doc",
          uploadedBy: {
            userId: "u002",
            name: "ecm.test1",
          },
          uploadedOn: "2025-11-21T15:52:00Z",
          s3Url:
            "https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf",
          fileSizeKB: 768,
          mimeType: "application/pdf",
          actions: {
            canDownload: true,
            canView: true,
            canDelete: false,
          },
        },
        {
          documentId: "12348",
          documentName: "1.jpeg",
          documentType: "PO",
          uploadedBy: {
            userId: "u003",
            name: "Prasanth",
          },
          uploadedOn: "2025-12-15T12:30:00Z",
          s3Url: "https://api.slingacademy.com/public/sample-photos/1.jpeg",
          fileSizeKB: 256,
          mimeType: "image/jpeg",
          actions: {
            canDownload: true,
            canView: true,
            canDelete: true,
          },
        },
        {
          documentId: "12349",
          documentName: "1.jpeg",
          documentType: "GRN",
          uploadedBy: {
            userId: "u001",
            name: "sysadmin",
          },
          uploadedOn: "2025-12-10T08:15:00Z",
          s3Url: "https://api.slingacademy.com/public/sample-photos/1.jpeg",
          fileSizeKB: 128,
          mimeType: "image/jpeg",
          actions: {
            canDownload: true,
            canView: true,
            canDelete: true,
          },
        },
      ],
    },
    timestamp: "2025-12-14T18:00:45.4703363+05:30",
  };
};
